import assert from 'node:assert/strict';
import {writeFileSync,mkdirSync} from 'node:fs';
import {seed,type Spec} from '../lib/model';
import archive47 from '../data/blueprint-4.7-original.json';
import {applyOperation,backup,verifyBackup} from '../lib/operations';
import {reviewedEvidence,taskIntegrity,semanticIdentity} from '../lib/task-integrity';
import {responseValid,responseDescription,methodBan,STUDIO_VERSION} from '../lib/contracts';
import {validateSvg,validateItem,makePacket,digest,stable,validateBlueprint} from '../lib/validation';
import {packetText,resultSkeleton} from '../lib/packet';
import {completedWitness} from './witness-result';
let checks=0;const ok=(v:unknown,m:string)=>{assert.ok(v,m);checks++;};
const state=(await applyOperation({forms:{}},{kind:'createYear',label:'V0.4 regression',yearKind:'test'})).state;
const find=(code:string)=>seed.items.find(s=>s.structureCode===code)!;
ok(STUDIO_VERSION==='0.4.0','version');
for(const s of seed.items){ok(!!reviewedEvidence(s),'all contracts reviewed');ok(!methodBan(s.action+' '+s.given+' '+s.boundary),'no binding method ban');
 ok(!reviewedEvidence({...s,responseProduct:'One written explanation'}),'response product mutation');
 ok(!reviewedEvidence({...s,domainRules:['Changed numerical domain']}),'domain mutation');
 if(s.claimId==='G6-040')ok(s.visualPolicy==='Required','displayed-data claim');
 if(['COORD-MOVE','COMPARE-QUOTIENTS','ADD-MISSING-PART','DATA-MISSING-FREQUENCY','QUAD-COMMON-CLASS','QUAD-COUNT-CLASSES'].includes(s.structureCode))ok(s.dok===1,'DOK adjudication');
}
for(const code of ['CONVERT-TOTAL','CONVERT-THEN-RESTORE'])ok(semanticIdentity(find(code))==='CONVERT-ADD-COMPONENTS','conversion relation normalized');
for(const code of ['FUNCTION-INPUT','AFFINE-MISSING-RATE']){const s=seed.items.find(s=>s.structureCode===code);if(s)ok(semanticIdentity(s)==='AFFINE-MISSING-FACTOR','inverse affine normalized');}
for(const svg of ["<svg viewBox='0 0 100 80'><rect x='1' y='2' width='3' height='4'/></svg>",'<svg viewBox="0\t0\n100 80"></svg>'])ok(validateSvg(svg)===null,'safe SVG syntax');
for(const svg of ['<svg viewBox="0 0 0 10"></svg>','<svg viewBox="0 0 NaN 10"></svg>','<svg viewBox="0 0 10 10"><script/></svg>','<svg viewBox="0 0 10 10"><rect onclick="x()"/></svg>'])ok(!!validateSvg(svg),'unsafe/malformed SVG');
for(const label of ['below 1','less than 1','equal to 1','above 1','greater than 1','0<k<1','(0,1)','k>1'])ok(responseValid(label,find('SCALING-INFER-INTERVAL')),'factor aliases');
for(const label of ['cm³','cm^3','cubic centimeter','cubic centimetres'])ok(responseValid(label,find('CUBIC-UNIT-IDENTIFY')),'unit aliases');
ok(!responseValid('cm²',find('CUBIC-UNIT-IDENTIFY')),'wrong dimension');
ok(responseDescription(find('CUBIC-UNIT-IDENTIFY')).includes('ARE the response'),'conditional units');
ok(!responseValid('42',find('TRANSLATE-EXPONENTIAL')),'exponent output shape');
ok(responseValid('2^3*(4+1)',find('TRANSLATE-EXPONENTIAL')),'valid exponent output');
ok(!responseValid('Explain why this works',find('TRANSLATE-EXPONENTIAL')),'prose rejected');
ok(methodBan('Do not calculate the exact scale factor.'),'method ban');
ok(!methodBan('Write an unevaluated grouped expression.'),'output form not method');
const budgets:number[]=[];
for(const g of [5,6,7])for(let f=1;f<=8;f++){
 ok(validateBlueprint(g,f,state).filter(x=>x.severity==='error').length===0,'all 24 preflight');
 const p=await makePacket(g,f,state),text=packetText(p),bytes=Buffer.byteLength(text);budgets.push(bytes);
 ok(bytes<180000,'compact packet budget');ok(!text.includes('witnessAnswer')&&!text.includes('witnessCalculation'),'no solved QA answers in generation');
 ok(p.adjacent.length===30&&p.paired.length===(g===6?30:15),'complete exclusions');
 const r=completedWitness(p);ok(r.items.flatMap((i,j)=>validateItem(i,p.items[j],state,r.items)).filter(i=>i.severity==='error').length===0,'all fixtures');
 // Same mathematical SVG encoded differently must pass the same item gate.
 const j=r.items.findIndex(i=>i.visual?.kind==='svg');if(j>=0){const alternate=structuredClone(r.items[j]);if(alternate.visual?.kind==='svg')alternate.visual.svg=alternate.visual.svg.replaceAll('"',"'");ok(validateItem(alternate,p.items[j],state,r.items).filter(i=>i.severity==='error').length===0,'alternate visual encoding');}
}
// A real v0.3 packet stays immutable on restore, but cannot be mistaken for current design.
const g=5,f=1,p={schema:'aac.packet.v1',projectId:`AAC-${state.year!.id}`,assessmentYear:state.year,purpose:'generation',seedHash:archive47.seedHash,packetId:crypto.randomUUID(),designRevision:'archived-v03',grade:g,form:f,issuedAt:new Date().toISOString(),studioVersion:'0.3.0',blueprintVersion:'4.7.0',contractVersion:'aac.contract.v3',items:await Promise.all(archive47.items.filter(s=>s.grade===g&&s.form===f).map(async s=>({...s,specificationHash:await digest(s),proposedTemplateId:'T-OLD',proposedSurfaceFormId:'S-OLD'}))),adjacent:archive47.items.filter(s=>s.grade===g&&[8,2].includes(s.form)),paired:archive47.items.filter(s=>s.grade===6&&s.form===f)};
const b={...backup(state,1),seedHash:archive47.seedHash,state:{...state,forms:{'5|1':{packet:p,items:[],checks:{},status:'draft',updatedAt:new Date().toISOString()}}}};
const restored=await verifyBackup(b,{forms:{}});ok(stable(restored.forms['5|1'].packet)===stable(p),'v0.3 restore immutable');
const bad=structuredClone(b);bad.state.forms['5|1'].packet.items[0].given='tampered';await assert.rejects(()=>verifyBackup(bad,{forms:{}}));checks++;
mkdirSync('docs/releases',{recursive:true});writeFileSync('docs/releases/0.4-regression.json',JSON.stringify({checks,forms:24,slots:360,packetBytes:{min:Math.min(...budgets),max:Math.max(...budgets)},scope:'Contract regressions, bank checks, safe encoding variants and v0.3 migration. Mathematical and visual educator review remains required.'},null,2)+'\n');console.log('PASS:',checks,'V0.4 assertions');
