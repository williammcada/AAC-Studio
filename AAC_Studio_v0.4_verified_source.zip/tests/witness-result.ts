import witnesses from '../data/v04/witnesses.json';
import {type Packet} from '../lib/model';
import {resultSkeleton} from '../lib/packet';
export function completedWitness(p:Packet){const r=resultSkeleton(p);r.items=r.items.map((i,j)=>{const w=witnesses[p.items[j].key as keyof typeof witnesses];return {...i,stem:w.stem,choices:w.choices,answer:w.answer,solution:w.solution,visual:w.visual as any,scoringNote:'Award one point for the correct response.',reviewNote:'Isolated release test witness; not an accepted school assessment.'};});return r;}
