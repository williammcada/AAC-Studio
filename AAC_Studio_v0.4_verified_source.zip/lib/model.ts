import rawSeed from './seed.json';
import historicalSeed from '../data/blueprint-4.5-original.json';
export {historicalSeed};
export const seed=rawSeed;
type CurrentSpec=(typeof seed.items)[number];
type V4Fields='domainRules'|'difficultyRationale'|'variationEvidence';
export type Spec=Omit<CurrentSpec,V4Fields>&Partial<Pick<CurrentSpec,V4Fields>>;
export type Visual={kind:'svg';svg:string;alt:string}|{kind:'image';dataUrl:string;alt:string}|{kind:'table';headers:string[];rows:string[][];alt:string};
export type Item={question:number;specificationHash:string;templateId:string;surfaceFormId:string;structureFamilyId:string;stem:string;choices:string[];answer:string;acceptedAnswers:string[];scoringNote:string;solution:string[];visual:Visual|null;reviewNote:string;reviewed?:boolean};
export type Packet={schema:'aac.packet.v1';projectId:string;seedHash:string;packetId:string;designRevision:string;grade:number;form:number;issuedAt:string;assessmentYear?:AssessmentYear;purpose?:'generation'|'audit'|'diagnostic';studioVersion?:string;blueprintVersion?:string;contractVersion?:string;preflightIssues?:Issue[];items:(Spec & {specificationHash:string;proposedTemplateId:string;proposedSurfaceFormId:string})[];adjacent:Spec[];paired:Spec[]};
export type GenerationConflict={status:'open'|'resolved';message:string;reportedAt:string;packetId:string;designRevision:string;resolution?:string;resolvedAt?:string};
export type FormState={packet:Packet;items:Item[];checks:Record<string,boolean>;status:'draft'|'finalized';updatedAt:string;finalizedAt?:string;conflict?:GenerationConflict};
export type AssessmentYear={id:string;label:string;kind:'assessment'|'test';createdAt:string};
// The active bank lives in forms; otherYears contains only inactive banks.
// Switching moves a bank atomically, so each year's records have one canonical copy.
export type YearBank={year:AssessmentYear;forms:Record<string,FormState>};
export type State={forms:Record<string,FormState>;year?:AssessmentYear;otherYears?:YearBank[]};
export const ORIGINAL_YEAR:AssessmentYear={id:'aac-2026-27',label:'2026–2027',kind:'assessment',createdAt:'2026-01-01T00:00:00.000Z'};
export const currentYear=(state:State)=>state.year||ORIGINAL_YEAR;
export const historicalLocks=(state:State)=>currentYear(state).id===ORIGINAL_YEAR.id;
export const yearBanks=(state:State):YearBank[]=>[{year:currentYear(state),forms:state.forms},...(state.otherYears||[])];
export const yearProject=(state:State)=>historicalLocks(state)?seed.projectId:`AAC-${currentYear(state).id}`;
export const fileYear=(state:State)=>currentYear(state).label.replace(/[^a-zA-Z0-9]+/g,'-');
export const allFormEntries=(state:State)=>yearBanks(state).flatMap(b=>Object.values(b.forms));

export type HistoryEntry={id:string;revision:number;summary:string;created_at:string};
export type WorkspaceData={state:State;revision:number;history:HistoryEntry[]};
export type Issue={severity:'error'|'warning';code:string;message:string;question?:number};
export const formKey=(grade:number,form:number)=>`${grade}|${form}`;
export const slots=(grade:number,form:number)=>seed.items.filter(i=>i.grade===grade&&i.form===form);
export const checklist:Record<string,string>={cognitiveDemand:'I checked that each item meets its assigned DOK through its mathematical reasoning, not just extra arithmetic.',mathematics:'I checked every answer and worked solution for mathematical accuracy.',structure:'I checked the action and given/unknown relationship against the assigned task and all adjacent and paired structures.',accessibility:'I reviewed all 15 items together for clear language, ELL accessibility, workload, and redundancy.',visuals:'I checked required visuals, labels, grayscale legibility, and the printed layout.'};

// Compatibility adapter ONLY for immutable v1.2.1 packets. Never used for current generation.
export const legacyNeedsRepair=(grade:number,form:number)=>form<4;
export const legacyGenerationSpecs=(grade:number,form:number):Spec[]=>historicalSeed.items.filter(s=>s.grade===grade&&s.form===form).map(s=>({...s,
 wordLimit:s.wordLimit||45,
 context:s.context==='Locked final item'?'Direct mathematical prompt; use neutral, internationally familiar context only when it helps the assigned action.':s.context,
 family:s.family==='Locked final item'?'Inherited legacy task family; preserve the assigned action and given/unknown relationship.':s.family,
 boundary:s.boundary==='Retain the finalized item.'?'Use only the stated action, given/unknown relationship, and required response; do not introduce an additional skill.':s.boundary,
 taskRuleId:'LEGACY-MIGRATION'
}));
