import {z} from 'zod';
// A deliberately bounded adapter for the Zod nodes actually used by the importer.
// Unsupported nodes fail loudly instead of publishing an approximate contract.
export function schemaDocument(schema:z.ZodTypeAny):Record<string,unknown>{
 const d=schema._def;
 switch(d.typeName){
 case z.ZodFirstPartyTypeKind.ZodObject:{const shape=(schema as z.ZodObject<z.ZodRawShape>).shape;return {type:'object',properties:Object.fromEntries(Object.entries(shape).map(([k,v])=>[k,schemaDocument(v)])),required:Object.entries(shape).filter(([,v])=>!v.isOptional()).map(([k])=>k),additionalProperties:d.unknownKeys!=='strict'};}
 case z.ZodFirstPartyTypeKind.ZodString:{const out:Record<string,unknown>={type:'string'};for(const c of d.checks||[]){if(c.kind==='min')out.minLength=c.value;else if(c.kind==='max')out.maxLength=c.value;else if(c.kind==='regex')out.pattern=c.regex.source;else throw Error('Undocumented string constraint');}return out;}
 case z.ZodFirstPartyTypeKind.ZodNumber:{const out:Record<string,unknown>={type:'number'};for(const c of d.checks||[]){if(c.kind==='int')out.type='integer';else if(c.kind==='min')out[c.inclusive?'minimum':'exclusiveMinimum']=c.value;else if(c.kind==='max')out[c.inclusive?'maximum':'exclusiveMaximum']=c.value;else throw Error('Undocumented number constraint');}return out;}
 case z.ZodFirstPartyTypeKind.ZodLiteral:return {const:d.value};
 case z.ZodFirstPartyTypeKind.ZodEnum:return {type:'string',enum:d.values};
 case z.ZodFirstPartyTypeKind.ZodArray:return {type:'array',items:schemaDocument(d.type),...(d.minLength?{minItems:d.minLength.value}:{}),...(d.maxLength?{maxItems:d.maxLength.value}:{}),...(d.exactLength?{minItems:d.exactLength.value,maxItems:d.exactLength.value}:{})};
 case z.ZodFirstPartyTypeKind.ZodDiscriminatedUnion:return {oneOf:[...d.options.values()].map(schemaDocument)};
 case z.ZodFirstPartyTypeKind.ZodNullable:return {anyOf:[schemaDocument(d.innerType),{type:'null'}]};
 case z.ZodFirstPartyTypeKind.ZodDefault:return {...schemaDocument(d.innerType),default:d.defaultValue()};
 case z.ZodFirstPartyTypeKind.ZodOptional:return schemaDocument(d.innerType);
 default:throw Error(`Undocumented schema node: ${d.typeName}`);
 }
}
