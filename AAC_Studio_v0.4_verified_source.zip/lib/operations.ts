import archive46 from '../data/blueprint-4.6-original.json';
import archive47 from '../data/blueprint-4.7-original.json';
import archive45 from '../data/blueprint-4.5-original.json';
import {STUDIO_VERSION} from './contracts';
import previousSeed from '../data/blueprint-4.4-original.json';
import {z} from 'zod';
import {seed,slots,formKey,type State,type FormState,type Item,checklist,legacyNeedsRepair,legacyGenerationSpecs,currentYear,historicalLocks,yearBanks,yearProject,ORIGINAL_YEAR,type YearBank} from './model';
import {makePacket,parseResult,itemSchema,validateItem,canFinalize,stable,digest,adjacentSlots,pairedSlots} from './validation';
type FormOperation={kind:'packet';grade:number;form:number;diagnostic?:boolean}|{kind:'import';grade:number;form:number;result:unknown}|{kind:'edit';grade:number;form:number;item:unknown}|{kind:'review';grade:number;form:number;question:number;reviewed:boolean}|{kind:'checks';grade:number;form:number;checks:Record<string,boolean>}|{kind:'finalize';grade:number;form:number}|{kind:'restore';backup:unknown}|{kind:'conflict';grade:number;form:number;message:string}|{kind:'resolveConflict';grade:number;form:number;resolution:string};
export type Operation=(FormOperation & {yearId?:string})|{kind:'createYear';label:string;yearKind:'assessment'|'test'}|{kind:'switchYear';yearId:string}|{kind:'deleteYear';yearId:string;confirmation:string};
export async function verifyBackup(input:unknown,current:State):Promise<State>{
 const b=structuredClone(input) as {schema?:string;state?:State;seedHash?:string};
 if(b?.schema!=='aac.backup.v2'){
  const original=yearBanks(current).find(b=>b.year.id===ORIGINAL_YEAR.id)!;
  const restored=await verifyBank(input,{...original});
  return {...restored,year:ORIGINAL_YEAR,otherYears:yearBanks(current).filter(b=>b.year.id!==ORIGINAL_YEAR.id)};
 }
 if(!b.state||![seed.seedHash,previousSeed.seedHash,archive45.seedHash,archive46.seedHash,archive47.seedHash].includes(b.seedHash||''))throw Error('This backup does not match this blueprint.');
 const banks=yearBanks(b.state),existing=yearBanks(current);
 if(!Array.isArray(b.state.otherYears)||banks.length>100)throw Error('Invalid assessment-year backup.');
 const ids=new Set<string>(),labels=new Set<string>();
 for(const bank of banks){
  const y=bank.year;
  if(!y||!/^aac-(?:2026-27|[a-f0-9-]{36})$/.test(y.id)||typeof y.label!=='string'||!y.label.trim()||y.label.length>60||!['assessment','test'].includes(y.kind)||!Number.isFinite(Date.parse(y.createdAt)))throw Error('Invalid assessment year.');
  if(ids.has(y.id)||labels.has(y.label.trim().toLowerCase()))throw Error('Duplicate assessment years in backup.');ids.add(y.id);labels.add(y.label.trim().toLowerCase());
  if(y.id===ORIGINAL_YEAR.id&&stable(y)!==stable(ORIGINAL_YEAR))throw Error('The original assessment year cannot be renamed or replaced.');
  const old=existing.find(x=>x.year.id===y.id);
  if(old&&stable(old.year)!==stable(y))throw Error('A backup cannot change an existing year identity.');
  const checked=await verifyBank({schema:'aac.backup.v1',seedHash:b.seedHash,state:bank},{forms:old?.forms||{},year:y});bank.forms=checked.forms;
 }
 if(!ids.has(ORIGINAL_YEAR.id))throw Error('A backup must preserve the original assessment year.');
 for(const old of existing)if(!ids.has(old.year.id)&&Object.values(old.forms).some(e=>e.status==='finalized'))throw Error('A backup cannot remove a year with finalized records. Use Delete year explicitly.');
 return {year:banks[0].year,forms:banks[0].forms,otherYears:banks.slice(1)};
}
async function verifyBank(input:unknown,current:State):Promise<State>{
 if(!input||typeof input!=='object')throw Error('Choose an AAC Studio backup.');
 const b=input as {schema:string;seedHash:string;state:State};if(b.schema!=='aac.backup.v1'||![seed.seedHash,previousSeed.seedHash,archive45.seedHash,archive46.seedHash,archive47.seedHash].includes(b.seedHash)||!b.state?.forms||typeof b.state.forms!=='object'||Array.isArray(b.state.forms))throw Error('This backup does not match this blueprint.');
 const out:State={forms:{},year:currentYear(current)};
 for(const [key,value] of Object.entries(b.state.forms)){
  if(!(historicalLocks(current)?/^[567]\|[4-8]$/:/^[567]\|[1-8]$/).test(key)||!value||typeof value!=='object')throw Error('The backup contains an invalid or protected form.');
  const [g,f]=key.split('|').map(Number);const e=structuredClone(value);const p=e.packet;const source=p?.seedHash===previousSeed.seedHash?previousSeed:p?.seedHash===archive45.seedHash?archive45:p?.seedHash===archive46.seedHash?archive46:p?.seedHash===archive47.seedHash?archive47:seed;
  if(!p||p.grade!==g||p.form!==f||p.seedHash!==source.seedHash||p.projectId!==yearProject(current)||!['draft','finalized'].includes(e.status))throw Error(`Invalid backup record ${key}.`);
  if(p.assessmentYear&&stable(p.assessmentYear)!==stable(currentYear(current)))throw Error('The packet belongs to a different assessment year.');
  if(!historicalLocks(current)&&(!p.assessmentYear||(p.purpose==='audit'&&(e.items.length||e.status==='finalized'))))throw Error('Legacy audit packets cannot contain accepted items.');
  if(p.schema!=='aac.packet.v1'||!/^[-a-zA-Z0-9]+$/.test(p.packetId)||!/^[-a-zA-Z0-9]+$/.test(p.designRevision))throw Error('The backup contains an invalid packet.');
  const canonical=!historicalLocks(current)&&source===archive45&&p.purpose!=='audit'&&legacyNeedsRepair(g,f)?legacyGenerationSpecs(g,f):source.items.filter(s=>s.grade===g&&s.form===f);if(p.items?.length!==15||new Set(p.items.map(i=>i.question)).size!==15)throw Error('The backup contains invalid allocations.');
  for(const s of canonical){const pi=p.items.find(x=>x.question===s.question);if(!pi||pi.specificationHash!==await digest(s))throw Error('The backup changes an assigned specification.');for(const [k,v] of Object.entries(s))if(stable(pi[k as keyof typeof pi])!==stable(v))throw Error('The backup changes an assigned specification.');}
  if(p.adjacent?.length!==30||p.paired?.length!==(g===6?30:15))throw Error('The backup lacks the required comparison structures.');
  for(const [stored,expected] of [[p.adjacent,source.items.filter(s=>s.grade===g&&(s.form===(f===1?8:f-1)||s.form===(f===8?1:f+1)))],[p.paired,source.items.filter(s=>Math.abs(s.grade-g)===1&&s.form===f)]] as const){for(const s of expected){const sourceSpec=(source===seed||source===archive46||source===archive47)&&historicalLocks(current)&&s.form<4?archive45.items.find(x=>x.key===s.key)||s:s;const x=stored.find(v=>v.key===s.key);const locked=b.state.forms[formKey(s.grade,s.form)];const alternative=locked?.status==='finalized'?locked.packet.items.find(v=>v.key===s.key):null;const matches=(v:typeof s|null|undefined)=>v&&x&&Object.entries(v).filter(([k])=>!['templateId','surfaceFormId','specificationHash','proposedTemplateId','proposedSurfaceFormId'].includes(k)).every(([k,value])=>stable((x as unknown as Record<string,unknown>)[k])===stable(value));if(!matches(sourceSpec)&&!matches(alternative))throw Error('The backup changes a comparison structure.');}}
  if(!Array.isArray(e.items)||(e.items.length!==0&&e.items.length!==15)||new Set(e.items.map(i=>i.question)).size!==e.items.length)throw Error('A restored draft must contain zero or 15 items.');
  e.items=e.items.map(i=>{const {reviewed,...data}=i;const item=itemSchema.parse(data);if(item.specificationHash!==p.items.find(s=>s.question===item.question)?.specificationHash)throw Error('The restored item is bound to a different specification.');return {...item,reviewed:reviewed===true};});
  if(e.conflict)e.conflict=conflictRecord.parse(e.conflict);if(e.status!=='finalized')e.checks=Object.fromEntries(Object.keys(checklist).map(k=>[k,e.checks?.[k]===true]));out.forms[key]=e;
 }
 for(const [key,e] of Object.entries(current.forms))if(e.status==='finalized'&&stable(e)!==stable(out.forms[key]))throw Error(`Grade ${key[0]} Form ${key[2]} is finalized. A backup cannot remove or change it.`);
 for(const [key,e] of Object.entries(out.forms)){
  if(e.status==='finalized'&&current.forms[key]?.status!=='finalized'){
   if(e.items.length!==15||e.items.some(i=>!i.reviewed)||Object.keys(checklist).filter(k=>e.packet.seedHash!==previousSeed.seedHash||k!=='cognitiveDemand').some(k=>!e.checks[k]))throw Error('A finalized backup lacks complete review records.');
   const errors=e.packet.seedHash!==seed.seedHash?[]:e.items.flatMap(i=>validateItem(i,e.packet.items.find(s=>s.question===i.question)!,out,e.items)).filter(i=>i.severity==='error');if(errors.length)throw Error(`Finalized backup validation failed: ${errors[0].message}`);
  }
 }
 return out;
}
export async function applyOperation(current:State,op:Operation):Promise<{state:State;summary:string}>{
 if(op.kind==='createYear'){
  const label=op.label?.trim().replace(/\s+/g,' ');if(!label||label.length>60||/[<>\x00-\x1f]/.test(label)||!['assessment','test'].includes(op.yearKind))throw Error('Enter a year name of 1–60 characters and choose assessment or test.');
  const banks=yearBanks(current);if(banks.length>=100)throw Error('Delete an unused year before adding another (limit 100).');
  const normalized=(s:string)=>s.toLowerCase().replace(/[–—]/g,'-').replace(/\s/g,'');
  if(banks.some(b=>normalized(b.year.label)===normalized(label)))throw Error('An assessment year with that name already exists.');
  const year={id:`aac-${crypto.randomUUID()}`,label,kind:op.yearKind,createdAt:new Date().toISOString()};
  return {state:{year,forms:{},otherYears:structuredClone(banks)},summary:`Created ${year.kind} year: ${label}`};
 }
 if(op.kind==='switchYear'||op.kind==='deleteYear'){
  const banks=structuredClone(yearBanks(current)),target=banks.find(b=>b.year.id===op.yearId);if(!target)throw Error('This assessment year no longer exists.');
  if(op.kind==='deleteYear'){
   if(target.year.id===ORIGINAL_YEAR.id)throw Error('The original 2026–2027 assessment year cannot be deleted.');
   if(op.confirmation!==target.year.label)throw Error('Type the exact year name to confirm deletion.');
   const remaining=banks.filter(b=>b.year.id!==op.yearId),next=remaining.find(b=>b.year.id===currentYear(current).id)||remaining.find(b=>b.year.id===ORIGINAL_YEAR.id)!;
   return {state:{...next,otherYears:remaining.filter(b=>b.year.id!==next.year.id)},summary:`Deleted year: ${target.year.label} (${Object.keys(target.forms).length} form records)`};
  }
  return {state:{...target,otherYears:banks.filter(b=>b.year.id!==op.yearId)},summary:`Opened assessment year: ${target.year.label}`};
 }
 if(op.yearId&&op.yearId!==currentYear(current).id)throw Error('The active assessment year changed. Reopen the intended year and retry.');
 if(op.kind==='restore')return {state:await verifyBackup(op.backup,current),summary:'Restored a reviewed workspace backup'};
 const {grade:g,form:f}=op;if(![5,6,7].includes(g)||!Number.isInteger(f)||f<1||f>8||(f<4&&historicalLocks(current)))throw Error('Forms 1–3 are locked only in the original year. Choose a new assessment year.');
 const key=formKey(g,f),state=structuredClone(current),old=state.forms[key];if(old?.status==='finalized')throw Error('This form is finalized and cannot be changed.');
 const now=new Date().toISOString(),label=`${currentYear(current).label} · G${g} Form ${f}`;
 if(op.kind==='packet'){
  const packet=await makePacket(g,f,current,op.diagnostic===true);state.forms[key]={packet,items:old?.items||[],checks:old?.checks||{},status:'draft',updatedAt:now,...(old?.conflict?{conflict:old.conflict}:{})};
  if(old&&packet.packetId!==old.packet.packetId){state.forms[key].items=[];state.forms[key].checks={};if(state.forms[key].conflict)state.forms[key].conflict={...state.forms[key].conflict!,status:'resolved',resolution:'Superseded by a new blueprint packet; the previous report is retained for reference.',resolvedAt:now};}
  return {state,summary:`${label}: generation packet saved`};
 }
 if(!old)throw Error('Export a generation packet for this form first.');
 const e=state.forms[key];
 switch(op.kind){
  case 'import':{const candidate=op.result as {schema?:string};if(candidate?.schema==='aac.conflict.v1'){const c=conflictResult.parse(candidate);if(c.projectId!==e.packet.projectId||c.seedHash!==e.packet.seedHash||c.packetId!==e.packet.packetId||c.designRevision!==e.packet.designRevision||c.grade!==g||c.form!==f)throw Error('This conflict report belongs to a different packet.');e.conflict={status:'open',packetId:e.packet.packetId,designRevision:e.packet.designRevision,reportedAt:now,message:c.issues.map(i=>`${i.question?`Q${i.question}: `:''}${i.message}${i.suggestedRepair?` Proposed repair: ${i.suggestedRepair}`:''}`).join('\n')};if(e.conflict.message.length>30000)throw Error('The combined conflict report exceeds 30,000 characters.');}else{const incoming=await parseResult(op.result,e.packet,current);const errors=incoming.flatMap(i=>validateItem(i,e.packet.items.find(s=>s.question===i.question)!,current,incoming)).filter(i=>i.severity==='error');if(errors.length)throw Error(errors.map(i=>`Q${i.question}: ${i.message}`).join('\n'));e.items=incoming;e.checks={};}break;}
  case 'conflict':if(op.message.trim().length<10||op.message.length>30000)throw Error('Supply a conflict report of 10–30,000 characters.');e.conflict={status:'open',packetId:e.packet.packetId,designRevision:e.packet.designRevision,reportedAt:now,message:op.message.trim()};break;
  case 'resolveConflict':if(!e.conflict)throw Error('There is no saved conflict report.');if(op.resolution.trim().length<10||op.resolution.length>3000)throw Error('Record how the conflict was resolved (10–3,000 characters).');e.conflict={...e.conflict,status:'resolved',resolution:op.resolution.trim(),resolvedAt:now};e.checks={};break;
  case 'edit':{
   const item=itemSchema.parse(op.item) as Item;const s=e.packet.items.find(s=>s.question===item.question);if(!s||item.specificationHash!==s.specificationHash||item.structureFamilyId!==s.structureFamilyId)throw Error('Editing cannot change the assigned task.');
   if(!e.items.some(i=>i.question===item.question))throw Error('Import the complete result before editing.');const editErrors=validateItem(item,s,state,e.items);if(editErrors.some(x=>x.severity==='error'))throw Error(editErrors.map(x=>x.message).join(' '));e.items=e.items.map(i=>i.question===item.question?{...item,reviewed:false}:i);e.checks={};break;
  }
  case 'review':{
   const item=e.items.find(i=>i.question===op.question);if(!item)throw Error('Choose an imported item.');if(op.reviewed){const errors=validateItem(item,e.packet.items.find(s=>s.question===op.question)!,state,e.items).filter(i=>i.severity==='error');if(errors.length)throw Error(errors.map(i=>i.message).join(' '));}item.reviewed=op.reviewed===true;e.checks={};break;
  }
  case 'checks':e.checks=Object.fromEntries(Object.keys(checklist).map(k=>[k,op.checks?.[k]===true]));break;
  case 'finalize':{
   const errors=(await canFinalize(e,state)).filter(i=>i.severity==='error');if(errors.length)throw Error(errors.map(i=>i.message).join(' '));e.status='finalized';e.finalizedAt=now;break;
  }
  default:throw Error('Unknown workspace action.');
 }
 e.updatedAt=now;
 return {state,summary:`${label}: ${op.kind==='conflict'?'generation conflict recorded':op.kind==='resolveConflict'?'conflict resolution recorded':op.kind==='import'?(e.conflict?.reportedAt===now?'generation conflict imported':'15 items imported'):op.kind==='edit'?'item revised':op.kind==='review'?'item review saved':op.kind==='checks'?'form review saved':'form finalized and locked'}`};
}
export function backup(state:State,revision:number){return {schema:'aac.backup.v2',studioVersion:STUDIO_VERSION,projectId:seed.projectId,seedHash:seed.seedHash,blueprintVersion:seed.blueprintVersion,blueprint:seed,createdAt:new Date().toISOString(),revision,state:{...state,year:currentYear(state),otherYears:state.otherYears||[]}};}

const conflictRecord=z.object({status:z.enum(['open','resolved']),message:z.string().min(10).max(30000),reportedAt:z.string(),packetId:z.string(),designRevision:z.string(),resolution:z.string().max(3000).optional(),resolvedAt:z.string().optional()}).strict();
const conflictResult=z.object({schema:z.literal('aac.conflict.v1'),projectId:z.string(),seedHash:z.string(),packetId:z.string(),designRevision:z.string(),grade:z.number().int(),form:z.number().int(),issues:z.array(z.object({question:z.number().int().min(1).max(15).optional(),message:z.string().min(10).max(1500),suggestedRepair:z.string().max(1500).optional()}).strict()).min(1).max(30)}).strict();
