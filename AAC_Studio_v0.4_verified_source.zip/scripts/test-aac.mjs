import {execFileSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
const output=mkdtempSync(join(tmpdir(),'aac-tests-'));
try{for(const test of ['domain','storage','assessment-years','release-02','release-03','release-04',...(process.env.AAC_TEST_INDEXEDDB?['offline-years']:[])]){const target=join(output,`${test}.mjs`);execFileSync(resolve('node_modules/.pnpm/node_modules/esbuild/bin/esbuild'),[`tests/${test}.ts`,'--bundle','--platform=node','--format=esm',`--outfile=${target}`,...(test==='storage'?['--alias:cloudflare:workers=./tests/storage-env.ts']:[])],{stdio:'inherit'});execFileSync(process.execPath,[target],{stdio:'inherit',env:{...process.env,AAC_QA_DIR:output}});}}finally{rmSync(output,{recursive:true,force:true});}
