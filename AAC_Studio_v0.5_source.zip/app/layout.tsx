import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AAC Studio v0.2.0",
  description: "William McAda’s admissions assessment workspace for Grades 5–7.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
