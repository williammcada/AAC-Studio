import {STUDIO_VERSION} from '../lib/contracts';
import {seed,allFormEntries,type State,type WorkspaceData,type HistoryEntry} from '../lib/model';
import {applyOperation,backup,verifyBackup,type Operation} from '../lib/operations';
import {digest} from '../lib/validation';
import {download} from '../lib/export';

type Bootstrap={workspaceId:string;backup?:ReturnType<typeof backup>};
type StoredState={revision:number;state:State};
type StoredRevision=HistoryEntry & {state:State};
const tag=typeof document==='undefined'?null:document.getElementById('aac-initial-state');
const bootstrap:Bootstrap=tag?JSON.parse(tag.textContent||'{}'):{workspaceId:'aac-2026-27-offline'};
const source=typeof document==='undefined'?'':`<!doctype html>\n${document.documentElement.outerHTML}`;
let dbPromise:Promise<IDBDatabase|null>|null=null;
let memory:WorkspaceData={state:{forms:{}},revision:0,history:[]};
const memoryHistory=new Map<number,State>();
let temporary=false;
let bootState:Promise<State>|null=null;
const initialState=()=>bootState??=bootstrap.backup?verifyBackup(bootstrap.backup,{forms:{}}):Promise.resolve({forms:{}});
export const storageNotice=()=>temporary?'Browser saving is unavailable. Save an HTML copy or JSON backup before closing this tab.':'Changes save in this browser. Save an HTML copy or JSON backup to keep a portable copy.';

function database():Promise<IDBDatabase|null>{
 if(dbPromise)return dbPromise;
 dbPromise=new Promise((resolve,reject)=>{
  if(typeof indexedDB==='undefined'){temporary=true;resolve(null);return;}
  try{const request=indexedDB.open(`aac-studio-${bootstrap.workspaceId||'aac-2026-27-offline'}`,1);
   request.onupgradeneeded=()=>{const db=request.result;db.createObjectStore('current');db.createObjectStore('history',{keyPath:'revision'});db.createObjectStore('assets');};
   request.onsuccess=()=>{const db=request.result;db.onversionchange=()=>db.close();resolve(db);};
   request.onerror=()=>{if(['SecurityError','InvalidStateError','NotSupportedError'].includes(request.error?.name||'')){temporary=true;resolve(null);}else reject(Error('Local saved work could not be opened. Close other copies and retry.'));};
   request.onblocked=()=>reject(Error('Close other AAC Studio tabs, then reload this file.'));
  }catch(e){if(e instanceof DOMException&&['SecurityError','NotSupportedError'].includes(e.name)){temporary=true;resolve(null);}else reject(e);}
 });return dbPromise;
}
const requestResult=<T>(request:IDBRequest<T>)=>new Promise<T>((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error||Error('Local storage failed.'));});
async function expand(db:IDBDatabase,packed:State):Promise<State>{
 const state=structuredClone(packed);const wanted=new Set<string>();
 for(const entry of allFormEntries(state))for(const item of entry.items){const key=(item.visual as unknown as {offlineAsset?:string})?.offlineAsset;if(key)wanted.add(key);}
 if(!wanted.size)return state;
 const tx=db.transaction('assets','readonly'),assets=new Map<string,unknown>();
 await Promise.all([...wanted].map(async key=>{const value=await requestResult(tx.objectStore('assets').get(key));if(!value)throw Error('A saved figure is missing. Restore a complete backup or open a saved HTML copy.');assets.set(key,value);}));
 for(const entry of allFormEntries(state))for(const item of entry.items){const key=(item.visual as unknown as {offlineAsset?:string})?.offlineAsset;if(key)item.visual=assets.get(key) as typeof item.visual;}
 return state;
}
async function compact(state:State){const packed=structuredClone(state),assets=new Map<string,unknown>();for(const entry of allFormEntries(packed))for(const item of entry.items)if(item.visual){const key=await digest(item.visual);assets.set(key,item.visual);item.visual={offlineAsset:key} as unknown as typeof item.visual;}return {packed,assets};}
export async function readHistory(before=Number.MAX_SAFE_INTEGER):Promise<HistoryEntry[]>{
 const db=await database();if(!db)return memory.history.filter(h=>h.revision<before).slice(0,60);
 return new Promise((resolve,reject)=>{const tx=db.transaction('history','readonly'),out:HistoryEntry[]=[];const request=tx.objectStore('history').openCursor(IDBKeyRange.upperBound(before,true),'prev');request.onerror=()=>reject(request.error);request.onsuccess=()=>{const cursor=request.result;if(!cursor||out.length===60){resolve(out);return;}const {id,revision,summary,created_at}=cursor.value as StoredRevision;out.push({id,revision,summary,created_at});cursor.continue();};});
}
export async function readWorkspace():Promise<WorkspaceData>{
 const db=await database();if(!db){if(!memory.revision&&Object.keys(memory.state.forms).length===0)memory.state=await initialState();return structuredClone(memory);}
 const value=await requestResult(db.transaction('current','readonly').objectStore('current').get('main')) as StoredState|undefined;
 return {state:value?await expand(db,value.state):await initialState(),revision:value?.revision||0,history:await readHistory()};
}
export async function readRevision(revision:number){const db=await database();if(!db){const s=memoryHistory.get(revision);if(!s)throw Error('This saved revision is unavailable.');return backup(structuredClone(s),revision);}const value=await requestResult(db.transaction('history','readonly').objectStore('history').get(revision)) as StoredRevision|undefined;if(!value)throw Error('This saved revision is unavailable.');return backup(await expand(db,value.state),revision);}
export async function mutate(expectedRevision:number,operation:Operation):Promise<WorkspaceData>{
 const current=await readWorkspace();if(current.revision!==expectedRevision)throw Error('This workspace changed in another tab. Reload saved work and retry. Your input is preserved.');
 const result=await applyOperation(current.state,operation),revision=current.revision+1,created_at=new Date().toISOString();
 const event:HistoryEntry={id:crypto.randomUUID(),revision,summary:result.summary,created_at};const next:WorkspaceData={state:result.state,revision,history:[event,...current.history].slice(0,60)};
 const db=await database();if(!db){if(memory.revision!==expectedRevision)throw Error('This workspace changed. Reload and retry.');memory=structuredClone({...next,history:[event,...memory.history]});memoryHistory.set(revision,structuredClone(result.state));return next;}
 const {packed,assets}=await compact(result.state);
 await new Promise<void>((resolve,reject)=>{
  const tx=db.transaction(['current','history','assets'],'readwrite');let conflict=false;
  tx.oncomplete=()=>resolve();tx.onabort=()=>reject(Error(conflict?'This workspace changed in another tab. Reload saved work and retry.':'Your changes could not be saved. Export a backup before closing; your previous saved work is intact.'));tx.onerror=()=>{};
  const check=tx.objectStore('current').get('main');check.onsuccess=()=>{if((check.result?.revision||0)!==expectedRevision){conflict=true;tx.abort();return;}for(const [key,visual] of assets)tx.objectStore('assets').put(visual,key);tx.objectStore('current').put({revision,state:packed},'main');tx.objectStore('history').put({...event,state:packed});};
 });return next;
}
export function portableHtml(data:WorkspaceData,html=source):string{
 const embedded=JSON.stringify({workspaceId:crypto.randomUUID(),backup:backup(data.state,data.revision)}).replace(/</g,'\\u003c');
 const pattern=/<script\b(?=[^>]*\bid="aac-initial-state")[^>]*>[\s\S]*?<\/script>/;
 if(!pattern.test(html))throw Error('The original HTML could not be packaged. Download a JSON backup instead.');
 return html.replace(pattern,()=>`<script id="aac-initial-state" type="application/json">${embedded}</script>`);
}
export function saveHtmlCopy(data:WorkspaceData){download(`AAC_Studio_v${STUDIO_VERSION}_${new Date().toISOString().slice(0,10)}.html`,portableHtml(data),'text/html;charset=utf-8');}
