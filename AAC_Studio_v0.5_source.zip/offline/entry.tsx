import React from 'react';
import {createRoot} from 'react-dom/client';
import Workspace from './workspace';
class AppBoundary extends React.Component<{children:React.ReactNode},{failed:boolean}>{
 state={failed:false};static getDerivedStateFromError(){return {failed:true};}
 render(){if(this.state.failed)return <main style={{padding:40,fontFamily:'Arial'}}><h1>AAC Studio could not open</h1><p>Open the downloaded HTML file directly in a current version of Chrome or Edge.</p><p>Your previously saved browser data has not been deleted.</p><button onClick={()=>location.reload()}>Try again</button></main>;return this.props.children;}
}
createRoot(document.getElementById('root')!).render(<AppBoundary><Workspace/></AppBoundary>);
