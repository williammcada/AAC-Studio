CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`revision` integer NOT NULL,
	`summary` text NOT NULL,
	`created_at` text NOT NULL,
	`snapshot_key` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `events_revision_unique` ON `events` (`revision`);--> statement-breakpoint
CREATE TABLE `workspace` (
	`id` text PRIMARY KEY NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`snapshot_key` text,
	`updated_at` text NOT NULL
);
