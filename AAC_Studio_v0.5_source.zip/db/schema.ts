import {integer,sqliteTable,text} from 'drizzle-orm/sqlite-core';
export const workspace=sqliteTable('workspace',{id:text('id').primaryKey(),revision:integer('revision').notNull().default(0),snapshotKey:text('snapshot_key'),updatedAt:text('updated_at').notNull()});
export const events=sqliteTable('events',{id:text('id').primaryKey(),revision:integer('revision').notNull().unique(),summary:text('summary').notNull(),createdAt:text('created_at').notNull(),snapshotKey:text('snapshot_key').notNull()});
