"""Deterministic, auditable 4.4 -> 4.5 AAC Studio task repairs. Never edits student documents."""
import json, hashlib, pathlib, copy
ROOT=pathlib.Path(__file__).resolve().parents[1]
old_path=ROOT/'data/blueprint-4.4-original.json'
if not old_path.exists(): old_path.write_bytes((ROOT/'lib/seed.json').read_bytes())
old=json.loads(old_path.read_text()); s=copy.deepcopy(old); changes=[]
def update(key, reason, **fields):
    row=next(x for x in s['items'] if x['key']==key); before=copy.deepcopy(row)
    row.update(fields)
    if not row['legacy']:
        rule=s['taskRules'][row['taskRuleId']]
        for k,v in fields.items():
            if k in rule: rule[k]=v
        if 'dok' in fields: rule['dokMin']=rule['dokMax']=fields['dok']
    changes.append({'key':key,'reason':reason,'before':{k:before.get(k) for k in fields},'after':fields})
def task(key,reason,code,**fields):
    update(key,reason,structureCode=code,structureFamilyId='MATH45|'+code,source='AAC Studio 4.5 / task repair 2026-09-15',**fields)
task('5|4|6','Replace out-of-scope unit-fraction by unit-fraction division with sharing followed by a use from one share.','UNIT-SHARE-REMAINDER',
 action='Find the amount remaining in one equal share.',given='A unit-fraction length is shared equally among a whole-number group count. One recipient uses a stated fraction of a unit from that share; the remaining length is positive.',requiredResult='the length remaining in that recipient’s share',quantity='Linear',quantityDimension='Linear',responseProduct='One number with linear units',context='Neutral real-world',family='Short mathematical application',wordLimit=45,
 boundary='Divide a proper unit fraction by a positive whole number, then subtract a supplied smaller length from one share. Never divide one proper fraction by another. Both the sharing and subsequent use must be needed.')
task('5|8|11','Remove the repeated out-of-scope division task in Form 8.','UNIT-SHARE-TWO-STAGES',
 action='Find a share after two successive equal divisions.',given='A unit-fraction length is shared among a whole-number group count; each group divides its share into a supplied whole number of equal pieces.',requiredResult='the length of one final piece',quantity='Linear',quantityDimension='Linear',responseProduct='One number with linear units',context='Neutral real-world',family='Short mathematical application',wordLimit=45,
 boundary='Each division must be a unit fraction divided by a positive whole number. The two levels of sharing must be explicit and necessary; do not give their combined divisor.')
task('7|4|5','Differentiate the task from G6 V4 Q9 by using two inverse rate applications and adding their durations.','TRAVEL-TIME-TWO-LEGS',
 action='Find total travel time for two equal-distance stages.',given='A total distance is split into two equal distances. A different rational speed is supplied for each stage; neither stage time is given.',requiredResult='the combined travel time',quantity='Time',quantityDimension='Time',responseProduct='One number with time units',difficulty='Medium',
 boundary='Use exact rational arithmetic: halve the distance, find each stage time from distance and speed, and combine the times. State speed and requested time units clearly. Avoid rounding.')
update('7|4|1','Maintain the nonblocking difficulty target after redesigning Q5.',difficulty='Easy')
task('7|4|10','Separate rescaling a drawing from the single supplied-ratio conversion in G6 V4 Q15.','SCALE-REDRAW-LENGTH',
 action='Find a length when a drawing is reproduced at a new scale.',given='One length on an original drawing and two explicitly supplied scales for the original and new drawings; the actual length is not supplied.',requiredResult='the length on the new drawing',
 boundary='Use two distinct drawing scales with a common actual measurement unit. Require rescaling between drawings; do not supply the combined scale factor. No diagram is required.')
task('6|4|8','Retain four-option statistics MCQ without padding a binary classification with impossible labels.','STAT-QUESTION-SELECT',
 action='Select the statistical question from four questions.',given='Four concise questions about familiar quantities or populations; exactly one anticipates variability in data from a group. Variability is the only selection criterion.',requiredResult='the one statistical question',responseProduct='One MCQ selection (A–D); each option is a question.',
 boundary='Use four meaningful question options, one statistical and three nonstatistical. Do not add a second criterion such as numerical versus categorical data. No both/neither options or answer explanations.')
for key in ['7|4|7','7|5|5']:
 row=next(x for x in s['items'] if x['key']==key)
 update(key,'Separate the assessed response from unallocated graphing in the full standard.',boundary=('Use rational coefficients and a nonzero variable coefficient. Return only one solved inequality; no graph, written interpretation, or prescribed method.' if key.endswith('|7') else 'Use a strict linear inequality, an explicit integer domain, and a finite upper bound. Return only the greatest integer solution; no graph or written interpretation.'))
update('7|4|14','Count the quantitative distribution comparison.',comparison=True,comparisonCalculation=True)
for key in ['7|7|13','7|8|14']:
    update(key,'Count the same quantitative distribution comparison correctly in later forms.',comparison=True,comparisonCalculation=True)
task('7|7|6','Keep one comparison calculation after correctly counting the mean comparison at Q13.','UNIT-RATES-COMBINE',
 action='Find the combined rate of two simultaneous flows.',given='Two devices each deliver a fractional volume in a fractional time. They operate simultaneously at their constant individual rates.',requiredResult='the combined volume delivered per unit time',answerObject='Number',quantity='Rate',quantityDimension='Rate',responseProduct='One number with compound rate units',comparison=False,comparisonCalculation=False,context='Neutral real-world',family='Short mathematical application',wordLimit=45,variation='Direct versus multistep',
 boundary='Compute each fractional unit rate and add the simultaneous rates. Do not combine the elapsed times or compare the rates. Use exact no-calculator values.')
# Replace routine DOK-2 labels with routine DOK-1 labels, then restore the allocation
# through genuinely linked relationships rather than increasing arithmetic size.
for key in ['6|4|2','6|4|7','7|4|7','7|4|13']:
    update(key,'Calibrate routine translation/evaluation/solution/complement work as DOK 1.',dok=1)
task('6|4|5','Use two necessary constraints to support DOK 2; retain finite substitution, not general nonlinear equation solving.','TEST-EQUATION-AND-INEQUALITY',
 action='Select a candidate satisfying an equation and an inequality.',given='A small finite set of nonnegative candidates, one equation and one inequality. Exactly two candidates satisfy the equation, but exactly one of those also satisfies the inequality.',requiredResult='the candidate satisfying both conditions',dok=2,difficulty='Medium',comparison=True,
 boundary='Test only supplied candidates with Grade 6 arithmetic. Both conditions must eliminate a candidate. An expression such as x(10-x) is allowed with nonnegative intermediate values; do not require a general quadratic-solving method.')
task('6|4|10','Use a shared solution to link two one-step multiplication equations at DOK 2.','EQUATION-SHARED-SOLUTION',
 action='Find a coefficient that gives two equations the same solution.',given='One complete equation ax=b and a second equation cx=d with c unknown. The same nonnegative x satisfies both; a, b and d are supplied and nonzero.',requiredResult='the missing coefficient c',dok=2,
 boundary='Use exact nonnegative rational values. The first equation determines the common x; the second determines c. Require one numerical coefficient and no prescribed method.')
for key in ['6|4|1','6|4|4']:
    update(key,'Rebalance the nonblocking difficulty labels after revising the candidate task.',difficulty='Easy')
task('7|4|2','Require equivalence reasoning across distribution and a missing like term rather than a routine coefficient product.','DISTRIBUTE-MISSING-LIKE-COEFFICIENT',
 action='Find a missing coefficient in equivalent linear expressions.',given='An identity a(bx+c)+dx=ex+f valid for every x, with a, b, c, e and f supplied and d missing. The supplied constant satisfies f=ac.',requiredResult='the missing coefficient d',dok=2,
 boundary='Rational coefficients; all expressions remain linear. Distribution and matching the x-coefficients must both be necessary. Do not ask students to explain the equivalence.')
task('7|4|6','Require reconciliation of a per-unit rate with a grouped input variable at DOK 2.','PROPORTION-EQUATION-GROUPED-INPUT',
 action='Write a proportional equation when the input counts equal groups.',given='A unit rate, the fixed number of units in each group, and definitions: x counts groups while y measures the total output. Neither the group rate nor the equation coefficient is supplied.',requiredResult='one equation y=kx for the grouped input',dok=2,context='Neutral real-world',family='Short mathematical application',wordLimit=45,
 boundary='Define all variables and units. The given rate is per individual unit, whereas x counts groups; the coefficient must combine the rate and group size. Output only one equation.')
# Recover damaged source fields from the approved SF02 writeback, not from the later SF03 student document.
update('5|3|12','Recover the ordered-pair given/result from the approved writeback coordinate record, PDF page 2 (printed page 9).',
 given='A required coordinate-plane display with a point to identify as an ordered pair.',requiredResult='the ordered pair',source='G5_V3_writeback.pdf, PDF page 2 / printed page 9; approved SF02. Given/result transcription repaired 2026-09-15; student document not regenerated.')
update('6|3|6','Recover PAIRED_VALUE_TABLE and MISSING_OUTPUT from approved writeback, PDF page 1 (printed page 10).',
 given='An equivalent-ratio table containing paired values and one missing output.',requiredResult='the missing output',historicalStructureFamilyId='6-RP-A-3-EQUIVALENT-RATIO-TABLE__COMPLETE-ONE-MISSING-VALUE-IN-AN-EQUIVALENT-RATIO-TABLE__THE-MISSING-TABLE-VALUE__UNITLESS',source='G6_V3_writeback.pdf, PDF pages 1 and 3 / printed pages 10 and 13; approved SF02. Transcription repaired 2026-09-15.')
update('6|3|11','Recover value/benchmark and category selection from approved writeback, PDF page 2 (printed page 12).',
 given='One displayed signed value and a benchmark; select their comparison category.',requiredResult='the comparison category',source='G6_V3_writeback.pdf, PDF page 2 / printed page 12; approved SF02. Given/result transcription repaired 2026-09-15.')
s['blueprintVersion']='4.5.0';s['policyVersion']='1.1.0'
s['sourceFile']='AAC_BLUEPRINT_v4.4.xlsx plus reviewed AAC Studio 4.5 repair manifest'
s['repairVersion']='aac-studio-1.1';s['previousSeedHash']=old['seedHash']
s['referenceGuidance']={'7.EE.B.4':'The full standard includes graphing and contextual interpretation. This is reference context only: each AAC item assesses only its assigned objective response and binding content boundary.'}
s.pop('seedHash',None);s['seedHash']=hashlib.sha256(json.dumps(s,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
(ROOT/'lib/seed.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(ROOT/'data/studio-1.1-repairs.json').write_text(json.dumps({'version':'1.1','previousSeedHash':old['seedHash'],'newSeedHash':s['seedHash'],'changes':changes,'note':'SF02 writeback is controlling. Later SF03 DOCX files were inspected but not used to overwrite locked records.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'repairs':len(changes),'seedHash':s['seedHash']}))
