"""Read the verified workbook into an immutable application seed; never edit Excel."""
import json, zipfile, hashlib, xml.etree.ElementTree as E
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data/AAC_BLUEPRINT_v4.4.xlsx'
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
with zipfile.ZipFile(SOURCE) as z:
    strings=[''.join(x.itertext()) for x in E.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',NS)]
    rels={x.attrib['Id']:x.attrib['Target'].lstrip('/') for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    sheets={}
    for sh in E.fromstring(z.read('xl/workbook.xml')).findall('m:sheets/m:sheet',NS):
        t=rels[sh.attrib['{'+NS['r']+'}id']];t=t if t.startswith('xl/') else 'xl/'+t
        cells={}
        for c in E.fromstring(z.read(t)).findall('m:sheetData/m:row/m:c',NS):
            typ=c.get('t');v=c.findtext('m:v','',NS)
            if typ=='s':v=strings[int(v)] if v else ''
            elif typ=='inlineStr':v=''.join(c.find('m:is',NS).itertext())
            if typ=='e':raise ValueError('Source formula error: '+sh.attrib['name']+'!'+c.get('r'))
            cells[c.get('r')]=v
        sheets[sh.attrib['name']]=cells
def cell(s,c,r):return sheets[s].get(c+str(r),'')
def num(s,c,r):return int(float(cell(s,c,r) or 0))
claims=[]
for r in range(5,128):
    claims.append({'id':cell('03 Claim Specifications','A',r),'grade':num('03 Claim Specifications','B',r),'standard':cell('03 Claim Specifications','G',r),'text':cell('03 Claim Specifications','U',r),'scope':cell('03 Claim Specifications','AU',r)})
claim_by={x['id']:x for x in claims}
rules={}
for r in range(5,230):
    s='18 Task Rules';d={name:cell(s,col,r) for col,name in {'A':'id','B':'claimId','C':'standard','D':'structureCode','E':'action','F':'given','G':'requiredResult','H':'answerObject','I':'quantity','J':'responseMode','K':'visualPolicy','L':'representation','M':'context','N':'family','R':'statistics','S':'footprint','T':'variation','U':'boundary','AB':'quantityDimension','AC':'responseProduct','AF':'dokRationale'}.items()}
    d.update(dokMin=num(s,'O',r),dokMax=num(s,'P',r),wordLimit=num(s,'V',r),comparisonCalculation=bool(num(s,'AD',r)),comparison=bool(num(s,'AE',r)),expressionEligible=cell(s,'Q',r)=='Yes')
    d['responseMode']='mcq' if d['responseMode']=='Selected response' else 'shortAnswer'
    assert cell(s,'AA',r)=='PASS';rules[d['id']]=d
items=[]
for r in range(5,365):
    s='19 Effective Items';legacy=num(s,'C',r)<=3
    d={name:cell(s,col,r) for col,name in {'A':'key','G':'claimId','H':'standard','I':'action','J':'given','K':'requiredResult','L':'answerObject','M':'quantity','N':'responseMode','O':'visualPolicy','P':'representation','Q':'footprint','S':'structureCode','T':'structureFamilyId','W':'templateId','X':'surfaceFormId','Y':'historicalStructureFamilyId','AL':'quantityDimension','AN':'variation','AO':'difficulty','AP':'topic','AR':'cluster','AS':'bankRole','AT':'scope','AV':'taskRuleId'}.items()}
    d.update(grade=num(s,'B',r),form=num(s,'C',r),question=num(s,'D',r),dok=num(s,'R',r),legacy=legacy,metadataConfirmed=cell(s,'Z',r)=='PASS',source=cell('10 Accepted Items','Y',r) if legacy else 'AAC Blueprint 4.4 / reviewed task rule')
    d['responseMode']='mcq' if d['responseMode']=='Selected response' else 'shortAnswer'
    d['claim']=claim_by.get(d['claimId'],{}).get('text','Approved mean-total prerequisite override')
    if legacy:d.update(context='Locked final item',family='Locked final item',boundary='Retain the finalized item.',wordLimit=0,responseProduct=cell('10 Accepted Items','R',r),comparisonCalculation=False,comparison=False,statistics='None',expressionEligible=False)
    else:
        rule=rules[d['taskRuleId']]
        for key in ['context','family','boundary','wordLimit','responseProduct','comparisonCalculation','comparison','statistics','expressionEligible']:d[key]=rule[key]
        assert cell(s,'AJ',r)=='PASS'
    items.append(d)
clusters=[]
for r in range(5,100):
    if cell('02 Cluster Blueprint','A',r) in ['5','6','7']:clusters.append({'grade':num('02 Cluster Blueprint','A',r),'code':cell('02 Cluster Blueprint','D',r),'min':num('02 Cluster Blueprint','K',r),'max':num('02 Cluster Blueprint','L',r)})
source_issues=json.loads((ROOT/'data/source-issues.json').read_text())
seed={'schema':'aac.blueprint.v1','projectId':'AAC-2026-27','blueprintVersion':'4.4.0','policyVersion':'1.0.0','schoolYear':'2026–27','sourceFile':'AAC_BLUEPRINT_v4.4.xlsx','sourceSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'claims':claims,'clusters':clusters,'items':items,'taskRules':rules,'sourceIssues':source_issues}
seed['seedHash']=hashlib.sha256(json.dumps(seed,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(items)==360 and sum(x['legacy'] for x in items)==135 and len(rules)==225 and len(claims)==123
assert next(x for x in items if x['key']=='7|1|6')['structureCode']=='MEAN-TOTAL'
dest=Path(__file__).resolve().parents[1]/'lib/seed.json';dest.parent.mkdir(exist_ok=True);dest.write_text(json.dumps(seed,ensure_ascii=False,indent=2))
print(json.dumps({'items':len(items),'finalized':135,'planned':225,'claims':len(claims),'openSources':len(seed['sourceIssues']),'seedHash':seed['seedHash']}))
