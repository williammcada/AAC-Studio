import json,copy,hashlib,pathlib
R=pathlib.Path(__file__).resolve().parents[1]
old=json.loads((R/'data/blueprint-4.6-original.json').read_text());s=copy.deepcopy(old);changes=[]
def row(k):return next(x for x in s['items'] if x['key']==k)
def update(k,reason,**fields):
 r=row(k);before={x:r.get(x) for x in fields};r.update(fields);changes.append(dict(key=k,reason=reason,before=before,after=fields))
def task(k,code,action,given,result,**fields):
 fields.setdefault('boundary',given+' Return only '+result+'. No additional response or prescribed method.');fields.setdefault('context','Pure mathematics');fields.setdefault('wordLimit',20)
 update(k,'Complete future-facing task relationship.',structureCode=code,structureFamilyId='MATH47|'+code,action=action,given=given,requiredResult=result,**fields)
def claim(k,c):
 c=next(x for x in s['claims'] if x['id']==c);update(k,'Reallocate claim coverage with matching construct.',claimId=c['id'],claim=c['text'],standard=c['standard'],scope=c['scope'])
# Fully specified later designs supply the starting point; no historical row is edited.
for g in [5,6,7]:
 for f,src in [(1,5),(2,6),(3,7)]:
  for q in range(1,16):
   oldr=copy.deepcopy(row(f'{g}|{f}|{q}'));r=copy.deepcopy(row(f'{g}|{src}|{q}'));r.update(key=oldr['key'],grade=g,form=f,question=q,templateId='',surfaceFormId='',historicalStructureFamilyId='',source=f'Fresh 4.7 design; family adapted from G{g} V{src} Q{q}; historical item not replaced.',metadataConfirmed=True,legacy=False)
   target=row(oldr['key']);target.clear();target.update(r);changes.append(dict(key=r['key'],reason='Replace incomplete future-year allocation; preserve archived final.',before=oldr,after=copy.deepcopy(r)))
# Missing claims are deliberate allocations with their actual response as evidence.
claim('5|1|1','G5-006');task('5|1|1','PLACE-ADJACENT-FACTOR','Find the multiplicative place-value factor.','The same nonzero digit occurs in two adjacent place-value positions; the larger value is compared with the smaller.','the multiplicative factor',dok=1)
claim('5|2|7','G5-004');task('5|2|7','PATTERN-CORRESPONDING-PAIR','Find the corresponding ordered pair in two patterns.','Two stated additive whole-number rules, starting values, and a common term position.','the pair of values at that position',answerObject='Ordered pair',quantity='Location',cluster='5.OA.B',visualPolicy='Prohibited',representation='None',dok=2,context='Pure mathematics',wordLimit=20)
claim('5|3|14','G5-034');task('5|3|14','CUBE-LAYERS-COUNT','Count unit cubes in a layered solid.','A unit-square layer plan and explicit numbers of identical complete layers for two adjoining stacks; no cube count is supplied.','the total unit-cube count',answerObject='Number',quantity='Cubic',visualPolicy='Required',representation='Unit Cube Model',footprint='Large Visual',dok=2)
claim('6|1|1','G6-010');task('6|1|1','GCF-DIRECT','Find the greatest common factor.','Two positive whole numbers at most 100.','their greatest common factor',dok=1)
claim('6|2|1','G6-008');task('6|2|1','WHOLE-DIVISION-QUOTIENT','Find the whole-number quotient.','A multidigit positive whole-number dividend and two-digit divisor with zero remainder.','the quotient',dok=1)
claim('6|1|4','G6-014');task('6|1|4','QUADRANT-FROM-PAIR','Identify the quadrant of an ordered pair.','A signed ordered pair with neither coordinate zero.','the quadrant label',answerObject='Label',quantity='Category',dok=1)
claim('6|2|4','G6-032');task('6|2|4','COORD-SIDE-LENGTH','Find one axis-aligned polygon side length.','A polygon is specified by ordered-pair vertices; the requested side has endpoints sharing one coordinate.','the side length',visualPolicy='Prohibited',representation='None',footprint='Compact',cluster='6.G.A',dok=1)
# Swap the original geometry slot into the second signed-number slot to retain quotas.
claim('6|2|13','G6-017');task('6|2|13','ABS-CONSTRAINED-NUMBER','Find a number satisfying magnitude and signed-order conditions.','Four rational candidates; exactly two satisfy an absolute-value condition and exactly one of those satisfies a signed-order condition.','the unique candidate',answerObject='Number',quantity='Unitless',visualPolicy='Prohibited',representation='None',footprint='Compact',cluster='6.NS.C',comparison=True,comparisonCalculation=False,dok=2)
claim('6|3|13','G6-030');task('6|3|13','POLYGON-DECOMPOSE-AREA','Find the area of a composite polygon.','An L-shaped polygon has all outer horizontal and vertical lengths; one needed inner length is inferred by subtraction.','the area',quantity='Square',representation='Composite Area Diagram',dok=2)
claim('6|1|12','G6-036');task('6|1|12','MEDIAN-SORTED-DATA','Find the median of an unsorted data set.','Six integer observations given as a necessary dot plot.','the median',statistics='Numeric',dok=1)
claim('6|2|14','G6-039');task('6|2|14','DISTRIBUTION-RANGE-FROM-DISPLAY','Find the range of a distribution.','A dot plot with repeated integer observations and a labeled scale.','the numerical range',answerObject='Number',quantity='Unitless',statistics='Numeric',responseMode='shortAnswer',representation='Statistical Graph',visualPolicy='Required',footprint='Compact',dok=1)
claim('7|1|3','G7-003');task('7|1|3','PROPORTIONALITY-CONSTANT','Find the constant of proportionality.','A ratio table explicitly relates y to x with nonzero inputs; the unit-input pair is absent.','the constant k in y=kx',answerObject='Number',quantity='Unitless',responseMode='shortAnswer',dok=1)
claim('7|1|13','G7-034');task('7|1|13','UNIFORM-EVENT-PROBABILITY','Find an event probability in a uniform model.','Equally likely numbered outcomes and one condition describing the event.','the exact probability',quantity='Probability',dok=1)
claim('7|2|3','G7-038');task('7|2|3','SIMULATION-EVENT-ESTIMATE','Estimate a probability from simulation results.','A complete simulation frequency table and an event combining two outcome categories.','the event frequency divided by total simulated trials',answerObject='Number',quantity='Probability',visualPolicy='Required',representation='Statistical Organizer',footprint='Compact',dok=2)
claim('7|2|13','MANUAL-G7-F1-Q06');task('7|2|13','MEAN-TO-TOTAL','Find a total from a mean and number of values.','A mean and a positive integer number of observations.','the total sum',cluster='Prerequisite',statistics='Numeric',dok=1)
s['clusters'].append(dict(grade=7,code='Prerequisite',min=0,max=1))
# Future prerequisite coverage is explicit and does not replace required ratio standards.
# Additional repair overrides are stored separately for readable review.
for change in json.loads((R/'data/v03/task-overrides.json').read_text()):
 k=change.pop('key');reason=change.pop('reason','V0.3 mathematical and workload repair.');update(k,reason,**change)
# Seed finalization occurs after evidence authoring.
for r in s['items']:
 r.update(taskRuleId='TASK47-'+r['key'],metadataConfirmed=True,legacy=False,templateId='',surfaceFormId='')
 r['responseProduct']='One MCQ selection (A–D)' if r['responseMode']=='mcq' else 'One '+r['answerObject'].lower()+'; quantity: '+r['quantity']+'. Put unit words in the prompt.'
 r['quantityDimension']=r['quantity'];r['boundary']=r.get('boundary','')
 s['taskRules'][r['taskRuleId']]={k:r[k] for k in ['claimId','standard','action','given','requiredResult','answerObject','quantity','responseMode','visualPolicy','representation','context','family','boundary','variation','statistics','wordLimit','footprint','structureCode']};s['taskRules'][r['taskRuleId']].update(dokMin=r['dok'],dokMax=r['dok'])
s.update(blueprintVersion='4.7.0',policyVersion='1.3.0',repairVersion='aac-studio-0.3',previousSeedHash=old['seedHash'],sourceFile='AAC Studio 0.3 complete current-design bank; immutable historical archives retained')
s.pop('seedHash',None);s['seedHash']=hashlib.sha256(json.dumps(s,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
(R/'work/v03/candidate.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(R/'data/v03/change-manifest.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
print('Candidate bank:',len(s['items']))
