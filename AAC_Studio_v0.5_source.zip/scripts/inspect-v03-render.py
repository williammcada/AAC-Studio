import pathlib,json,fitz,re,zipfile,xml.etree.ElementTree as E
from PIL import Image,ImageDraw
R=pathlib.Path(__file__).resolve().parents[1];out=R/'work/v03/contact';out.mkdir(exist_ok=True);report=[]
for folder in sorted((R/'work/v03/render').glob('G?_V?')):
 pdf=folder/(folder.name+'.pdf')
 if not pdf.exists():continue
 doc=fitz.open(pdf);boundary=[];student=0
 for i,p in enumerate(doc):
  t=p.get_text()
  # Render the verified PDF page atomically; avoids partial PNG writes from concurrent converter workers.
  target=folder/f'page-{i+1}.png';tmp=folder/f'page-{i+1}.tmp.png';p.get_pixmap(matrix=fitz.Matrix(1.7,1.7)).save(tmp);tmp.replace(target)
  if 'Answer key' in t and student==0:student=i
  for b in p.get_text('blocks'):
   if b[0]<25 or b[1]<20 or b[2]>p.rect.width-20 or b[3]>p.rect.height-20:boundary.append((i+1,b[:4],b[4][:50]))
 pages=[folder/f'page-{n}.png' for n in range(1,len(doc)+1)]
 for label,part in [('student',pages[:student]),('teacher',pages[student:])]:
  cols=2 if label=='student' else 3;thumbw=650 if label=='student' else 440;thumbh=round(thumbw*11/8.5);gap=18;rows=(len(part)+cols-1)//cols
  sheet=Image.new('RGB',(cols*(thumbw+gap),rows*(thumbh+gap+28)), '#d8e0e4');d=ImageDraw.Draw(sheet)
  for j,path in enumerate(part):
   im=Image.open(path).convert('RGB');im.thumbnail((thumbw,thumbh));x=(j%cols)*(thumbw+gap);y=(j//cols)*(thumbh+gap+28);d.text((x+8,y+5),folder.name+' '+path.stem,fill='black');sheet.paste(im,(x,y+25))
  sheet.save(out/f'{folder.name}_{label}.jpg',quality=88)
 with zipfile.ZipFile(R/'work/v03/qa'/f'{folder.name}.docx') as z:
  root=E.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
  text=' '.join(root.itertext());frac=len(root.findall('.//m:f',ns));media=len([n for n in z.namelist() if n.startswith('word/media/')]);sections=[x in text for x in ['Answer key','Worked solutions','Item review','Proposed item identifiers']]
 report.append(dict(form=folder.name,pages=len(doc),studentPages=student,nativeFractions=frac,embeddedFigures=media,allTeacherSections=all(sections),boundaryIssues=boundary))
(R/'docs/releases/0.3-render-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Forms',len(report),'pages',sum(x['pages'] for x in report),'boundary issues',sum(len(x['boundaryIssues']) for x in report));print('Contact sheets:',out)
