"""Deterministic v0.5 contract migration. Run against preserved v0.4, never mutable seed."""
import copy, hashlib, json, pathlib, re
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix
R=pathlib.Path(__file__).resolve().parents[1]
def read(p):return json.loads((R/p).read_text())
def save(p,v):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
if not (R/'data/blueprint-4.8-original.json').exists():save('data/blueprint-4.8-original.json',read('lib/seed.json'))
s=read('data/blueprint-4.8-original.json');old=copy.deepcopy(s);pool=read('data/v04/task-catalog.json');prior=read('data/v04/allocation-evidence.json');manifest=[]
# One policy record for each approved semantic core, including aliases.
semantics={}
for r in pool:
 k=r['semanticKey'];v=semantics.setdefault(k,{'comparison':False,'comparisonCalculation':False})
 for field in v:v[field]=v[field] or r[field]

def repair(r):
 before=copy.deepcopy(r);c=r['structureCode'];g=r['grade'];rules=[]
 # Strip previously serialized rules before rebuilding from operation-specific policies.
 for rule in r.get('domainRules',[]):r['given']=r['given'].replace(rule,'').strip()
 for rule in r.get('domainRules',[]):
  if not re.search(r'divisor/group/portion|maximum COMPLETE|within the assigned standard boundary|unique solution is nonnegative',rule):rules.append(rule)
 r.update(semantics[r['semanticKey']])
 r['originalStandard']=r.get('originalStandard',r['standard']);r['originalClaim']=r.get('originalClaim',r['claim'])
 r['standard']=r['standard'].replace('6.SP.B.5c','6.SP.B.5.c')
 r['evidenceType']='prerequisite' if r['scope']=='Approved Prerequisite Review' else 'direct';r['evidenceNote']='Evidence is limited to the assigned action; no full-standard mastery claim.'
 r['coordinatePlanes']=1 if r['representation'] in ['Coordinate Plane','Proportional Graph'] else 0
 r['candidateDelivery']='stem-number-bank' if r['responseMode']=='shortAnswer' and re.search(r'candidate|choice set|numerical selection',r['given']+' '+r['requiredResult'],re.I) else 'none'
 r['outputForm']='generic'
 if r['answerObject']=='Comparison symbol':r['outputForm']='comparison-three'
 if r['answerObject']=='Expression' and (g==5 or c=='TRANSLATE-EXPONENTIAL'):r['outputForm']='numerical-expression'
 if r['answerObject']=='Inequality':r['outputForm']='strict-solved-inequality'
 if r['answerObject']=='Ratio':r['outputForm']='positive-simplest-ratio'
 if c=='FRACTION-TO-DECIMAL':r['outputForm']='terminating-decimal'
 if c in ['PROPORTION-EQUATION-GROUPED-INPUT','PROPORTION-REVERSE-EQUATION']:r['outputForm']='y=kx'
 if c=='MEAN-TO-TOTAL':
  r['quantity']='Unitless';r['given']='A signed rational mean and a positive integer number of observations; the total sum is unknown.'
  rules.append('The observation count is a positive integer. The sum equals mean times count and may be negative or nonintegral; the sum is not a count.')
 if c=='WHOLE-QUOTIENT-ROW-GROUPS':
  r['quantity']='Count';r['given']='Only the positive integer row count, objects per row and two-digit new group size are supplied. The total number of objects is not supplied.'
  r['requiredResult']='the exact integer number of new groups'
  rules.append('The derived total is at most 9999; the group size is an integer from 10 to 99. The total is exactly divisible by the new group size; do not floor or round.')
 if c=='EXPRESSION-RELATION':r['given']=re.sub(r'[,;]?\s*do not evaluate either\.?','',r['given'],flags=re.I)
 if c=='COMPARE-UNIT-RATES':r['given']=re.sub(r'[,;]?\s*calculate both rates before comparing\.?','',r['given'],flags=re.I)
 if c in ['UNIT-RATE','UNIT-RATE-DIFFERENCE']:
  r['requiredResult']='the numerical unit rate in the compound units stated in the stem' if c=='UNIT-RATE' else 'the nonnegative numerical difference between the two rates in the compound units stated in the stem'
  rules.append('All denominator quantities are positive. Put compound units in the stem; the answer and accepted equivalents contain only numbers, never unit words.')
  if c=='UNIT-RATE-DIFFERENCE':rules.append('The difference means the larger rate minus the smaller rate, regardless of the order presented.')
 exact_div={'DIVIDE-REMAINDER-PORTION','DIVIDE-TOTAL-PORTIONS','FRACTION-QUOTIENT-UNIT-CONVERSION','DECIMAL-QUOTIENT-COMBINED-LENGTH','DECIMAL-QUOTIENT-REMAINDER-LENGTH','REMAINING-UNIT-PORTION-COUNT','UNIT-DIV-PORTIONS','UNIT-DIV-TWO-PORTION-SIZES'}
 if r['quantity']=='Count':
  rules.append('The required answer is a nonnegative integer count within the supplied collection or event range.')
  if c in exact_div:rules.append('Portion size is positive; the usable total is nonnegative and exactly divisible by the portion size. No rounding or floor interpretation.')
 if c=='RATIONAL-BUDGET-COUNT':rules.append('The usable budget is nonnegative and price per group is positive. Ask for the maximum COMPLETE groups; explicitly state the floor interpretation in the stem.')
 if c=='SUBTRACT-THEN-MULTIPLY':rules.append('Removal is between zero and the whole collection; the fraction is in [0,1] and its product with the remainder is an integer.')
 if c=='DECIMAL-PRODUCT-DERIVED-FACTOR':rules.append('Length L is positive; reduction d satisfies 0<d<L; width L-d is positive. Decimal operands have at most two decimal places.')
 if c=='COMPOSITE-MISSING-VOLUME':rules.append('Prisms are nonoverlapping with positive whole-number edges; total volume exceeds the known component volume and all dimensions fit the diagram.')
 if g==5 and c in ['PLOT-TOTAL','PLOT-FREQUENCY']:rules.append('Measurements use halves, fourths or eighths of the named unit; frequencies are nonnegative integers and the display contains all observations.')
 if g==5 and c in ['WHOLE-QUOTIENT-REMAINDER','WHOLE-QUOTIENT-ROW-GROUPS']:rules.append('Whole-number dividend is at most 9999 and divisor is from 10 to 99; a remainder, when assigned, is smaller than the divisor.')
 if g==5 and c=='DIV-QUOTIENT':rules.append('Dividend and divisor have at most two decimal places; divisor is nonzero and quotient is terminating. No unstated rounding.')
 if c=='LCM':rules.append('Both inputs are positive integers no greater than 12.')
 if c=='GCF-FACTOR-BLANK':rules.append('Both whole-number addends are between 1 and 100 inclusive.')
 if c=='PERCENT-WHOLE':rules.append('The percentage and supplied part are strictly positive so the whole is uniquely determined.')
 if c in ['PERCENT-PART-REMAINDER','PERCENT-EQUIVALENT-DECREASE','PERCENT-DISCOUNT-THEN-FEE']:rules.append('Reduction/used percentage is between 0 and 100 inclusive; remaining physical quantities are nonnegative.')
 if c=='PERCENT-ORIGINAL':rules.append('The remaining multiplier is strictly positive; a decrease is less than 100 percent; the recovered original amount is positive.')
 if c=='SIMPLE-INTEREST-PRINCIPAL':rules.append('Interest, rate and time are strictly positive; time and rate use compatible periods, and time is a positive whole number.')
 if c=='PERCENT-SUCCESSIVE':rules.append('Starting amount is positive; each decrease lies between 0 and 100 percent, and each multiplier is nonnegative.')
 if c=='PERCENT-CHANGE':rules.append('The starting quantity is positive; specify increase or decrease and return its nonnegative percentage magnitude.')
 if c=='RATIO-TABLE-INPUT':rules.append('The reference input and output are strictly positive; the ratio is fixed and the missing input is uniquely determined.')
 if c=='RATE-TWO-STAGES':rules.append('Both durations are positive, consecutive and nonoverlapping. Use compatible quantity/time units; overall rate is total quantity divided by total elapsed time.')
 if c=='UNIT-RATES-COMBINE':rules.append('Durations are positive, units compatible, and outputs add over the same stated time interval without overlap or loss.')
 if c=='TRAVEL-TIME-TWO-LEGS':rules.append('Both speeds and leg distances are positive and in compatible units; total travel time is the sum of both leg times.')
 if c=='UNIT-RATE-CONVERT':rules.append('Denominator quantity and conversion factor are strictly positive; explicitly state conversion direction and target compound units.')
 if c=='RATIONAL-WEIGHTED-TOTAL':rules.append('Indivisible object counts must be whole numbers. Fractional quantities must be explicitly measured amounts in compatible units.')
 if c=='PRISM-VOLUME-EXTENDED-EDGE':rules.append('All edges and the extension are positive and expressed in compatible length units.')
 if c=='NET-ADD-FACES':rules.append('All dimensions are positive; shared net edges agree. Any triangle altitude is numerically compatible with its side lengths, perpendicular to the named base.')
 if c=='ADJACENT-LINEAR-ANGLE-SOLVE':rules.append('For angles ax+b and cx+d, a+c is nonzero; the unique solution gives both angles strictly between 0 and 180 degrees and their sum is 180. The diagram agrees.')
 if c=='SCALE-REDRAW-LENGTH':rules.append('Both scales and all lengths are positive; explicitly define drawing-to-actual scale direction and use compatible units.')
 if c=='CIRCLE-CIRCUMFERENCE':
  rules.append('Radius is positive. Request exact circumference in terms of pi; do not accept decimal approximations as exact equivalents.')
  r['given']=re.sub(r'(?:symbolic pi|pi|π).*?(?:approximation|approximate)[^.]*\.?','exact pi notation',r['given'],flags=re.I);r['outputForm']='exact-pi'
 if c=='RATE-TOTAL-DIFFERENCE':rules.append('Starting physical amount is nonnegative, rates and durations are positive, and combined uses do not exceed the start; ask for the remaining amount.')
 if c in ['EMPIRICAL-PROBABILITY','SIMULATION-EVENT-ESTIMATE','COMPOUND-COUNT','COMPOUND-PROBABILITY']:
  rules.append('Outcome categories form a complete, nonoverlapping partition. Frequencies are nonnegative integers; total trials/sample-space size is positive and equals the sum of category counts.')
 if c in ['TRIAL-PREDICT-FREQUENCY','SAMPLE-POPULATION-ESTIMATE']:rules.append('Positive observed and target totals; observed count lies within its total; prediction lies within the target total. Choose values yielding an exact integer prediction; no implicit rounding.')
 if c in ['TEST-TWO-CONDITIONS','TEST-EQUATION-AND-INEQUALITY']:
  rules.append('Use exactly four distinct whole-number candidates from 0 to 12. Equation is nontrivial, uses +, -, multiplication and at most a square, integer constants with magnitude at most 144 and at most three operations per side. Exactly two candidates satisfy the equation, at least one fails it, and exactly one of the two satisfies the independent strict inequality. No quadratic-solving method is required.')
  r['candidateDelivery']='stem-number-bank'
 if c=='EQUATION-COEFFICIENT-MODEL':rules.append('Known multiplicative factors are positive and the model coefficient is uniquely determined; the coefficient is not an equation-solution domain by default.')
 if c=='EQUATION-SHARED-SOLUTION':rules.append('All multiplicative coefficients and denominators are positive; the shared solution is nonnegative.')
 if c=='DATA-MISSING-FREQUENCY':
  r['claim']='Determine a missing frequency from a frequency table and total observation count.';r['evidenceType']='supporting';r['evidenceNote']='Frequency reasoning supports data work; this table-only task does not directly assess 6.SP.B.4 plotting.'
  rules.append('Known frequencies are nonnegative integers whose sum does not exceed the positive total; the missing frequency is total minus their sum.')
 if c in ['DISTRIBUTION-MEDIAN','MEDIAN-SORTED-DATA'] and g==6:
  r['claim']='Calculate the median of the supplied numerical observations.';r['evidenceType']='supporting';r['evidenceNote']='Direct calculation reference: 6.SP.B.5.c. Supporting evidence only for the original conceptual standard; does not establish full distribution understanding.'
 if c=='MEDIAN-SORTED-DATA':r['action']='Find the median from a dot plot.'
 if c in ['COMPARE-MEANS','COMPARE-MEDIANS']:
  r['claim']='Calculate the nonnegative difference between two '+('means.' if c=='COMPARE-MEANS' else 'medians.')
  r['evidenceType']='supporting';r['evidenceNote']='Narrow center calculation supporting 7.SP.B.4; no claim to directly assess random-sample variability or population inference.'
  r['requiredResult']='the nonnegative difference between the two centers';rules.append('Compute the larger center minus the smaller center; both data sets are nonempty.')
 if c=='MEDIAN-GAP-IN-SPREADS':
  r['given']='Two necessary same-scale dot plots provide all observations. Infer each median and their shared positive interquartile range from the plots; centers and spread are not separately supplied.'
  rules.append('Use at least six observations per distribution. For quartiles, take medians of the lower and upper halves, excluding the overall middle observation for odd sizes; state this convention. Both computed IQRs are equal and positive. Normalize the nonnegative median gap by this common IQR.')
 if c=='DECIMAL-CLASSIFY':
  r['claimId']='G7-014-CLASSIFY';r['claim']='Classify a rational decimal expansion as terminating or nonterminating repeating.'
  r['given']='One reduced fraction with positive denominator; classify its decimal expansion using the convention that terminating takes precedence over trailing-zero or trailing-nine representations.'
  r['requiredResult']='terminating or nonterminating repeating';r['outputForm']='decimal-classification'
 if c=='PROPORTION-CLASSIFY' and r['representation']=='Proportional Graph':
  r['given']='One necessary shared Cartesian axes panel contains four distinct curves labeled A, B, C, D. Exactly one is a straight line through the origin; the others are nonlinear or do not pass through the origin.'
  rules.append('Use ONE axes panel, not four mini-graphs. Labels A–D identify curves unambiguously with distinct grayscale line patterns. Choice strings are Curve A, Curve B, Curve C, Curve D. All four curves are readable at print size.')
 # Only explicit story/context requirements force narrative budgets.
 if re.search(r'neutral (?:context|situation|statement|joining|map)|short (?:joining|neutral)|contextual|real.world|word problems|travel|collection|starting physical',r['given']+' '+r['claim'],re.I) or c.startswith('FACTOR-CONTEXT') or c in ['PERCENT-EQUIVALENT-DECREASE','PERCENT-EQUIVALENT-MULTIPLIER','PERCENT-DISCOUNT-THEN-FEE','PERCENT-SUCCESSIVE','TRAVEL-TIME-TWO-LEGS']:
  r['context']='Neutral context'
 r['wordLimit']=45 if r['context']=='Neutral context' else 20
 if 'real-world' in r['claim'].lower() or 'word problems' in r['claim'].lower():rules.append('Use a concise neutral real-world situation realizing the stated claim.')
 r['domainRules']=list(dict.fromkeys(rules));r['given']=r['given'].strip()
 r['quantityDimension']=r['quantity'];r['structureFamilyId']='MATH49|'+r['semanticKey']
 r['responseProduct']='One MCQ selection (A–D)' if r['responseMode']=='mcq' else 'One '+r['answerObject'].lower()+'; answer domain: '+r['quantity']+'.'
 if c=='CUBIC-UNIT-IDENTIFY':r['responseProduct']='One cubic-unit label; unit words are the answer.'
 r['boundary']=r['given']+' '+' '.join(r['domainRules'])+' Return only '+r['requiredResult']+'. No additional response or prescribed method.'
 r['reviewStatus']='Contract reviewed; realized mathematics, cognitive demand and visual semantics require educator review.'
 manifest.append({'catalogId':r['catalogId'],'before':before,'after':copy.deepcopy(r)})
for r in pool:repair(r)
save('data/v05/task-catalog.json',pool);save('data/v05/semantic-policy.json',semantics)
# Minimize allocation changes while enforcing the original constraints consistently.
variables=[(i,f) for i in range(len(pool)) for f in range(1,9)];lookup={v:n for n,v in enumerate(variables)};rows=[];lo=[];hi=[]
def constrain(indices,a,b):rows.append(indices);lo.append(a);hi.append(b)
def ids(test,forms):return [lookup[i,f] for i,r in enumerate(pool) if test(r) for f in forms]
for g in [5,6,7]:
 for f in range(1,9):
  gf=lambda r:r['grade']==g
  constrain(ids(gf,[f]),15,15)
  for c in s['clusters']:
   if c['grade']==g:constrain(ids(lambda r:gf(r) and r['cluster']==c['code'],[f]),c['min'],c['max'])
  for d,a,b in [(1,4,6),(2,8,10),(3,0,1)]:constrain(ids(lambda r:gf(r) and r['dok']==d,[f]),a,b)
  for field,val,b in [('responseMode','mcq',2),('comparison',True,2),('comparisonCalculation',True,1),('footprint','Large Visual',3)]:constrain(ids(lambda r:gf(r) and r[field]==val,[f]),0,b)
  constrain(ids(lambda r:gf(r) and r['answerObject']=='Expression' and r['responseMode']=='shortAnswer',[f]),0,1)
  for c in {r['claimId'] for r in pool if gf(r)}:constrain(ids(lambda r:gf(r) and r['claimId']==c,[f]),0,1)
  if g==7:
   for st in ['7.RP.A.1','7.RP.A.2','7.RP.A.3']:constrain(ids(lambda r:gf(r) and r['standard']==st,[f]),1,1)
  for k in {r['semanticKey'] for r in pool if gf(r)}:constrain(ids(lambda r:gf(r) and r['semanticKey']==k,[f,f%8+1]),0,1)
for c in {r['claimId'] for r in pool}:constrain(ids(lambda r:r['claimId']==c,range(1,9)),1,8)
for f in range(1,9):
 for grades in [[5,6],[7]]:constrain(ids(lambda r:r['grade'] in grades and r['coordinatePlanes']>0,[f]),0,1)
 for a,b in [(5,6),(6,7)]:
  for k in {r['semanticKey'] for r in pool}:constrain(ids(lambda r:r['grade'] in [a,b] and r['semanticKey']==k,[f]),0,1)
A=lil_matrix((len(rows),len(variables)))
for j,row in enumerate(rows):A[j,row]=1
preferred={(e['catalogId'],int(key.split('|')[1])) for key,e in prior.items()}
objective=np.array([0 if (pool[i]['catalogId'],f) in preferred else 100 for i,f in variables],float)+np.array([((i*31+f*17)%97)/10000 for i,f in variables])
result=milp(objective,integrality=np.ones(len(variables)),bounds=Bounds(0,1),constraints=LinearConstraint(A.tocsr(),lo,hi),options={'time_limit':60,'mip_rel_gap':.001})
print(result.message,flush=True)
if result.x is None:raise SystemExit('No feasible bank; no activation')
assert np.all(A@result.x>=np.array(lo)-1e-6) and np.all(A@result.x<=np.array(hi)+1e-6)
items=[];evidence={};alloc=[]
for g in [5,6,7]:
 for f in range(1,9):
  group=[copy.deepcopy(pool[i]) for j,(i,ff) in enumerate(variables) if ff==f and pool[i]['grade']==g and result.x[j]>.5]
  positioned={};new=[]
  for r in group:
   key=next((k for k,e in prior.items() if e['catalogId']==r['catalogId'] and k.startswith(f'{g}|{f}|')),None)
   if key:positioned[int(key.split('|')[2])]=r
   else:new.append(r)
  for r in sorted(new,key=lambda r:(r['footprint']!='Large Visual',r['catalogId'])):
   available=[q for q in range(1,16) if q not in positioned and (r['footprint']!='Large Visual' or 12<=q<=14)]
   if not available:raise RuntimeError('Position allocation needs review')
   positioned[available[0]]=r
  for q,r in sorted(positioned.items()):
   key=f'{g}|{f}|{q}';r.update(key=key,form=f,question=q,taskRuleId='TASK49-'+key,source='V0.5 repaired catalog '+r['catalogId'])
   oldrow=next(x for x in old['items'] if x['key']==key)
   if prior[key]['catalogId']!=r['catalogId']:alloc.append({'key':key,'before':oldrow['structureCode'],'after':r['structureCode'],'catalogId':r['catalogId']})
   olde=next((e for e in prior.values() if e['catalogId']==r['catalogId']),None)
   if not olde:
    olde=next(e for e in read('data/v03/allocation-evidence.json').values() if e['catalogId']==r['catalogId'])
   evidence[key]={**copy.deepcopy(olde),'catalogId':r['catalogId'],'semanticKey':r['semanticKey'],'structureCode':r['structureCode'],'claimId':r['claimId'],'given':r['given'],'dok':r['dok'],'dokRationale':r['dokRationale'],'claimEvidence':r['claim']+' '+r['evidenceNote'],'reviewBasis':r['reviewStatus']}
   for k in ['catalogId','sourceSlot','semanticKey','dokRationale']:r.pop(k,None)
   evidence[key]['contract']={k:v for k,v in r.items() if k not in ['key','form','question','templateId','surfaceFormId','source']}
   items.append(r)
s.update(items=items,blueprintVersion='4.9.0',policyVersion='1.5.0',repairVersion='aac-studio-0.5',previousSeedHash=old['seedHash'],sourceFile='AAC Studio v0.5 deterministic audit repairs; historical records immutable')
cl=copy.deepcopy(next(c for c in s['claims'] if c['id']=='G7-014'));cl.update(id='G7-014-CLASSIFY',text='Classify a rational decimal expansion as terminating or nonterminating repeating.');s['claims'].append(cl)
for c in s['claims']:c['standard']=c['standard'].replace('6.SP.B.5c','6.SP.B.5.c')
s['taskRules']={r['taskRuleId']:{**evidence[r['key']]['contract'],'dokMin':r['dok'],'dokMax':r['dok']} for r in items}
s.pop('seedHash',None);s['seedHash']=hashlib.sha256(json.dumps(s,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
save('data/v05/allocation-evidence.json',evidence);save('data/v05/change-manifest.json',manifest);save('data/v05/reallocation.json',alloc);save('lib/seed.json',s)
print('Activated',len(items),'rows;',len(s['claims']),'claims;',len(alloc),'changed allocation slots;',s['seedHash']);print(alloc)
