import pathlib,subprocess,os,concurrent.futures
r=pathlib.Path(__file__).resolve().parents[1];docs=sorted((r/'work/v03/qa').glob('G?_V?.docx'));python=os.environ['CODEX_PRIMARY_RUNTIME_PYTHON']
def run(p):
 dest=r/'work/v03/render'/p.stem
 result=subprocess.run([python,'/root/.codex/skills/builtins/documents/render_docx.py',str(p),'--output_dir',str(dest),'--emit_pdf'],capture_output=True,text=True)
 (dest.parent/(p.stem+'.log')).write_text(result.stdout+result.stderr)
 return p.stem,result.returncode,len(list(dest.glob('page-*.png')))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for item in ex.map(run,docs):print(item,flush=True)
