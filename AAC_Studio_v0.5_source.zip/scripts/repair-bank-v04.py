"""V0.4 repair compiler. Historical banks and QA evidence are never overwritten.
Deterministic MILP allocation enforces coverage, DOK, cyclic and paired exclusions.
"""
import copy, hashlib, importlib.util, json, pathlib, re
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix
R=pathlib.Path(__file__).resolve().parents[1]
def read(p): return json.loads((R/p).read_text())
def save(p,v):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
old=read('lib/seed.json') if not (R/'data/blueprint-4.7-original.json').exists() else read('data/blueprint-4.7-original.json')
if not (R/'data/blueprint-4.7-original.json').exists():save('data/blueprint-4.7-original.json',old)
s=copy.deepcopy(old);pool=read('data/v03/task-catalog.json');changes=[]
reviewed=read('data/v03/allocation-evidence.json')
prior={e['catalogId']:e for e in reviewed.values()}
routine={'COORD-MOVE','COMPARE-QUOTIENTS','ADD-MISSING-PART','DATA-MISSING-FREQUENCY','QUAD-COMMON-CLASS','QUAD-COUNT-CLASSES'}
aliases={'CONVERT-TOTAL':'CONVERT-ADD-COMPONENTS','CONVERT-THEN-RESTORE':'CONVERT-ADD-COMPONENTS','AFFINE-MISSING-COUNT':'AFFINE-MISSING-FACTOR','AFFINE-MISSING-RATE':'AFFINE-MISSING-FACTOR'}
for r in pool:
 before=copy.deepcopy(r);c=r['structureCode'];g=r['grade'];rules=[]
 r['semanticKey']=aliases.get(r['semanticKey'],r['semanticKey'])
 # Preserve the displayed-data claim, supply its required mathematical evidence.
 if r['claimId']=='G6-040':
  r.update(visualPolicy='Required',representation='Statistical Graph',footprint='Compact')
  r['given']='A necessary dot plot of at least six numerical observations with one extreme value and a stated measurement context. '+('Choose the measure of center least affected by the extreme observation.' if c=='CENTER-OUTLIER-CHOICE' else 'Choose the measure of variability least affected by the extreme observation.')
 if c in routine:r['dok']=1
 if c=='SCALING-COMPARE':
  r['given']=re.sub(r'[,;]?\s*without calculating (?:the )?product\.?','',r['given'],flags=re.I)
  r['action']='Compare the positive product with its positive input.'
 if c=='SCALING-INFER-INTERVAL':
  r['given']=re.sub(r';?\s*do not calculate[^.]*\.?','',r['given'],flags=re.I).strip()
  r['requiredResult']='one factor category: below 1, equal to 1, or above 1'
  r['action']='Classify the positive scale factor relative to one.'
  rules.append('Positive input and factor; select exactly one category relative to 1.')
 if c=='DATA-MISSING-FREQUENCY':
  r.update(representation='Statistical Organizer',dok=1)
  r['given']='A necessary numerical frequency table gives the total number of observations and has exactly one missing frequency.'
 if c=='DATA-OBSERVATIONS':r['given']='A necessary dot plot with a labeled numerical scale; each dot represents one observation. Determine the total observation count.'
 if c=='FUNCTION-INPUT':rules.append('The coefficient a is nonzero; the equation has exactly one admissible input.')
 if g==7 and c=='DIV-DIVISOR':rules.append('Dividend, specified quotient and recovered divisor are all nonzero.')
 if c=='INEQUALITY-INTEGER-LIMIT':rules.append('The admissible integer set is nonempty and bounded above; its inequality-derived maximum is strictly below the supplied domain ceiling.')
 if c in ['EQUATION-SHARED-SOLUTION','EQUATION-SHARED-ROOT','EQUATION-COEFFICIENT-MODEL'] or ('a' in r['given'] and 'b' in r['given'] and 'd' in r['given'] and r['standard']=='6.EE.B.7'):
  rules.append('All multiplicative coefficients and denominators are positive; the unique solution is nonnegative.')
 if c=='UNIT-RATE-DIFFERENCE':
  r['given']='Two supplied quantity pairs describe the same type of rate. Both pairs use the same numerator units and the same denominator units.'
  rules.append('All denominator quantities are positive; subtract rates in their common units. No conversion is required.')
 if r['answerObject']=='Number' and (r['quantity']=='Count' or re.search(r'number of (?:pieces|portions|groups)',r['requiredResult'])):
  r['quantity']='Count'
  rules.append('All divisor/group/portion sizes are positive. For an unrounded count, choose exactly divisible quantities so the answer is a nonnegative integer; never silently floor or round.')
 if re.search(r'complete|maximum',r['requiredResult']) and r['quantity']=='Count':
  rules[-1]='Positive divisor and usable total; maximum COMPLETE count is explicitly intended. The floor interpretation must be stated in the student prompt.'
 if c=='NET-SURFACE-AREA-FROM-PERIMETER':rules.append('Base perimeter P and known edge a satisfy a>0, P>2a and P!=4a; prism height is positive.')
 if c=='SQUARE-PRISM-NET-AREA':rules.append('Base perimeter and prism height are positive.')
 if c=='NET-ADD-FACES':rules.append('Triangle sides satisfy strict triangle inequalities; any supplied altitude is perpendicular to its stated base and all shared net edges match.')
 if 'batch' in r['given']:rules.append('At least two positive batches; portion sizes and all counts are positive and divisions are exact.')
 if 'LCM' in c:rules.append('Inputs are positive integers within the assigned standard boundary.')
 if c in ['ESTIMATE-SUM','ESTIMATE-DIFFERENCE','ESTIMATE-REASONABLE']:
  r['given']=r['given'].replace('estimate rather than compute an exact sum','select the benchmark closest to the sum')
  rules.append(('State the nearest whole-number target explicitly.' if c=='ESTIMATE-DIFFERENCE' else 'Supply at least three distinct numerical benchmark candidates and ask for the closest candidate to the actual result. Return the candidate value.')+' Exclude exact halfway ties and equal-distance candidates. No prescribed internal method.')
  r['given']=re.sub(r'\breasonable\b','closest',r['given'],flags=re.I)
 if 'nearest whole' in r['given'].lower():rules.append('Exclude exact half-unit ties; the nearest whole-number answer is unique.')
 # Context means required mathematical content, not a forced narrative.
 if re.search(r'shar|recipients|per.unit|simulation|measur|meters|centimeters|batches|travel|groups|portions|rate|fixed (?:mass|amount|quantity)',r['given'],re.I) or c=='INEQUALITY-DERIVE-FROM-TOTAL':
  r['context']='Neutral context';r['wordLimit']=45
 else:r['context']='Pure mathematics';r['wordLimit']=20
 r['domainRules']=rules
 r['given']=r['given'].strip()+' '+ ' '.join(rules)
 r['boundary']=r['given'].strip()+' Return only '+r['requiredResult']+'. No additional response or prescribed method.'
 r['responseProduct']='One MCQ selection (A–D)' if r['responseMode']=='mcq' else ('One cubic-unit label; unit words are the answer.' if c=='CUBIC-UNIT-IDENTIFY' else 'One '+r['answerObject'].lower()+'; answer domain: '+r['quantity']+'.')
 r['quantityDimension']=r['quantity'];r['structureFamilyId']='MATH48|'+r['semanticKey']
 # Difficulty is a task target pending actual item review, never a position label.
 r['difficulty']='Easy' if r['dok']==1 and r['answerObject'] in ['Label','Symbol','Comparison symbol'] else 'Medium' if r['dok']==1 else 'Hard' if c in ['POLYGON-DECOMPOSE-AREA','PATTERN-PAIR-FROM-TOTAL','NET-SURFACE-AREA-FROM-PERIMETER'] else 'Medium'
 r['difficultyRationale']='Provisional task target: '+('direct recognition or comparison' if r['difficulty']=='Easy' else 'inference of an unprovided relationship with linked conditions' if r['difficulty']=='Hard' else 'routine numerical work or a bounded connection of quantities')+'. Actual operand size, reading and workload must be reviewed after generation; this is not calibrated difficulty.'
 r['variation']='Classification' if r['answerObject'] in ['Label','Comparison symbol'] or r['responseMode']=='mcq' else 'Symbolic construction' if r['answerObject'] in ['Expression','Equation','Inequality'] else 'Display interpretation' if r['visualPolicy']=='Required' else 'Missing quantity' if re.search(r'missing|unknown|infer|recover',r['action']+' '+r['requiredResult'],re.I) else 'Numerical relationship'
 r['variationEvidence']='Intrinsic task category: '+r['variation']+'. Based on the assigned response and givens, not a claimed contrast with an unnamed form.'
 r['dokRationale']=('Routine reading, substitution, or stated operations; multiple computations alone do not raise DOK.' if r['dok']==1 else prior.get(r['catalogId'],{}).get('dokRationale','Connect the supplied constraints to infer the unprovided mathematical relationship; educator review of the realized item is required.'))
 changes.append({'catalogId':r['catalogId'],'before':before,'after':copy.deepcopy(r)})
save('data/v04/task-catalog.json',pool)
variables=[(i,f) for i in range(len(pool)) for f in range(1,9)];lookup={v:n for n,v in enumerate(variables)};rows=[];lo=[];hi=[]
def constrain(indices,a,b):rows.append(indices);lo.append(a);hi.append(b)
def ids(test,forms):return [lookup[i,f] for i,r in enumerate(pool) if test(r) for f in forms]
for g in [5,6,7]:
 for f in range(1,9):
  gf=lambda r:r['grade']==g
  constrain(ids(gf,[f]),15,15)
  for c in s['clusters']:
   if c['grade']==g:constrain(ids(lambda r:gf(r) and r['cluster']==c['code'],[f]),c['min'],c['max'])
  for d,a,b in [(1,4,6),(2,8,10),(3,0,1)]:constrain(ids(lambda r:gf(r) and r['dok']==d,[f]),a,b)
  for field,val,b in [('responseMode','mcq',2),('comparison',True,2),('comparisonCalculation',True,1),('footprint','Large Visual',3)]:constrain(ids(lambda r:gf(r) and r[field]==val,[f]),0,b)
  constrain(ids(lambda r:gf(r) and r['answerObject']=='Expression' and r['responseMode']=='shortAnswer',[f]),0,1)
  for c in {r['claimId'] for r in pool if gf(r)}:constrain(ids(lambda r:gf(r) and r['claimId']==c,[f]),0,1)
  if g==7:
   for st in ['7.RP.A.1','7.RP.A.2','7.RP.A.3']:constrain(ids(lambda r:gf(r) and r['standard']==st,[f]),1,1)
  for k in {r['semanticKey'] for r in pool if gf(r)}:constrain(ids(lambda r:gf(r) and r['semanticKey']==k,[f,f%8+1]),0,1)
for c in s['claims']:constrain(ids(lambda r:r['claimId']==c['id'],range(1,9)),1,8)
for f in range(1,9):
 constrain(ids(lambda r:r['grade'] in [5,6] and r['representation']=='Coordinate Plane',[f]),0,1)
 constrain(ids(lambda r:r['grade']==7 and r['representation']=='Coordinate Plane',[f]),0,1)
 for a,b in [(5,6),(6,7)]:
  for k in {r['semanticKey'] for r in pool}:constrain(ids(lambda r:r['grade'] in [a,b] and r['semanticKey']==k,[f]),0,1)
A=lil_matrix((len(rows),len(variables)))
for j,row in enumerate(rows):A[j,row]=1
preferred={(e['catalogId'],int(key.split('|')[1])) for key,e in reviewed.items()}
objective=np.array([0 if (pool[i]['catalogId'],f) in preferred else 10 for i,f in variables],float)+np.array([((i*31+f*17)%97)/10000 for i,f in variables])
result=milp(objective,integrality=np.ones(len(variables)),bounds=Bounds(0,1),constraints=LinearConstraint(A.tocsr(),lo,hi),options={'time_limit':180,'mip_rel_gap':.02})
print(result.message,flush=True)
if result.x is None:raise SystemExit('No feasible repaired bank. Nothing activated.')
assert np.all(A@result.x>=np.array(lo)-1e-6) and np.all(A@result.x<=np.array(hi)+1e-6)
chosen=[(pool[i],f) for j,(i,f) in enumerate(variables) if result.x[j]>.5];items=[]
for g in [5,6,7]:
 for f in range(1,9):
  group=[copy.deepcopy(r) for r,ff in chosen if r['grade']==g and ff==f]
  large=sorted([r for r in group if r['footprint']=='Large Visual'],key=lambda r:r['question']);small=sorted([r for r in group if r['footprint']!='Large Visual'],key=lambda r:(r['question'],r['catalogId']))
  positions=dict(zip(range(12,15),large))
  for q in range(1,16):
   r=positions.get(q) or small.pop(0);r.update(key=f'{g}|{f}|{q}',form=f,question=q,taskRuleId=f'TASK48-{g}|{f}|{q}',source='V0.4 repaired catalog '+r['catalogId'],legacy=False,metadataConfirmed=True);items.append(r)
s.update(items=items,blueprintVersion='4.8.0',policyVersion='1.4.0',repairVersion='aac-studio-0.4',previousSeedHash=old['seedHash'],sourceFile='AAC Studio V0.4 repaired bank; historical records immutable')
keys=['claimId','standard','claim','action','given','requiredResult','answerObject','quantity','responseMode','visualPolicy','representation','context','family','boundary','variation','statistics','wordLimit','footprint','structureCode','responseProduct','domainRules','difficulty','difficultyRationale','variationEvidence','dok','comparison','comparisonCalculation','expressionEligible','metadataConfirmed','quantityDimension','structureFamilyId']
s['taskRules']={r['taskRuleId']:{**{k:r[k] for k in keys},'dokMin':r['dok'],'dokMax':r['dok']} for r in items}
module=importlib.util.spec_from_file_location('witnesses',R/'tests/v03/witnesses.py');wmod=importlib.util.module_from_spec(module);module.loader.exec_module(wmod)
witnesses={};evidence={}
for r in items:
 w=wmod.for_spec(r);c=r['structureCode']
 if r['claimId']=='G6-040':
  w['visual']=wmod.dotplot([8,9,10,10,11,12,120]);w['stem']='The plot shows travel times in minutes. '+('Which center is least affected by the extreme value?' if c=='CENTER-OUTLIER-CHOICE' else 'Which spread measure is least affected by the extreme value?')
 w['stem']=re.sub(r'[,;]?\s*without calculating (?:the )?product\.?|Do not calculate the exact (?:scale )?factor\.?','',w['stem'],flags=re.I)
 if c=='DATA-MISSING-FREQUENCY':w['visual']=wmod.table(['Value','Frequency'],[['1','2'],['2','3'],['3','?'],['4','1']])
 if w['calculation']:assert wmod.evaluate(w['calculation'])==wmod.F(w['answer'].removesuffix('%')),(r['key'],w)
 w['stem']=wmod.native(w['stem']);w['choices']=[wmod.native(x) for x in w['choices']];w['catalogId']=r['catalogId'];witnesses[r['key']]=w
 evidence[r['key']]={'catalogId':r['catalogId'],'sourceSlot':r['sourceSlot'],'semanticKey':r['semanticKey'],'structureCode':c,'claimId':r['claimId'],'given':r['given'],'dok':r['dok'],'dokRationale':r['dokRationale'],'claimEvidence':r['claim']+' Required evidence: '+r['requiredResult'],'witnessAnswer':w['answer'],'witnessCalculation':w['calculation'],'witnessSolution':w['solution'],'contract':{k:r[k] for k in keys},'reviewBasis':'V0.4 task adjudication and exact-arithmetic QA. Educator review of realized items remains required.'}
 for k in ['catalogId','sourceSlot','semanticKey','dokRationale']:r.pop(k,None)
s.pop('seedHash',None);s['seedHash']=hashlib.sha256(json.dumps(s,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
save('data/v04/witnesses.json',witnesses);save('data/v04/allocation-evidence.json',evidence);save('data/v04/change-manifest.json',changes);save('lib/seed.json',s)
print('Activated',len(items),'repaired allocations with',len(s['claims']),'claims; seed',s['seedHash'])
