"""Reviewed task catalog -> constrained, reproducible 24-form allocation.
This compiler never edits historical archives. Constraints fail closed.
"""
import json,copy,pathlib,hashlib,collections
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import lil_matrix
R=pathlib.Path(__file__).resolve().parents[1]
s=json.loads((R/'work/v03/candidate.json').read_text());pool=[];seen=set()
for claim in s['claims']:
 if claim['id']=='G5-024':claim['text']='Infer the size or range of an unknown scale factor from a positive input and information about the product.'

def replace(r,code,given,result,action=None,**fields):
 r.update(structureCode=code,given=given,requiredResult=result,action=action or 'Determine '+result+'.',**fields)
# DOK is based on the simplest necessary reasoning, not the number of computations.
routine={'COORD-READ','COORD-COMBINE','PRISM-LAYERS','PRISM-BASE-HEIGHT','GCF-FACTOR-BLANK','GCF-OUTER-FACTOR','FUNCTION-OUTPUT','FUNCTION-INPUT','RELATED-VARIABLE-OFFSET','EQUATION-COEFFICIENT-MODEL','DISTRIBUTION-MEDIAN','DISTRIBUTION-RANGE','NUMBERLINE-READ','NUMBERLINE-INTERPOLATE','INEQUALITY-TRANSLATE','FACTOR-LINEAR-MISSING','FACTOR-CONTEXT-OUTER','FACTOR-CONTEXT-COEFFICIENT','COORD-DISTANCE','PERCENT-EQUIVALENT-MULTIPLIER','PERCENT-EQUIVALENT-DECREASE','TRANSLATE-GROUPED-SUM','UNIT-SHARE-COMBINED-GROUPS','UNIT-SHARE-TWO-STAGES','UNIT-RATE','ADD-TWO','MUL-MISSING-FACTOR','QUAD-INHERIT-PROPERTY','FUNCTION-MISSING-PARAMETER','DISTRIBUTE-MISSING-LIKE-COEFFICIENT'}
for original in s['items']:
 r=copy.deepcopy(original);g=r['grade'];c=r['structureCode']
 if g==5 and c in ['SCALING-INFER-INTERVAL','SCALING-SELECT-FACTOR']:
  r['claimId']='G5-024';r['claim']=next(c['text'] for c in s['claims'] if c['id']=='G5-024')

 if c in routine:r['dok']=1
 if g==5 and c=='MUL-DIGIT' and r['claimId']=='G5-012':
  replace(r,'WHOLE-PRODUCT-JOINED-ROWS','Two supplied whole-number row counts are combined, with the same supplied two-digit number of objects per row. The combined row count is multidigit.','the total number of objects',dok=2,context='Neutral context',wordLimit=45)
 if g==5 and c=='UNIT-DIV-DENOMINATOR':
  replace(r,'UNIT-DIV-TWO-PORTION-SIZES','A whole-number length is divided into a whole-number number of equal batches; each resulting batch has whole-number length. One batch is cut into pieces of one supplied unit-fraction size, and a second batch into a different supplied unit-fraction size.','the total number of pieces from those two batches',dok=2,context='Neutral context',wordLimit=45)
 if g==6 and c=='PRISM-MISSING-EDGE':
  replace(r,'PRISM-VOLUME-EXTENDED-EDGE','A rectangular prism has three fractional edges; one edge is extended by a supplied fractional amount. The resulting edge length and volume are not supplied.','the new volume',dok=2,quantity='Cubic')
 if c=='INEQUALITY-BOUNDARY':
  replace(r,'INEQUALITY-DERIVE-FROM-TOTAL','A fixed amount and a variable extra amount x together must be below a supplied strict total limit.','one inequality x<c',answerObject='Inequality',quantity='Relation',dok=2)
 if c=='SAMPLE-BIAS-CLASSIFY':
  replace(r,'SAMPLE-REPRESENTATIVE-SELECT','A defined population and four concise sample-selection procedures; exactly one gives every member an equal chance and avoids systematic undercoverage.','one MCQ selection of the representative procedure',dok=2)
 if c=='NUMBERLINE-MISSING-MOVE':
  replace(r,'NUMBERLINE-SUM-WITH-OPPOSITE','A necessary number line supplies coordinates of two nonzero labeled points; one addend is the first coordinate and the other is the opposite of the second coordinate.','the signed sum',dok=1)
 if g==5 and c=='MUL-MISSING-FACTOR':
  replace(r,'DECIMAL-PRODUCT-DERIVED-FACTOR','A rectangle has a supplied decimal length and a decimal width shorter than that length by a supplied amount. Neither width nor area is supplied.','the area',dok=2,quantity='Square',context='Neutral context',wordLimit=45)
 if g==5 and c in ['DIV-DIVISOR','DIV-DIVIDEND','DIV-REMAINDER-ONLY']:
  if r['standard']=='5.NBT.B.6':
   replace(r,'WHOLE-QUOTIENT-REMAINDER' if c=='DIV-REMAINDER-ONLY' else 'WHOLE-QUOTIENT-ROW-GROUPS','A multidigit whole-number total and a two-digit group size; '+('a nonzero remainder is explicitly permitted.' if c=='DIV-REMAINDER-ONLY' else 'the total is made from a supplied number of equal rows and items per row; the two-digit new group size is supplied.'),'the quotient and remainder' if c=='DIV-REMAINDER-ONLY' else 'the number of complete new groups',answerObject='Quotient with remainder' if c=='DIV-REMAINDER-ONLY' else 'Number',dok=1 if c=='DIV-REMAINDER-ONLY' else 2,context='Neutral context',wordLimit=45)
  else:
   replace(r,'DECIMAL-QUOTIENT-REMAINDER-LENGTH' if c=='DIV-DIVISOR' else 'DECIMAL-QUOTIENT-COMBINED-LENGTH','Two supplied decimal lengths are '+('joined, then a supplied decimal length is removed; the remainder is divided into pieces of a supplied decimal length.' if c=='DIV-DIVISOR' else 'joined and divided into pieces of a supplied decimal length; the quotient is exact.'),'the number of pieces',dok=2,context='Neutral context',wordLimit=45)
 if g==5 and c=='MUL-DIGIT' and r['claimId']!='G5-012':
  replace(r,'FRACTION-PRODUCT-DERIVED-FACTOR' if r['claimId']=='G5-021' else 'DECIMAL-PRODUCT-TWO-LENGTHS','Two supplied '+('fractional' if r['claimId']=='G5-021' else 'decimal')+' lengths form the width of a rectangle; its length is supplied separately. Determine the area; the combined width is not supplied.','the area',dok=2,quantity='Square',context='Neutral context',wordLimit=45)
 if g==5 and c=='MUL-MISSING-DENOMINATOR':
  replace(r,'FRACTION-PRODUCT-REMAINING-AREA','A rectangular sheet has fractional length and width; a stated fraction of its area is removed.','the remaining area',dok=2,quantity='Square',context='Neutral context',wordLimit=45)
 if c=='COMBINE-SHARE-QUOTIENT':
  replace(r,'SHARE-REMAINDER-QUOTIENT','A whole-number total has a smaller whole-number amount reserved. The remaining amount is shared among a supplied whole-number group count; the quotient is nonintegral.','the fractional amount per group',dok=2)
 if g==6 and c=='DIV-DIVISOR':
  replace(r,'FRACTION-QUOTIENT-UNIT-CONVERSION','A fractional total is expressed in meters and a fractional portion length in centimeters; 100 centimeters equals one meter. Conversion is necessary before division.','the number of portions',dok=2,context='Neutral context',wordLimit=45)
 if c=='NET-MISSING-FACE':
  replace(r,'NET-SURFACE-AREA-FROM-PERIMETER','A rectangular-prism net gives the perimeter of a nonsquare base, one base edge and prism height. Neither the other base edge nor any face area is supplied.','the total surface area',dok=2,quantity='Square')
 if c=='NUMBERLINE-READ':
  replace(r,'NUMBERLINE-REFLECT-POINT','A number line labels zero and a positive nonunit coordinate, with equal intervals; a marked nonzero point must be reflected across zero.','the coordinate of the reflected point',dok=1)
 if c=='TEST-TWO-CONDITIONS':
  r['given']='One equation with two solutions in a finite nonnegative candidate set, and an independent inequality that selects exactly one of those solutions.'
 if g==6 and c=='DISTRIBUTION-RANGE-FROM-DISPLAY':
  replace(r,'DISTRIBUTION-INTERVAL-COUNT','A dot plot with repeated observations and a stated closed interval whose endpoints are not the minimum and maximum.','the number of observations inside the interval',dok=1,quantity='Count')
 if c=='PATTERN-CORRESPONDING-PAIR':
  replace(r,'PATTERN-PAIR-FROM-TOTAL','Two positive additive whole-number rules and starting values are supplied. The sum of a corresponding pair at an unknown common position is supplied; exactly one nonnegative common position works.','the corresponding ordered pair',dok=2)
 if c=='PATTERN-MISSING-START':r['given']+=' All starting values and generated terms are nonnegative whole numbers.'
 if r['answerObject']=='Quotient with remainder':r['quantity']='Unitless'
 if any(t in r['given'].lower() for t in ['neutral','context','situation','recipients']):r['context']='Neutral context'
 if r['structureCode'] in ['COMPARE-SHARES','UNIT-RATE-DIFFERENCE']:r['context']='Neutral context'
 # Context fields now describe the allocated task; retain pure mathematical tasks where appropriate.
 if r['context']!='Pure mathematics':r['wordLimit']=45
 r['boundary']=r['given']+' Return only '+r['requiredResult']+'. '+('Use inclusive quadrilateral definitions. ' if c.startswith('QUAD-') else '')+'No additional response or prescribed method.'
 r['responseProduct']='One MCQ selection (A–D)' if r['responseMode']=='mcq' else 'One '+r['answerObject'].lower()+'; quantity: '+r['quantity']+'. Put unit words in the prompt.'
 r['quantityDimension']=r['quantity']
 # Canonical identity ignores display, labels, numeric domain and contextual nouns.
 aliases={'COMBINE-SHARE-QUOTIENT':'SHARE-ADD-THEN-DIVIDE','OPPOSITE-INVERSE':'OPPOSITE','OPPOSITE-PAIR':'OPPOSITE','MEDIAN-SORTED-DATA':'DISTRIBUTION-MEDIAN','ABS-CONSTRAINED-NUMBER':'ABS-SIGNED-ORDER','COORD-SIDE-LENGTH':'COORD-DISTANCE','TEST-TWO-CONDITIONS':'TEST-EQUATION-AND-INEQUALITY','FUNCTION-MISSING-PARAMETER':'RELATED-VARIABLE-OFFSET','SAMPLE-POPULATION-ESTIMATE':'TRIAL-PREDICT-FREQUENCY','FACTOR-CONTEXT-COEFFICIENT':'FACTOR-LINEAR-MISSING','FACTOR-CONTEXT-OUTER':'DISTRIBUTE-COEFFICIENT','PRODUCT-SIGN-INVERSE':'PRODUCT-SIGN','PROPORTIONALITY-CONSTANT':'UNIT-RATE','UNIT-DIV-PORTIONS':'DIV-QUOTIENT','UNIT-SHARE-AMOUNT':'DIV-QUOTIENT','FRACTION-AREA-MISSING-SIDE':'DIV-QUOTIENT','GCF-FACTOR-BLANK':'DIV-QUOTIENT','UNIT-DIV-DENOMINATOR':'DIV-QUOTIENT','GCF-OUTER-FACTOR':'GCF-DIRECT','CONVERT-SINGLE':'MULTIPLY-TWO','MEAN-TO-TOTAL':'MULTIPLY-TWO','PRISM-BASE-HEIGHT':'MULTIPLY-TWO','PRISM-EDGE-VOLUME':'MULTIPLY-THREE','PRISM-LAYERS':'MULTIPLY-TWO','FRACTION-QUOTIENT-UNIT-CONVERSION':'UNIT-RATE-CONVERT','DISTRIBUTION-RANGE-FROM-DISPLAY':'DISTRIBUTION-RANGE'}
 aliases.update({'NUMBERLINE-REFLECT-POINT':'OPPOSITE','FUNCTION-OUTPUT':'AFFINE-TOTAL','FUNCTION-INPUT':'AFFINE-MISSING-COUNT','FUNCTION-MISSING-PARAMETER':'AFFINE-MISSING-FIXED','RELATED-VARIABLE-OFFSET':'AFFINE-MISSING-FIXED','DIVIDE-TOTAL-PORTIONS':'SHARE-ADD-THEN-DIVIDE','DECIMAL-QUOTIENT-COMBINED-LENGTH':'SHARE-ADD-THEN-DIVIDE','SHARE-REMAINDER-QUOTIENT':'DIVIDE-REMAINDER-PORTION','REMAINING-UNIT-PORTION-COUNT':'DIVIDE-REMAINDER-PORTION','WHOLE-QUOTIENT-ROW-GROUPS':'MULTIPLY-THEN-DIVIDE','WHOLE-PRODUCT-JOINED-ROWS':'PRODUCT-JOINED-FACTORS','DECIMAL-PRODUCT-TWO-LENGTHS':'PRODUCT-JOINED-FACTORS','FRACTION-PRODUCT-DERIVED-FACTOR':'PRODUCT-JOINED-FACTORS','DECIMAL-PRODUCT-DERIVED-FACTOR':'SUBTRACT-THEN-MULTIPLY','MEDIAN-GAP-IN-SPREADS':'CENTER-GAP-NORMALIZE','UNIT-RATES-COMBINE':'SUM-QUOTIENTS'})
 r['semanticKey']=aliases.get(r['structureCode'],r['structureCode'])
 # Table classification and graphical selection have the same proportionality decision.
 if r['structureCode']=='PROPORTION-CLASSIFY':r['semanticKey']='PROPORTION-CLASSIFY'
 r['structureFamilyId']='MATH47|'+r['semanticKey']
 key=(g,r['claimId'],r['structureCode'],r['given'],r['responseMode'],r['visualPolicy'])
 if key in seen:continue
 seen.add(key);r['catalogId']=f'T47-{g}-{len(pool)+1:03}';r['sourceSlot']=original['key'];pool.append(r)
# Store candidate task catalog before allocation for transparent review.
(R/'data/v03/task-catalog.json').write_text(json.dumps(pool,ensure_ascii=False,indent=2)+'\n')
# Variable x(task, form). Tasks retain grade, claim and semantic relationship.
variables=[(i,f) for i in range(len(pool)) for f in range(1,9)];lookup={v:n for n,v in enumerate(variables)};rows=[];lower=[];upper=[]
def constrain(indices,lo,hi):rows.append(indices);lower.append(lo);upper.append(hi)
def ids(test,forms=range(1,9)):return [lookup[i,f] for i,r in enumerate(pool) if test(r) for f in forms]
for g in [5,6,7]:
 for f in range(1,9):
  gf=lambda r:r['grade']==g
  constrain(ids(gf,[f]),15,15)
  for c in s['clusters']:
   if c['grade']==g:constrain(ids(lambda r:gf(r) and r['cluster']==c['code'],[f]),c['min'],c['max'])
  for d,lo,hi in [(1,4,6),(2,8,10),(3,0,1)]:constrain(ids(lambda r:gf(r) and r['dok']==d,[f]),lo,hi)
  for field,val,hi in [('responseMode','mcq',2),('comparison',True,2),('comparisonCalculation',True,1),('footprint','Large Visual',3)]:constrain(ids(lambda r:gf(r) and r[field]==val,[f]),0,hi)
  constrain(ids(lambda r:gf(r) and r['answerObject']=='Expression' and r['responseMode']=='shortAnswer',[f]),0,1)
  for v in {r['variation'] for r in pool}:constrain(ids(lambda r:gf(r) and r['variation']==v,[f]),0,4)
  for c in {r['claimId'] for r in pool if gf(r)}:constrain(ids(lambda r:gf(r) and r['claimId']==c,[f]),0,1)
  if g==7:
   for st in ['7.RP.A.1','7.RP.A.2','7.RP.A.3']:constrain(ids(lambda r:gf(r) and r['standard']==st,[f]),1,1)
  for k in {r['semanticKey'] for r in pool if gf(r)}:
   # At most one within a form or either cyclic neighbor.
   constrain(ids(lambda r:gf(r) and r['semanticKey']==k,[f,f%8+1]),0,1)
for c in s['claims']:constrain(ids(lambda r:r['claimId']==c['id']),1,8)
for f in range(1,9):
 constrain(ids(lambda r:r['grade'] in [5,6] and r['representation']=='Coordinate Plane',[f]),0,1)
 constrain(ids(lambda r:r['grade']==7 and r['representation']=='Coordinate Plane',[f]),0,1)
 for a,b in [(5,6),(6,7)]:
  for k in {r['semanticKey'] for r in pool}:constrain(ids(lambda r:r['grade'] in [a,b] and r['semanticKey']==k,[f]),0,1)
A=lil_matrix((len(rows),len(variables)))
for j,row in enumerate(rows):A[j,row]=1
# Prefer existing positions where feasible; deterministic small tie-breaker.
preferred={(r['catalogId'],r['form']) for r in json.loads((R/'data/v03/preferred-allocations.json').read_text())}
objective=np.array([0 if (pool[i]['catalogId'],f) in preferred else 10 for i,f in variables],dtype=float)+np.array([((i*31+f*17)%97)/10000 for i,f in variables])
result=milp(objective,integrality=np.ones(len(variables)),bounds=Bounds(0,1),constraints=LinearConstraint(A.tocsr(),lower,upper),options={'time_limit':90,'mip_rel_gap':.02})
print('Catalog',len(pool),'variables',len(variables),'constraints',len(rows),'solver:',result.message)
if result.x is None:raise SystemExit('No feasible bank; do not publish.')
chosen=[(pool[i],f) for j,(i,f) in enumerate(variables) if result.x[j]>.5]
items=[]
for g in [5,6,7]:
 for f in range(1,9):
  group=[copy.deepcopy(r) for r,ff in chosen if r['grade']==g and ff==f]
  assert len(group)==15
  # Reserve 12–14 for the genuinely large diagrams; other slots sorted by former sequence.
  large=sorted([r for r in group if r['footprint']=='Large Visual'],key=lambda r:r['question']);small=sorted([r for r in group if r['footprint']!='Large Visual'],key=lambda r:(r['question'],r['catalogId']))
  positions={q:r for q,r in zip(range(12,15),large)}
  for q in range(1,16):
   r=positions.get(q) or small.pop(0);r.update(key=f'{g}|{f}|{q}',form=f,question=q,taskRuleId=f'TASK47-{g}|{f}|{q}',source='Reviewed current catalog '+r['catalogId']+'; historical archives remain unchanged.',legacy=False,metadataConfirmed=True)
   # Difficulty is a planning target, independent of DOK; not a mathematical guarantee.
   r['difficulty']='Easy' if q in [1,2,3] else 'Hard' if q in [13,14,15] else 'Medium';items.append(r)
s['items']=items;s['taskRules']={}
for r in items:
 s['taskRules'][r['taskRuleId']]={k:r[k] for k in ['claimId','standard','action','given','requiredResult','answerObject','quantity','responseMode','visualPolicy','representation','context','family','boundary','variation','statistics','wordLimit','footprint','structureCode']};s['taskRules'][r['taskRuleId']].update(dokMin=r['dok'],dokMax=r['dok'])
s.pop('seedHash',None);s['seedHash']=hashlib.sha256(json.dumps(s,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
(R/'work/v03/compiled.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
print('Compiled all',len(items),'slots; all constraint rows checked:',bool(np.all(A@result.x>=np.array(lower)-1e-6) and np.all(A@result.x<=np.array(upper)+1e-6)))
