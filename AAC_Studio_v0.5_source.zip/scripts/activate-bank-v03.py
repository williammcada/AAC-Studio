import json,pathlib,hashlib
R=pathlib.Path(__file__).resolve().parents[1];s=json.loads((R/'work/v03/compiled.json').read_text());w=json.loads((R/'data/v03/witnesses.json').read_text());e={}
concept={
'SCALING-COMPARE':'Infer the direction of change from the multiplier’s relation to one; do not calculate an unnecessary product.',
'SCALING-INFER-INTERVAL':'Infer an unknown multiplier’s interval from a positive input-output comparison.',
'SCALING-SELECT-FACTOR':'Coordinate two strict bounds to eliminate candidate factors; a single product or bound is insufficient.',
'PATTERN-DIFFERENCE':'Coordinate two generated sequences and compare corresponding positions.',
'PATTERN-PAIR-FROM-TOTAL':'Infer a shared unknown term position from a constraint on the paired total; neither independently generated pattern supplies the position.',
'PATTERN-CORRESPONDING-PAIR':'Maintain two different iterative rules and align their corresponding term positions.',
'PATTERN-MISSING-START':'Work backward through one iterative rule using a cross-pattern equality.',
'COORD-MOVE':'Interpret two directional changes as changes to different coordinate components.',
'COORD-INFER-RECTANGLE':'Use shared-coordinate rectangle constraints to infer an unplotted vertex.',
'QUAD-SUBCLASS':'Combine inherited attributes with an additional property to identify the most specific warranted class.',
'QUAD-COUNT-CLASSES':'Test a universal property across overlapping inclusive classes; count only classes for which it must hold.',
'QUAD-HIERARCHY-BLANK':'Infer the missing intermediate category from both parent and child constraints.',
'QUAD-COMMON-CLASS':'Find the nearest shared ancestor in an inclusive classification hierarchy.',
'EQUIVALENCE-SELECT':'Distinguish expressions that agree for all inputs using distribution and combination, rather than one trial value.',
'EQUIVALENCE-COUNTERVALUE':'Compare two non-equivalent expressions at constrained candidate inputs; distinguish agreement from a counterexample.',
'TEST-TWO-CONDITIONS':'Intersect an equation’s two candidate solutions with an independent inequality; both conditions are necessary.',
'TEST-EQUATION-AND-INEQUALITY':'Intersect an equation’s two candidate solutions with an independent inequality; both conditions are necessary.',
'ABS-CONSTRAINED-NUMBER':'Coordinate magnitude with signed order to distinguish two equal-magnitude candidates.',
'ABS-SIGNED-ORDER':'Coordinate magnitude with signed order to distinguish two equal-magnitude candidates.',
'NUMBERLINE-REFLECT-POINT':'Interpret position relative to zero and apply reflection; validate the scale before determining the opposite.',
'CENTER-OUTLIER-CHOICE':'Select a measure of center based on its resistance to the described extreme observation.',
'VARIABILITY-OUTLIER-CHOICE':'Select a measure of spread based on its resistance to an extreme observation, rather than recall a term alone.',
'SAMPLE-REPRESENTATIVE-SELECT':'Evaluate coverage and selection procedures against the population to select the unbiased procedure.',
'TRIANGLE-SSS-CLASSIFY':'Apply triangle-existence inequalities and distinguish existence from uniqueness under three side constraints.',
'TRIANGLE-AAA-CLASSIFY':'Check angle consistency while recognizing that angles alone do not fix scale.',
'TRIANGLE-TWO-ANGLES-SIDE':'Coordinate the angle-sum condition with included-side information to decide existence and uniqueness.',
'PROPORTION-CLASSIFY':'Test the defining invariant across all supplied pairs, or combine linearity with passing through the origin.',
'CROSS-SECTION':'Relate the cutting plane’s orientation to the two-dimensional section of a three-dimensional solid.',
'INEQUALITY-INTEGER-LIMIT':'Solve the strict inequality and interpret the result in a discrete integer domain; the domain bound does not supply the answer.',
'RATIONAL-BUDGET-COUNT':'Model the available quantity and quotient, then interpret a noninteger result as the maximum complete count.',
'PAIR-SUMS-RECOVER-TOTAL':'Recognize that adding the supplied pair sums counts each unknown twice, and recover the whole sum.',
'ADJACENT-LINEAR-ANGLE-SOLVE':'Form a straight-angle equation, solve the variable, and evaluate a target angle; neither supplied label alone gives its measure.',
'DISTRIBUTION-CENTER-SHIFT':'Relate a transformation of all observations to the distribution’s center.',
'MEDIAN-GAP-IN-SPREADS':'Compare centers on a common scale and normalize their separation by the common variability measure.',
'POLYGON-DECOMPOSE-AREA':'Infer missing lengths from the whole shape, then choose a valid area decomposition.',
'NET-SURFACE-AREA-FROM-PERIMETER':'Infer an unprovided base edge from perimeter, identify paired faces, and combine all face areas.',
'SQUARE-PRISM-NET-AREA':'Infer base edge length from perimeter, identify the net’s face types, and combine their areas.',
'RECT-TILE-AREA':'Derive rectangle dimensions from fractional tile lengths and row/column counts before finding area.',
'CUBE-LAYERS-COUNT':'Interpret two different layer plans and stack depths, then combine the unit-cube counts.',
'COMPOSITE-AREA-DEDUCE':'Infer the triangle base from the composite boundary and combine distinct area formulas.',
'COMPOSITE-MISSING-VOLUME':'Use additive volume structure to infer one component after calculating the other.',
}
for r in s['items']:
 key=r['key'];v=w[key];c=r['structureCode'];reason=concept.get(c)
 if r['dok']==1:reason='Routine recall, representation reading, or a stated procedure. The shortest valid solution is: '+' '.join(v['solution'])
 elif not reason:
  reason=('Select and connect the quantities needed for '+r['requiredResult']+'; the relationship is not supplied as a single executable numerical expression. ' if r['context']!='Pure mathematics' else 'Coordinate the supplied relationships to determine '+r['requiredResult']+'. ')+ 'Necessary reasoning: '+' '.join(v['solution'])
 e[key]={'catalogId':r.pop('catalogId'),'sourceSlot':r.pop('sourceSlot'),'semanticKey':r.pop('semanticKey'),'structureCode':r['structureCode'],'claimId':r['claimId'],'given':r['given'],'dok':r['dok'],'dokRationale':reason,'claimEvidence':r['claim']+' Evidence requested: '+r['action']+' The accepted object is '+r['requiredResult']+'.','witnessAnswer':v['answer'],'witnessCalculation':v['calculation'],'witnessSolution':v['solution'],'contract':{k:r[k] for k in ['claimId','standard','claim','action','given','requiredResult','answerObject','quantity','responseMode','visualPolicy','representation','footprint','structureCode','dok','variation','context','boundary','wordLimit','comparison','comparisonCalculation','statistics']},'reviewBasis':'Model-authored mathematical witness and task-level review; arithmetic independently checked with exact rational evaluation where a numeric expression applies. Educator item review remains required.'}
s.pop('seedHash',None);s['seedHash']=hashlib.sha256(json.dumps(s,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
(R/'lib/seed.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(R/'data/v03/allocation-evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
print('Activated 360 evidence-bound allocations',s['seedHash'])
