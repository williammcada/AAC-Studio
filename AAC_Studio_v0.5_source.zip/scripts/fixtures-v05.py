"""Isolated diagnostic fixtures; not accepted admissions items."""
import json,copy,pathlib
R=pathlib.Path(__file__).resolve().parents[1]
s=json.loads((R/'lib/seed.json').read_text());old=json.loads((R/'data/blueprint-4.8-original.json').read_text());w=json.loads((R/'data/v04/witnesses.json').read_text());out={}
def text(x,y,t,size=16):return f'<text x="{x}" y="{y}" font-size="{size}" font-family="Arial">{t}</text>'
def line(x,y,X,Y,extra=''):return f'<line x1="{x}" y1="{y}" x2="{X}" y2="{Y}" stroke="black" stroke-width="2" {extra}/>'
def svg(body,W=600,H=360):return {'kind':'svg','svg':f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}">{body}</svg>','alt':'Release diagnostic visual'}
for r in s['items']:
 c=r['structureCode'];g=r['grade'];key=r['key'];a=copy.deepcopy(w[key])
 if key=='6|2|5':a=copy.deepcopy(w[next(x['key'] for x in old['items'] if x['structureCode']==c and x['grade']==g)])
 data=None
 if c=='WHOLE-QUOTIENT-ROW-GROUPS':data={'rows':32,'perRow':18,'groupSize':24,'suppliedTotal':0}
 if c=='MEAN-TO-TOTAL':data={'mean':7,'count':6}
 if c=='DECIMAL-PRODUCT-DERIVED-FACTOR':data={'length':3.2,'reduction':1.2}
 if c in ['TEST-EQUATION-AND-INEQUALITY','TEST-TWO-CONDITIONS']:data={'candidates':[0,1,2,3],'coefficients':[1,-4,3],'bound':2,'direction':1}
 if c=='ADJACENT-LINEAR-ANGLE-SOLVE':data={'a':2,'b':10,'c':3,'d':20}
 if c=='LCM':
  data={'inputs':[6,8]};a.update(stem='Find the least common multiple of \\(6\\) and \\(8\\).',answer='24',solution=['6 = 2 × 3; 8 = 2³. LCM = 2³ × 3 = 24.'])
 if c=='SIMPLE-INTEREST-PRINCIPAL':data={'interest':12,'rate':.03,'time':2}
 if c=='UNIT-RATE-DIFFERENCE':
  data={'numerators':[9,8],'denominators':[6,4]} if g==6 else {'numerators':[1.5,1.5],'denominators':[.75,.5]}
  a['stem']=a['stem'].replace('B’s rate minus A’s','the larger rate minus the smaller')
 if c=='DATA-MISSING-FREQUENCY':data={'known':[2,3,1],'total':10}
 if c=='PROPORTION-REVERSE-EQUATION':a.update(answer='y=(1/4)*x',solution=['The coefficient is 1/4, so y=(1/4)*x.'])
 if c=='PROPORTION-CLASSIFY' and r['representation']=='Proportional Graph':
  b=line(60,300,545,300)+line(60,300,60,25)+text(540,330,'x')+text(32,25,'y')+text(38,320,'0')
  for n in range(1,6):b+=line(60+80*n,296,60+80*n,304)+text(55+80*n,324,str(n))
  for n in range(1,6):b+=line(56,300-50*n,64,300-50*n)+text(32,306-50*n,str(n))
  b+=line(60,300,460,50)+text(470,52,'A')+line(60,250,460,150,'stroke-dasharray="9 5"')+text(470,155,'B')+line(60,50,460,250,'stroke-dasharray="2 5"')+text(470,257,'C')
  pts=' '.join(f'{60+80*x},{300-10*x*x}' for x in [0,.5,1,1.5,2,2.5,3,3.5,4,4.5,5])
  b+=f'<polyline points="{pts}" fill="none" stroke="black" stroke-width="2" stroke-dasharray="10 3 2 3"/>'+text(415,112,'D')
  a.update(stem='Which curve represents a proportional relationship?',choices=['Curve A','Curve B','Curve C','Curve D'],answer='A',visual=svg(b),solution=['A alone is linear and passes through the origin. B and C have nonzero intercepts; D is nonlinear.'])
  a['visual']['alt']='One shared Cartesian plane. Curves A through D use distinct labeled line patterns.'
 if c=='MEDIAN-GAP-IN-SPREADS':
  b=''
  for j,vals in enumerate([[8,9,10,10,11,12],[12,13,14,14,15,16]]):
   y=100+j*160;b+=text(20,y-60,'A' if j==0 else 'B')+line(65,y,555,y)
   for n in range(8,17):b+=line(70+55*(n-8),y-4,70+55*(n-8),y+4)+text(62+55*(n-8),y+25,str(n),14)
   for n in sorted(set(vals)):
    for k in range(vals.count(n)):b+=f'<circle cx="{70+55*(n-8)}" cy="{y-18-20*k}" r="5" fill="black"/>'
  a.update(stem='Use each half’s median for quartiles. How many common interquartile ranges separate the two medians?',visual=svg(b,600,320),answer='2',solution=['A has median 10 and quartiles 9,11; B has median 14 and quartiles 13,15. Each IQR is 2. The median gap is 4, or 2 common IQRs.'])
  a['visual']['alt']='Two dot plots A and B on the same scale from 8 to 16; each dot is one observation.'
 if c=='DECIMAL-CLASSIFY':a['answer']='nonterminating repeating'
 if data:a['taskData']=data
 out[key]=a
(R/'data/v05/witnesses.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
