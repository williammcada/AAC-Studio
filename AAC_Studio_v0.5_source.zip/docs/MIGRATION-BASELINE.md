# Migration Baseline — AAC Studio

**Recorded:** 18 September 2026  
**Repository:** `williammcada/AAC-Studio`  
**Branch:** `main`  
**Active release:** AAC Studio v0.4.0 · Blueprint 4.8.0 · `aac.contract.v4`  
**Record status:** Official verified source and portable-release baseline.

## Canonical source identity

| Field | Value |
| --- | --- |
| Canonical source | Complete repository source tree |
| Verified source provenance | Sites source commit `638cb0166ab5db37f4fe2fdc4df8bd4b971a99d5` |
| Portable release | `AAC_Studio_v0.4.html` |
| Portable release SHA-256 | `c191704b7467a65b654ea3d9ab2ae2af614096b0d2ecaad76877285c822ee634` |
| Canonical GitHub verified-release commit | The v0.4 release commit containing this source; its immutable SHA is added by the following documentation-only checkpoint |
| Hosted release | `https://aac-studio-wm.wsm05.chatgpt.site` |

The previous v0.3 source baseline remains preserved as `AAC_Studio_v0.3.html` at checkpoint `76d9c85f634025b3d75970fc4d827b8467f54ba1`. It is historical and is not the current implementation baseline.

## Verification status

| Check | Result | Evidence / limitation |
| --- | --- | --- |
| Complete source and portable release preserved | Passed | Full source tree and the exact delivered HTML are committed together. |
| Release regression | Passed | 46 domain/workflow assertions, 1,711 v0.2 release assertions, 18,444 retained v0.3 bank/compatibility assertions, and 1,633 v0.4 assertions. |
| All 24 form workflows | Passed | Packet export, valid import, review, finalization, Word package and backup restoration for G5–G7/V1–V8. |
| Type and production build | Passed | TypeScript check and Vinext production build rerun from the synchronized canonical tree. |
| Offline artifact | Passed | Exact verified HTML preserved; build has zero external dependencies. |
| Hosted/running application | Passed | v0.4.0 / Blueprint 4.8.0 verified in Chrome at the hosted URL during release. |
| Microsoft Word desktop and physical printing | Not run | Representative packages were rendered and inspected with LibreOffice; this limitation remains explicit. |

## Documentation authority

- [`PROJECT-BRIEF.md`](PROJECT-BRIEF.md) records permanent project-local scope and verification requirements.
- [`change-specs/AAC_Studio_V0.4_Consolidated_Repair_Specification.md`](change-specs/AAC_Studio_V0.4_Consolidated_Repair_Specification.md) is the implemented v0.4 repair specification.
- [`releases/0.4-release.md`](releases/0.4-release.md) records changes, tests and limits.
- [`MIGRATION-NOTE.md`](MIGRATION-NOTE.md) and the v0.3 baseline remain historical context.

## Next gate

Begin v0.5 only from this verified baseline. Create and approve a versioned change specification before implementation; preserve an implementation checkpoint before extended testing; then record the exact verified candidate before release and deployment.
