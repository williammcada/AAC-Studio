# AAC Studio v1.1.0 / Blueprint 4.5.0

This release establishes the first explicit Studio release version and repairs the offline AAC Studio workflow and the affected future allocations. It preserves finalized Forms 1–3 and their approved Template and Surface Form IDs. The change manifest is `data/studio-1.1-repairs.json`; `scripts/repair-studio-v11.py` rebuilds the repaired seed from the retained original blueprint.

## Changes

- Replaced the unsupported Grade 5 fraction-division relationships in V4 and V8 with within-standard relationships.
- Removed known cross-grade task duplicates, clarified objective response scope, repaired statistical-choice allocation and comparison counters, and recalibrated specific routine V4 DOK assignments while preserving the form's required distribution.
- Reconciled three damaged V3 comparison transcriptions against the approved SF02 writeback PDFs. Later SF03 student documents were not substituted for the controlling records. The original eleven V2 source discrepancies remain recorded.
- Added reviewed relationship signatures alongside Structure Family IDs, source-text integrity checks, and explicit DOK review. These checks detect the encoded conflicts; they do not prove mathematical equivalence or validate every item's cognitive demand automatically.
- Added packet-bound conflict JSON and plain-text conflict recording, repair-request download, and a recorded resolution. Reports preserve existing items and block finalization while open.
- Validates replacement items before replacing a draft. Accepts restricted exact numerical answers such as `12π`, `3π/2`, and `sqrt(2)`, without accepting arbitrary executable expressions.
- Mathematical dependency revisions exclude administrative Template and Surface IDs. A real change to an accepted mathematical task still invalidates dependent packets.
- Supports original Blueprint 4.4 JSON backups. Previously finalized forms preserve their original allocations and review records. Unfinalized old packets must be refreshed; their earlier drafts remain in revision history.

## Use

Open the updated `AAC_Studio.html`. Restore a prior JSON backup if transferring work from another HTML copy. Download fresh V4 packets from this release. Import either the returned item JSON or conflict JSON in Review & import; a prose report can be saved with **Save text as conflict**. Review all items and the whole-form checklist before finalization.

## Validation

TypeScript check; 58 domain/workflow assertions; repaired-allocation and backup-migration regression tests; local IndexedDB persistence, history, asset deduplication and concurrency tests; server storage regression; server-rendered 24-form/four-tab layout; standalone bundle dependency and syntax checks. Mathematical feasibility witnesses cover the redesigned relationships, not a newly generated 45-item assessment. Browser interaction testing was not run in this task.

All fifteen G5/G6/G7 V4–V8 allocation sets pass the encoded blocking preflight. Nonblocking difficulty and DOK-review warnings remain visible. The hosted site was not redeployed; this release is the requested offline HTML artifact.

## V0.5

The complete iteration audit is addressed by the v0.5 compiler, semantic policy, task-specific response checks and typed numerical validation. See `docs/change-specs/v0.5-AUDIT-REPAIRS.md` and `data/v05/`. Historical descriptions above are retained. Current status is a tested release candidate; desktop browser interaction remains unverified.
