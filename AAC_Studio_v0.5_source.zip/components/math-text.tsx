import {segments,type MathNode} from '@/lib/math';
import {validateSvg} from '@/lib/validation';
import type {Visual as VisualType} from '@/lib/model';
function Nodes({nodes}:{nodes:MathNode[]}){return <>{nodes.map((n,j)=>n.kind==='text'?<span key={j}>{n.text}</span>:n.kind==='fraction'?<span className="math-fraction" key={j}><span><Nodes nodes={n.top}/></span><span><Nodes nodes={n.bottom}/></span></span>:n.kind==='sqrt'?<span className="math-root" key={j}>√<span><Nodes nodes={n.body}/></span></span>:n.kind==='group'?<Nodes key={j} nodes={n.body}/>:<span key={j}><Nodes nodes={[n.base]}/>{n.position==='super'?<sup><Nodes nodes={n.body}/></sup>:<sub><Nodes nodes={n.body}/></sub>}</span>)}</>;}
export function MathText({text}:{text:string}){try{return <>{segments(text).map((s,j)=>s.kind==='text'?<span key={j}>{s.text}</span>:<span key={j} className="math" role="math" aria-label={s.source.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g,'$1 over $2')}><Nodes nodes={s.nodes}/></span>)}</>;}catch{return <span className="invalid-math">{text}</span>;}}
export function Visual({visual}:{visual:VisualType|null}){if(!visual)return null;if(visual.kind==='table')return <figure className="item-visual"><table aria-label={visual.alt}><thead><tr>{visual.headers.map((h,j)=><th key={j}><MathText text={h}/></th>)}</tr></thead><tbody>{visual.rows.map((r,j)=><tr key={j}>{r.map((v,k)=><td key={k}><MathText text={v}/></td>)}</tr>)}</tbody></table></figure>;
 try{if(visual.kind==='svg'&&validateSvg(visual.svg))return <p className="invalid-math">Figure needs correction before preview.</p>;if(visual.kind==='image'&&!/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/]+=*$/.test(visual.dataUrl))return <p className="invalid-math">Use an embedded PNG or JPEG figure.</p>;}catch{return <p className="invalid-math">Figure needs correction before preview.</p>;}
 const src=visual.kind==='image'?visual.dataUrl:`data:image/svg+xml;charset=utf-8,${encodeURIComponent(visual.svg)}`;
 // SVGs are isolated image documents, never injected as active markup.
 // eslint-disable-next-line @next/next/no-img-element
 return <figure className="item-visual"><img src={src} alt={visual.alt}/></figure>;
}
