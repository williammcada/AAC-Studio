import type {Spec} from './model';
import semanticPolicy from '../data/v05/semantic-policy.json';
import {scalarValue} from './exact-number';
export const STUDIO_VERSION='0.5.0';
export const CONTRACT_VERSION='aac.contract.v5';
export const DESIGN_POLICY='aac.design.v5';
export const SVG_ATTRIBUTES=['xmlns','viewBox','width','height','x','y','x1','y1','x2','y2','cx','cy','r','rx','ry','d','points','fill','stroke','stroke-width','stroke-dasharray','stroke-linecap','stroke-linejoin','transform','text-anchor','dominant-baseline','font-size','font-family','font-weight','opacity','fill-opacity','stroke-opacity','dx','dy','role','aria-label'];
export const intervalAliases=['below 1','less than 1','equal to 1','above 1','greater than 1','0<k<1','(0,1)','k=1','k>1'];
export const isUnitLabel=(s:Spec)=>s.structureCode==='CUBIC-UNIT-IDENTIFY';
export const hasStudentFraction=(text:string)=>/\d\s*[/⁄]\s*\d|[\u00bc-\u00be\u2150-\u215f\u2189]/u.test(text);
export const TABLE_REPRESENTATIONS=['Ratio Table','Function Table','Statistical Organizer','Compact Data Table'];
export const ANSWER_GRAMMARS={
 Number:'Finite decimal, integer, a/b, mixed a b/c, rational multiple of pi, or fixed sqrt(n). Probability is in [0,1]; Count is a nonnegative integer; Integer may be signed. Percent answers use an explicit % sign.',
 'Ordered pair':'(a, b); each component is a finite rational number; mixed fractions permitted. No thousands separators inside coordinates.',
 Ratio:'a:b; signed finite rational terms are allowed; second term must be nonzero. Use colon to distinguish a ratio from a scalar fraction.',
 'Comparison symbol':'One of <, >, =, ≤, ≥.',
 Symbol:'One explicitly defined single-letter variable, or + or − for a sign task.',
 Expression:'Arithmetic with numbers, defined one-letter variables, + - * / ^, parentheses and implicit multiplication; no equality or inequality. Literal division by zero is invalid.',
 Equation:'Two supported arithmetic expressions separated by exactly one =.',
 Inequality:'Two supported arithmetic expressions separated by exactly one <, >, ≤, or ≥.',
 Label:'A short mathematical label; at most 3 words, letters/digits/spaces/hyphens only. Task-specific unit and factor-category aliases are listed in the assigned response grammar.',
 'Quotient with remainder':'q R r, with nonnegative integer q and r. The remainder must be smaller than the given positive divisor (mathematical review).',
 'Repeating decimal':'Signed decimal with parenthesized recurring digits, e.g. 0.(3), -1.2(34). No ellipsis approximation.',
} as const;
export function responseDescription(s:Spec):string{
 if(s.responseMode==='mcq')return 'One MCQ selection (A–D). Four meaningful, distinct options with exactly one correct option.';
 if(isUnitLabel(s))return 'One cubic-unit label: cubic millimeter/centimeter/meter/kilometer (British spellings and plurals accepted), or mm³/cm³/m³/km³, or mm^3/cm^3/m^3/km^3. Unit words ARE the response for this task.';
 if(s.structureCode==='SCALING-INFER-INTERVAL')return 'One positive-factor category. Canonical: below 1, equal to 1, above 1. Accepted aliases: '+intervalAliases.join('; ')+'. Select the mathematically correct category; acceptedAnswers must contain equivalents of that category only.';
 const narrow=outputGrammar(s);
 if(narrow)return narrow+' Unit words belong in the prompt, not the answer.';
 const domain=s.quantity==='Integer'?'signed integer':s.quantity==='Count'?'nonnegative integer':s.quantity==='Percent'?'percentage with %':s.answerObject.toLowerCase();
 return `One ${domain}. ${ANSWER_GRAMMARS[s.answerObject as keyof typeof ANSWER_GRAMMARS]||'Unsupported response type: repair required.'} ${expressionShape(s)==='exponents'?'The answer must contain a whole-number exponent.':expressionShape(s)==='grouped'?'The answer must be an unevaluated expression retaining grouping and operations.':''} Unit words belong in the prompt, not the answer.`;
}
export function expressionShape(s:Spec){return s.answerObject!=='Expression'?null:/exponent/i.test(s.requiredResult+' '+s.given)?'exponents':/group|unevaluated/i.test(s.requiredResult+' '+s.given)?'grouped':null;}
export function methodBan(text:string){return /\b(?:do not evaluate either|calculate both rates before comparing)\b/i.test(text)|| /\b(?:without (?:calculating|computing) (?:the |an? )?(?:exact )?(?:product|factor|quotient|answer)|do not (?:calculate|compute) (?:the |an? )?(?:exact )?(?:scale )?(?:product|factor|quotient|answer))\b/i.test(text);}
export function definedVariables(s:Spec,stem=''):Set<string>{
 const text=`${s.given} ${s.boundary} ${stem}`;
 // Recognize isolated symbols only. Arbitrary prose cannot become an identifier.
 return new Set((text.match(/(?<![A-Za-z])[A-Za-z](?![A-Za-z])/g)||[]).filter(v=>!['a','A','I'].includes(v)||new RegExp(`\\b${v}\\s*(?:=|represents|denotes|is the|counts)`).test(text)));
}
function algebra(source:string,variables:Set<string>):boolean{
 const t=source.replace(/−/g,'-').replace(/[×·]/g,'*').replace(/÷/g,'/').replace(/\s+/g,'');
 if(!t||t.length>100||/[^\d.A-Za-z+*/^()\-]/.test(t))return false;
 const tokens=t.match(/(?:\d+(?:\.\d+)?|\.\d+)|[A-Za-z]|[+*/^()\-]/g)||[];
 if(tokens.join('')!==t||/[A-Za-z]{2,}/.test(t))return false;
 let p=0,valid=true;
 const primary=():number|null=>{const x=tokens[p++];if(x===undefined){valid=false;return null;}if(x==='('){const n=sum();if(tokens[p++]!==')')valid=false;return n;}if(/^[A-Za-z]$/.test(x)){if(!variables.has(x))valid=false;return null;}if(/^(?:\d|\.)/.test(x))return Number(x);valid=false;return null;};
 const unary=():number|null=>{if(tokens[p]==='+'||tokens[p]==='-'){const sign=tokens[p++];const n=unary();return n===null?null:sign==='-'?-n:n;}return power();};
 const power=():number|null=>{let n=primary();if(tokens[p]==='^'){p++;const r=unary();n=n===null||r===null?null:Math.pow(n,r);}return n;};
 const product=():number|null=>{let n=unary();while(p<tokens.length){const op=tokens[p],implicit=/^(?:[A-Za-z]|\()$/.test(op);if(op!=='*'&&op!=='/'&&!implicit)break;if(!implicit)p++;const r=unary();if(op==='/'&&r===0)valid=false;n=n===null||r===null?null:op==='/'?n/r:n*r;}return n;};
 const sum=():number|null=>{let n=product();while(tokens[p]==='+'||tokens[p]==='-'){const op=tokens[p++],r=product();n=n===null||r===null?null:op==='+'?n+r:n-r;}return n;};
 const n=sum();return valid&&p===tokens.length&&(n===null||Number.isFinite(n));
}
const rational=(t:string)=>/^[−+-]?(?:\d+(?:\.\d+)?|\.\d+|(?:\d+\s+)?\d+\s*\/\s*\d+)$/.test(t.trim())&&scalarValue(t)!==null;
function genericResponseValid(v:string,s:Spec,stem=''):boolean{
 const t=v.trim();if(!t||t.length>160)return false;
 switch(s.answerObject){
 case 'Number':{const n=scalarValue(t);return n!==null&&Number.isFinite(n)&&(s.quantity!=='Probability'||n>=0&&n<=1)&&(s.quantity!=='Count'||Number.isInteger(n)&&n>=0)&&(s.quantity!=='Integer'||Number.isInteger(n))&&(s.quantity!=='Percent'||t.endsWith('%'));}
 case 'Repeating decimal':return /^[−+-]?\d+\.\d*\(\d+\)$/.test(t);
 case 'Quotient with remainder':return /^\d+\s+R\s+\d+$/.test(t);
 case 'Ordered pair':{const m=t.match(/^\(([^,]+),([^,]+)\)$/);return !!m&&rational(m[1])&&rational(m[2]);}
 case 'Ratio':{const a=t.split(':');return a.length===2&&a.every(rational)&&scalarValue(a[1])!==0;}
 case 'Comparison symbol':return ['<','>','=','≤','≥'].includes(t);
 case 'Label':if(isUnitLabel(s))return /^(?:cubic (?:milli|centi|kilo)?met(?:er|re)s?|(?:mm|cm|m|km)(?:³|\^3))$/i.test(t);if(s.structureCode==='SCALING-INFER-INTERVAL')return intervalAliases.includes(t.toLowerCase().replace(/\s*([<>=])\s*/g,'$1'));return /^[\p{L}\p{N}][\p{L}\p{N}\s-]*$/u.test(t)&&t.split(/\s+/).length<=3&&t.length<=60;
 case 'Symbol':return /sign/i.test(`${s.action} ${s.requiredResult}`)?['+','-','−'].includes(t):/^[A-Za-z]$/.test(t)&&definedVariables(s,stem).has(t);
 case 'Expression':return algebra(t,definedVariables(s,stem))&&(expressionShape(s)!=='exponents'||/\^\s*(?:\d+|\(\d+\))/.test(t))&&(expressionShape(s)!=='grouped'||/\([^()]*[+*/−×÷-][^()]*\)/.test(t));
 case 'Equation':case 'Inequality':{const a=t.split(s.answerObject==='Equation'?/=/ : /[<>≤≥]/);return a.length===2&&a.every(x=>algebra(x,definedVariables(s,stem)));}
 default:return false;
 }
}

/** Quotas use a reviewed semantic core, never a form-specific boolean. */
export function quotaSemantics(s:Spec){
 const core=s.structureFamilyId.split('|').at(-1)||s.structureCode;
 return semanticPolicy[core as keyof typeof semanticPolicy]||{comparison:s.comparison,comparisonCalculation:s.comparisonCalculation};
}
/** Policy unit: one Cartesian axes panel, independent of SVG/image container count. */
export function coordinatePlaneCount(s:Spec):number{
 if(s.visualPolicy!=='Required')return 0;
 const isGraph=['Coordinate Plane','Proportional Graph'].includes(s.representation);
 return isGraph?Math.max(1,s.coordinatePlanes||0):s.coordinatePlanes||0;
}
export function outputGrammar(s:Spec):string|null{
 const forms:Record<string,string>={
 'comparison-three':'Exactly one of <, >, =.',
 'numerical-expression':'One variable-free numerical expression, retaining the requested grouping/operations and whole-number exponents where assigned.',
 'strict-solved-inequality':'A solved strict inequality: one defined variable on one side, one numerical constant on the other; use < or > only.',
 'positive-simplest-ratio':'A ratio a:b with positive integer terms in simplest form.',
 'terminating-decimal':'One finite decimal or integer in base-ten notation; do not return a fraction, repeating notation, radical or pi expression.',
 'y=kx':'An equation in the explicit form y=kx with a numerical coefficient k and input x on the right. Equivalent reversed equations or unsimplified input expressions do not meet this output form.',
 'decimal-classification':'One label: terminating or nonterminating repeating. Accepted aliases: finite for terminating; repeating, recurring, nonterminating recurring for nonterminating repeating.',
 'exact-pi':'One exact rational multiple of pi. Do not list approximate decimals as exact accepted equivalents.'
 };
 return forms[s.outputForm||'']||null;
}
export function responseValid(v:string,s:Spec,stem=''):boolean{
 const t=v.trim().replace(/−/g,'-');
 if(s.outputForm==='decimal-classification')return ['terminating','finite','nonterminating repeating','repeating','recurring','nonterminating recurring'].includes(t.toLowerCase());
 if(!genericResponseValid(v,s,stem))return false;
 switch(s.outputForm){
 case 'comparison-three':return ['<','>','='].includes(t);
 case 'numerical-expression':return !/[A-Za-z]/.test(t);
 case 'terminating-decimal':return /^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(t);
 case 'positive-simplest-ratio':{const m=t.match(/^(\d+)\s*:\s*(\d+)$/);if(!m)return false;let a=Number(m[1]),b=Number(m[2]);if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<=0||b<=0)return false;while(b){[a,b]=[b,a%b];}return a===1;}
 case 'strict-solved-inequality':{const a=t.split(/[<>]/);if(a.length!==2||/[≤≥=]/.test(t))return false;return a.some((x,i)=>/^[A-Za-z]$/.test(x.trim())&&definedVariables(s,stem).has(x.trim())&&scalarValue(a[1-i].trim())!==null);}
 case 'y=kx':{const m=t.replace(/\s/g,'').match(/^y=(.*?)\*?x$/);if(!m)return false;let k=m[1].replace(/\*$/,'');if(k===''||k==='-'||k==='+')return true;if(k.startsWith('(')&&k.endsWith(')'))k=k.slice(1,-1);return scalarValue(k)!==null;}
 case 'exact-pi':return /pi|π/.test(t);
 default:return true;
 }
}
