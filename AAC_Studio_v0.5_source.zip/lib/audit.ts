import historicalFindings from '../data/audit-findings.json';
import currentFindings from '../data/v05/repair-register.json';
import previousFindings from '../data/v04/repair-register.json';
import type {Spec,Issue} from './model';
import {reviewedEvidence} from './task-integrity';
export const findings=[...currentFindings,...previousFindings,...historicalFindings];
// Historical findings remain in the repair register. Current readiness depends on
// the repaired catalog contract, never a permanent list of old question numbers.
export function allocationFindings(s:Spec):Issue[]{
 const e=reviewedEvidence(s);
 if(!e)return [{severity:'error',code:'bank-evidence',question:s.question,message:'This current allocation has no matching reviewed bank evidence.'}];
 if(e.dok!==s.dok||!e.dokRationale||!e.claimEvidence||!e.witnessSolution.length)return [{severity:'error',code:'bank-evidence',question:s.question,message:'Resolve the claim, DOK rationale and mathematical witness before generation.'}];
 return [];
}
