/** Restricted numerical answer grammar. No evaluation of code, variables, or arbitrary expressions. */
function rational(s:string):number|null{
 const raw=s.trim().replace(/−/g,'-');
 if(raw.includes(',')&&!/^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/.test(raw))return null;
 const t=raw.replace(/,/g,'');
 const m=t.match(/^([+-]?)(?:(\d+)\s+)?(\d+)\s*\/\s*(\d+)$/);
 if(m){if(+m[4]===0)return null;const n=(+(m[2]||0))+(+m[3]/+m[4]);return m[1]==='-'?-n:n;}
 if(!/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(t))return null;
 const n=Number(t);return Number.isFinite(n)?n:null;
}
export function scalarValue(input:string):number|null{
 if(input.length>100)return null;
 let s=input.trim().replace(/−/g,'-').replace(/\\pi\b|pi\b/g,'π').replace(/\\\(|\\\)/g,'').trim();
 if(s.endsWith('%')){const n=rational(s.slice(0,-1));return n===null?null:n/100;}
 const n=rational(s);if(n!==null)return n;
 const p=s.match(/^([+-]?(?:(?:\d+(?:\.\d+)?|\.\d+)(?:\s*\/\s*\d+)?)?)\s*(?:\*|×)?\s*π(?:\s*\/\s*(\d+))?$/);
 if(p){const a=['','+','-'].includes(p[1])?(p[1]==='-'?-1:1):rational(p[1]);const d=p[2]?+p[2]:1;return a===null||d===0?null:a*Math.PI/d;}
 // A small exact radical form, e.g. 2*sqrt(3), sqrt(2)/3, or √(5).
 const r=s.match(/^([+-]?(?:\d+(?:\.\d+)?)?)\s*(?:\*|×)?\s*(?:sqrt|√)\((\d+)\)(?:\s*\/\s*(\d+))?$/);
 if(r){const a=['','+','-'].includes(r[1])?(r[1]==='-'?-1:1):rational(r[1]);const d=r[3]?+r[3]:1;return a===null||d===0?null:a*Math.sqrt(+r[2])/d;}
 return null;
}
