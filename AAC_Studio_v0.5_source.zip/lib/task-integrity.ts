import evidence from '../data/v05/allocation-evidence.json';
import archive48 from '../data/v04/allocation-evidence.json';
import archivedEvidence from '../data/v03/allocation-evidence.json';
import type {Spec,Issue} from './model';
import {methodBan,quotaSemantics,coordinatePlaneCount} from './contracts';

/** Reviewed aliases and role-aware signatures supplement (never replace) the teacher's semantic review. */
const aliases:Record<string,string>={
 'AFFINE-MISSING-COUNT':'DIVIDE-REMAINDER-PORTION',
 'SOLVE-MUL-EQUATION':'MUL-MISSING-FACTOR',
 'SCALE-DRAWING-LENGTH':'CONVERT-SINGLE',
 'OPPOSITE-INVERSE':'NEGATE-VALUE',
 'OPPOSITE-LOCATION':'NEGATE-VALUE',
 'SHARE-NUMERATOR':'SHARING-RECOVER-TOTAL',
 'DIV-DIVIDEND':'SHARING-RECOVER-TOTAL',
};
export function reviewedEvidence(s:Spec){
 const r=evidence[s.key as keyof typeof evidence];
 return r&&s.structureFamilyId.startsWith('MATH49|')&&r.structureCode===s.structureCode&&r.claimId===s.claimId&&r.given===s.given&&Object.entries(r.contract).every(([k,v])=>JSON.stringify((s as unknown as Record<string,unknown>)[k])===JSON.stringify(v))?r:null;
}
export function semanticIdentity(s:Spec):string{
 const r=reviewedEvidence(s);if(r)return r.semanticKey;
 const previous=archive48[s.key as keyof typeof archive48];
 if(s.structureFamilyId.startsWith('MATH48|')&&previous&&previous.structureCode===s.structureCode)return previous.semanticKey;
 const old=archivedEvidence[s.key as keyof typeof archivedEvidence];
 if(s.structureFamilyId.startsWith('MATH47|')&&old&&old.structureCode===s.structureCode){const key=old.semanticKey;return ({'CONVERT-TOTAL':'CONVERT-ADD-COMPONENTS','CONVERT-THEN-RESTORE':'CONVERT-ADD-COMPONENTS','AFFINE-MISSING-COUNT':'AFFINE-MISSING-FACTOR','AFFINE-MISSING-RATE':'AFFINE-MISSING-FACTOR'} as Record<string,string>)[key]||key;}
 const code=s.structureCode||s.structureFamilyId.split('|').at(-1)||'';
 return aliases[code]||code;
}
export function taskIntegrity(s:Spec):Issue[]{
 const out:Issue[]=[];const error=(code:string,message:string)=>out.push({severity:'error',code,message,question:s.question});
 if(s.structureFamilyId.startsWith('MATH49|')&&!reviewedEvidence(s))error('catalog-evidence','The task no longer matches its reviewed catalog evidence. Reconcile the design before generation.');
 if(methodBan(s.given+' '+s.action+' '+s.boundary))error('method-ban','Remove the prescribed internal method; retain only the required response form.');
 if(/displayed data set/i.test(s.claim)&&s.visualPolicy==='Prohibited')error('claim-display','The displayed-data claim requires a display.');
 if(/\b(?:written explanation|justification|error analysis)\b/i.test(s.responseProduct))error('response-scope','The exact response product must remain objective, not written reasoning.');
 const quota=quotaSemantics(s);
 if(s.comparison!==quota.comparison||s.comparisonCalculation!==quota.comparisonCalculation)error('comparison-semantics','Comparison flags must match the canonical semantic core.');
 if(s.context==='Pure mathematics'&&/neutral (?:context|situation|statement|joining)|short joining|contextual|real-world|word problems/i.test(s.given+' '+s.claim))error('context-contract','A required neutral situation needs Neutral context and its 45-word budget.');
 if(s.wordLimit!==(s.context==='Neutral context'?45:20))error('context-budget','Context and language budget disagree.');
 if(s.coordinatePlanes!==undefined&&s.coordinatePlanes!==coordinatePlaneCount(s))error('plane-semantics','Coordinate axes panel count disagrees with the assigned representation.');
 if(s.structureCode==='MEAN-TO-TOTAL'&&s.quantity==='Count')error('sum-domain','A sum is not an observation count.');
 if(s.answerObject==='Number'&&/with compound units/i.test(s.requiredResult))error('unit-response','Numerical outputs must omit unit words; name units in the stem.');
 if(s.structureCode==='DECIMAL-CLASSIFY'&&/convert/i.test(s.claim))error('claim-action','Classification needs a classification claim, not a conversion claim.');
 if(s.structureCode==='DATA-MISSING-FREQUENCY'&&s.standard==='6.SP.B.4'&&s.evidenceType!=='supporting')error('standard-evidence','A frequency table alone is supporting evidence, not direct plotting evidence.');
 if(!s.action.trim()||!s.given.trim()||!s.requiredResult.trim())error('task-fields','The action, givens, and required result must all be readable and complete.');
 if(/OURni|tlIeDsEs|NNToInFeY|CBALTEE|GMOISRSYIN|eVqAuiLreUdE|\bSSh\b/.test(`${s.given} ${s.requiredResult}`))error('baseline-text','The comparison record contains damaged source text. Reconcile it with the accepted source.');

 if(s.standard==='5.NF.B.7'&&((s.given.match(/unit[- ]fraction/gi)||[]).length>=2)&&/(?:number|count).*groups|groups.*(?:number|count)/i.test(`${s.given} ${s.requiredResult}`))error('scope','5.NF.B.7 cannot assign a proper unit-fraction total divided by a proper unit-fraction group size. Redesign the actual given/unknown relationship.');
 if(/\b(?:graph (?:the )?solution|draw (?:the |a )?graph|explain|justify)\b/i.test(s.boundary.replace(/\b(?:do not|never)\b[^.;]*/gi,'')))error('response-scope','The binding task boundary requests a graph or written reasoning outside the allocated objective response. Move full-standard guidance to reference text.');
 if(s.visualPolicy==='Prohibited'&&s.representation!=='None')error('visual-scope','A prohibited visual must have representation None.');
 if(s.visualPolicy==='Required'&&s.representation==='None')error('visual-scope','A required visual needs an allocated representation.');
 if(s.responseMode==='mcq'&&/one concise question/i.test(s.given)&&/statistical or nonstatistical/i.test(s.action))error('choice-domain','One binary statistical classification does not supply four meaningful alternatives. Allocate four question candidates.');
 if(/(?:difference between.*(?:mean|median)|gap.*spread|difference in centers)/i.test(`${s.action} ${s.requiredResult}`)&&(!s.comparison||!s.comparisonCalculation))error('comparison-flags','This distribution comparison must count toward both comparison limits.');

 return out;
}

/** The mathematical dependency excludes administrative IDs, source labels, and review timestamps. */
export function mathematicalSpec(s:Spec){
 const keys=['key','claimId','standard','claim','action','given','requiredResult','answerObject','quantity','responseMode','visualPolicy','representation','footprint','structureCode','dok','variation','context','family','boundary','wordLimit','responseProduct','comparisonCalculation','comparison','statistics','expressionEligible','taskRuleId','metadataConfirmed','domainRules','outputForm','candidateDelivery','coordinatePlanes','evidenceType','evidenceNote','reviewStatus'] as const;
 return {...Object.fromEntries(keys.map(k=>[k,s[k]])),semanticIdentity:semanticIdentity(s),reviewedEvidence:reviewedEvidence(s)};
}
