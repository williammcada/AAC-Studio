import {hasStudentFraction} from './contracts';
/** Small, explicit math grammar shared by screen and native Word export. */
export type MathNode = {kind:'text';text:string}|{kind:'fraction';top:MathNode[];bottom:MathNode[]}|{kind:'sqrt';body:MathNode[]}|{kind:'script';base:MathNode;body:MathNode[];position:'super'|'sub'}|{kind:'group';body:MathNode[]};
const commands:Record<string,string>={times:'×',div:'÷',cdot:'·',pi:'π',le:'≤',leq:'≤',ge:'≥',geq:'≥',ne:'≠',neq:'≠',pm:'±',degree:'°',circ:'°',infty:'∞',angle:'∠',triangle:'△',parallel:'∥',perp:'⊥',approx:'≈','%':'%'};
export function parseMath(source:string):MathNode[]{
 let p=0;
 function group():MathNode[]{if(source[p]!=='{')throw Error('Use braces around fraction parts, powers, and roots.');p++;const out=seq(true);return out;}
 function atom():MathNode{
  const c=source[p++];if(!c)throw Error('Incomplete equation.');
  if(c==='{'){p--;return {kind:'group',body:group()};}
  if(c==='\\'){
   const match=source.slice(p).match(/^[A-Za-z]+|^[,%! ]/);if(!match)throw Error('Unsupported math command.');p+=match[0].length;const cmd=match[0];
   if(cmd==='frac'||cmd==='dfrac'||cmd==='tfrac')return {kind:'fraction',top:group(),bottom:group()};
   if(cmd==='sqrt')return {kind:'sqrt',body:group()};
   if(cmd==='text'||cmd==='mathrm'){const start=p;const body=group();if(source.slice(start,p).includes('\\'))throw Error('Keep text labels plain.');return {kind:'group',body};}
   if(cmd==='left'||cmd==='right')return atom();
   if([',','!',' '].includes(cmd))return {kind:'text',text:' '};
   if(commands[cmd])return {kind:'text',text:commands[cmd]};
   throw Error(`Unsupported equation command: \\${cmd}.`);
  }
  if('}^_'.includes(c))throw Error('Equation braces or powers are incomplete.');
  if(c==='/'||hasStudentFraction(c))throw Error('Use \\frac{numerator}{denominator} for a stacked fraction.');
  return {kind:'text',text:c==='-'?'−':c};
 }
 function seq(nested=false):MathNode[]{const out:MathNode[]=[];while(p<source.length&&source[p]!=='}'){
  let a=atom();while(source[p]==='^'||source[p]==='_'){const position=source[p++]==='^'?'super':'sub';const body=source[p]==='{'?group():[atom()];a={kind:'script',base:a,body,position};}out.push(a);
 }if(nested){if(source[p]!=='}')throw Error('Unclosed equation brace.');p++;}return out;}
 const result=seq();if(p!==source.length)throw Error('Unexpected equation brace.');return result;
}
export type Segment={kind:'text';text:string}|{kind:'math';nodes:MathNode[];source:string};
export function segments(text:string):Segment[]{
 const out:Segment[]=[];let at=0;const re=/\\\(([\s\S]*?)\\\)/g;let m:RegExpExecArray|null;
 while((m=re.exec(text))){if(m.index>at)out.push({kind:'text',text:text.slice(at,m.index)});out.push({kind:'math',source:m[1],nodes:parseMath(m[1])});at=re.lastIndex;}
 if(at<text.length)out.push({kind:'text',text:text.slice(at)});
 if(out.some(s=>s.kind==='text'&&/\\\(|\\\)|\\frac|\$/.test(s.text)))throw Error('Wrap equations in \\( ... \\). Use the currency name instead of a dollar sign.');
 return out;
}
export const xml=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]!));
export function omml(nodes:MathNode[]):string{return nodes.map(n=>{
 if(n.kind==='text')return `<m:r><m:t xml:space="preserve">${xml(n.text)}</m:t></m:r>`;
 if(n.kind==='fraction')return `<m:f><m:fPr><m:type m:val="bar"/></m:fPr><m:num>${omml(n.top)}</m:num><m:den>${omml(n.bottom)}</m:den></m:f>`;
 if(n.kind==='sqrt')return `<m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e>${omml(n.body)}</m:e></m:rad>`;
 if(n.kind==='group')return omml(n.body);
 const tag=n.position==='super'?'sSup':'sSub',part=n.position==='super'?'sup':'sub';return `<m:${tag}><m:e>${omml([n.base])}</m:e><m:${part}>${omml(n.body)}</m:${part}></m:${tag}>`;
}).join('');}
