import {env} from 'cloudflare:workers';
import type {WorkspaceData,State,HistoryEntry} from './model';
import {applyOperation,type Operation} from './operations';
type Bindings={DB:D1Database;BUCKET:R2Bucket};
const bindings=()=>{const b=env as unknown as Bindings;if(!b.DB||!b.BUCKET)throw Error('Workspace storage is unavailable.');return b;};
export async function readWorkspace():Promise<WorkspaceData>{
 const {DB,BUCKET}=bindings();const row=await DB.prepare('SELECT revision, snapshot_key FROM workspace WHERE id = ?').bind('main').first<{revision:number;snapshot_key:string|null}>();
 let state:State={forms:{}};if(row?.snapshot_key){const snapshot=await BUCKET.get(row.snapshot_key);if(!snapshot)throw Error('The saved workspace could not be loaded.');state=await snapshot.json<State>();}
 const history=await DB.prepare('SELECT id, revision, summary, created_at FROM events ORDER BY revision DESC LIMIT 60').all<HistoryEntry>();
 return {state,revision:row?.revision||0,history:history.results};
}
export async function readRevision(revision:number){const {DB,BUCKET}=bindings();const row=await DB.prepare('SELECT snapshot_key FROM events WHERE revision = ?').bind(revision).first<{snapshot_key:string}>();if(!row)throw Error('This revision is unavailable.');const file=await BUCKET.get(row.snapshot_key);if(!file)throw Error('This revision is unavailable.');return file.json<State>();}
export class RevisionConflict extends Error{}
export async function mutate(expectedRevision:number,operation:Operation){
 const {DB,BUCKET}=bindings(),current=await readWorkspace();if(current.revision!==expectedRevision)throw new RevisionConflict('The workspace changed in another tab. Reload the saved workspace, then retry. Your input is still here.');
 const result=await applyOperation(current.state,operation);const id=crypto.randomUUID(),now=new Date().toISOString(),key=`revisions/${id}.json`,next=expectedRevision+1;
 await BUCKET.put(key,JSON.stringify(result.state),{httpMetadata:{contentType:'application/json'}});
 const tx=await DB.batch([
  DB.prepare('INSERT INTO workspace (id, revision, snapshot_key, updated_at) VALUES (?, 0, NULL, ?) ON CONFLICT(id) DO NOTHING').bind('main',now),
  DB.prepare('UPDATE workspace SET revision = ?, snapshot_key = ?, updated_at = ? WHERE id = ? AND revision = ?').bind(next,key,now,'main',expectedRevision),
  DB.prepare('INSERT INTO events (id, revision, summary, created_at, snapshot_key) SELECT ?, ?, ?, ?, ? WHERE EXISTS (SELECT 1 FROM workspace WHERE id = ? AND snapshot_key = ?)').bind(id,next,result.summary,now,key,'main',key)
 ]);
 if(tx[1].meta.changes!==1){await BUCKET.delete(key);throw new RevisionConflict('The workspace changed in another tab. Reload and retry.');}
 return {...current,state:result.state,revision:next,history:[{id,revision:next,summary:result.summary,created_at:now},...current.history].slice(0,60)};
}

export async function readHistory(before:number){const {DB}=bindings();return (await DB.prepare('SELECT id, revision, summary, created_at FROM events WHERE revision < ? ORDER BY revision DESC LIMIT 60').bind(before).all<HistoryEntry>()).results;}
