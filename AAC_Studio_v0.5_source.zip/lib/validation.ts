import {checkTaskData} from './task-data';
import {scalarValue} from './exact-number';
import {seed,historicalSeed,slots,formKey,historicalLocks,currentYear,yearProject, type State,type Spec,type Item,type Issue,type Packet,type FormState,checklist} from './model';
import {segments} from './math';
import {z} from 'zod';
import {semanticIdentity,taskIntegrity,mathematicalSpec} from './task-integrity';
import {STUDIO_VERSION,CONTRACT_VERSION,DESIGN_POLICY,hasStudentFraction,TABLE_REPRESENTATIONS,responseValid,SVG_ATTRIBUTES,methodBan,responseDescription,quotaSemantics,coordinatePlaneCount} from './contracts';
import {allocationFindings} from './audit';
export {responseValid} from './contracts';
const short=z.string().max(1200);const id=z.string().min(3).max(110).regex(/^[A-Za-z0-9|._-]+$/);
const visualSchema=z.discriminatedUnion('kind',[
 z.object({kind:z.literal('svg'),svg:z.string().max(100000),alt:z.string().min(3).max(300)}).strict(),
 z.object({kind:z.literal('image'),dataUrl:z.string().max(550000),alt:z.string().min(3).max(300)}).strict(),
 z.object({kind:z.literal('table'),headers:z.array(z.string().max(120)).min(1).max(8),rows:z.array(z.array(z.string().max(120)).min(1).max(8)).min(1).max(12),alt:z.string().min(3).max(300)}).strict()
]);
export const itemSchema=z.object({taskData:z.record(z.string(),z.union([z.number().finite(),z.array(z.number().finite()).max(30)])).optional(),question:z.number().int().min(1).max(15),specificationHash:id,templateId:id,surfaceFormId:id,structureFamilyId:id,stem:short.min(1),choices:z.array(z.string().min(1).max(240)).max(4).default([]),answer:z.string().min(1).max(160),acceptedAnswers:z.array(z.string().min(1).max(160)).max(10).default([]),scoringNote:short.min(1),solution:z.array(short.min(1)).min(1).max(12),visual:visualSchema.nullable(),reviewNote:short.default('')}).strict();
export const resultSchema=z.object({schema:z.literal('aac.result.v1'),projectId:z.string(),seedHash:z.literal(seed.seedHash),packetId:id,designRevision:id,grade:z.number().int(),form:z.number().int(),items:z.array(itemSchema).length(15)}).strict();
export const stable=(v:unknown):string=>JSON.stringify(v,(_,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.entries(x).sort(([a],[b])=>a.localeCompare(b))):x);
export async function digest(v:unknown){const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(stable(v)));return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');}
export function adjacentSlots(g:number,f:number){return [...slots(g,f===1?8:f-1),...slots(g,f===8?1:f+1)];}
export function pairedSlots(g:number,f:number){return [5,6,7].filter(x=>Math.abs(x-g)===1).flatMap(x=>slots(x,f));}
export function effective(spec:Spec,state:State):Spec{if(historicalLocks(state)&&spec.form<4)return historicalSeed.items.find(s=>s.key===spec.key)||spec;const entry=state.forms[formKey(spec.grade,spec.form)];const item=entry?.status==='finalized'?entry.items.find(i=>i.question===spec.question):null;const accepted=entry?.status==='finalized'?entry.packet.items.find(i=>i.question===spec.question):null;return item&&accepted?{...spec,...Object.fromEntries(Object.keys(spec).map(k=>[k,accepted[k as keyof typeof accepted]])),templateId:item.templateId,surfaceFormId:item.surfaceFormId} as Spec:spec;}
export async function designRevision(g:number,f:number,state:State){return digest({policy:seed.policyVersion,contract:CONTRACT_VERSION,designPolicy:DESIGN_POLICY,items:slots(g,f).map(mathematicalSpec),adjacent:adjacentSlots(g,f).map(i=>mathematicalSpec(effective(i,state))),paired:pairedSlots(g,f).map(i=>mathematicalSpec(effective(i,state)))});}
const count=(a:Spec[],f:(s:Spec)=>boolean)=>a.filter(f).length;
function repeated(values:string[]){return [...new Set(values.filter((v,i)=>v&&values.indexOf(v)!==i))];}
export function validateBlueprint(g:number,f:number,state:State={forms:{}}):Issue[]{
 const a=slots(g,f),out:Issue[]=[];const err=(code:string,message:string,q?:number)=>out.push({severity:'error',code,message,question:q});
 if(a.length!==15){err('slots','The form must have 15 assigned items.');return out;}
 if(f<4&&historicalLocks(state))return out;

 for(const s of a){
  out.push(...taskIntegrity(s),...allocationFindings(s));
  if(!s.metadataConfirmed)err('source','The assigned source metadata requires reconciliation.',s.question);
  const r=seed.taskRules[s.taskRuleId as keyof typeof seed.taskRules];
  if(!r){err('task','A catalog task rule is missing.',s.question);continue;}
  for(const k of Object.keys(r).filter(k=>!['dokMin','dokMax'].includes(k))){if(stable((s as unknown as Record<string,unknown>)[k])!==stable((r as unknown as Record<string,unknown>)[k]))err('task',`Assigned ${k} differs from its catalog task rule.`,s.question);}
  const dimensions:Record<string,string[]>={Number:['Unitless','Linear','Square','Cubic','Angle','Count','Percent','Probability','Rate','Time','Integer'],Label:['Category'],Symbol:['Symbolic'], 'Comparison symbol':['Relation'],Equation:['Symbolic'],Inequality:['Relation'],Expression:['Symbolic'], 'Ordered pair':['Location'],Ratio:['Ratio'],'Repeating decimal':['Unitless'],'Quotient with remainder':['Unitless']};
  if(!dimensions[s.answerObject]?.includes(s.quantity))err('quantity','The answer object and quantity dimension are incompatible.',s.question);
  if(s.dok<r.dokMin||s.dok>r.dokMax)err('dok','DOK differs from the task rule.',s.question);
  if(!['Required','Prohibited'].includes(s.visualPolicy))err('visual','Resolve the visual policy before generation.',s.question);
  if(s.statistics==='Vocabulary'&&s.responseMode!=='mcq')err('statistics','Statistics vocabulary requires MCQ.',s.question);
  if(s.statistics==='Numeric'&&s.responseMode!=='shortAnswer')err('statistics','Numeric statistics requires short answer for these allocations.',s.question);
  if(s.footprint==='Large Visual'&&(s.question<12||s.question>14))err('visual','Large visuals are limited to Questions 12–14.',s.question);
  const conflicts=[...adjacentSlots(g,f),...pairedSlots(g,f)].map(x=>effective(x,state)).filter(x=>semanticIdentity(x)===semanticIdentity(s));
  if(conflicts.length)out.push({severity:s.structureFamilyId.startsWith('MATH49|')&&conflicts.some(x=>x.structureFamilyId.startsWith('MATH49|'))?'error':'warning',code:'core-candidate',question:s.question,message:`Matching semantic signature with ${conflicts.map(x=>`G${x.grade} V${x.form} Q${x.question}`).join(', ')}. Reviewed current-design signatures must be distinct. Historical comparisons also require item review.`});
 }
 for(const [name,values] of [['structure',a.map(semanticIdentity)],['claim',a.map(s=>s.claimId)]] as const){if(repeated(values).length)out.push({severity:'error',code:name,message:`Repeated ${name} within the form${name==='structure'?'; review the actual mathematical relationships':''}.`});}
 if(count(a,s=>s.responseMode==='mcq')>2)err('response','At most two MCQs are allowed.');
 const d1=count(a,s=>s.dok===1),d2=count(a,s=>s.dok===2),d3=count(a,s=>s.dok===3);
 if(d1<4||d1>6||d2<8||d2>10||d3>1||d1+d2+d3!==15)err('dok','DOK counts must be 4–6 at level 1, 8–10 at level 2, and 0–1 at level 3.');
 // Intrinsic variation labels describe the task; only mathematical signatures
 // establish exclusion compliance. Inherited label quotas are retired in V0.4.
 if(count(a,s=>s.responseMode==='shortAnswer'&&s.answerObject==='Expression')>1)err('expression','At most one expression answer is allowed.');
 if(count(a,s=>quotaSemantics(s).comparisonCalculation)>1||count(a,s=>quotaSemantics(s).comparison)>2)err('comparison','Comparison calculation limit is one; total comparison limit is two.');
 if(count(a,s=>s.footprint==='Large Visual')>3)err('visual','At most three large visuals are allowed.');
 const planes=(g===5||g===6)?[...slots(5,f),...slots(6,f)]:a;
 if(planes.reduce((n,s)=>n+coordinatePlaneCount(effective(s,state)),0)>1)err('planes','The shared coordinate-plane limit is one Cartesian axes panel, including proportional graphs.');
 for(const c of seed.clusters.filter(c=>c.grade===g)){const n=count(a,s=>s.cluster===c.code);if(n<c.min||n>c.max)err('cluster',`${c.code}: ${n} items; expected ${c.min}–${c.max}.`);}
 if(g===7)for(const standard of ['7.RP.A.1','7.RP.A.2','7.RP.A.3'])if(count(a,s=>s.standard===standard)!==1)err('ratio',`${standard} must appear exactly once.`);
 const coverage=new Set(seed.items.map(i=>i.claimId));if(seed.claims.some(c=>!coverage.has(c.id)))err('coverage','The bank does not cover all registered claims.');
 const difficulty=['Easy','Medium','Hard'].map(d=>count(a,s=>s.difficulty===d));
 if(difficulty.join('/')!=='3/9/3')out.push({severity:'warning',code:'difficulty-target',message:`Provisional difficulty ${difficulty.join('/')} (easy/medium/hard) differs from the nonblocking 3/9/3 target.`});
 out.push({severity:'warning',code:'educator-review',message:'Automated preflight does not establish mathematical validity, DOK, standard mastery or visual meaning. Review the realized items before finalizing.'});
 out.push({severity:'warning',code:'visual-workload',message:`${count(a,s=>s.visualPolicy==='Required')} required visuals; inspect print size, label mapping, essential information and whole-form workload.`});
 for(const s of a)if(s.evidenceType==='supporting')out.push({severity:'warning',code:'supporting-evidence',question:s.question,message:s.evidenceNote||'Supporting calculation only; not direct evidence of the entire standard.'});
 for(const b of [...adjacentSlots(g,f),...pairedSlots(g,f)])for(const issue of taskIntegrity(effective(b,state)).filter(x=>x.code==='baseline-text'||x.code==='task-fields'))err('baseline',`G${b.grade} V${b.form} Q${b.question}: ${issue.message}`);
 if([...adjacentSlots(g,f),...pairedSlots(g,f)].some(s=>!s.metadataConfirmed))err('baseline','A comparison baseline has unresolved source metadata.');
 return out;
}
export function validateSvg(svg:string):string|null{
 if(!/^\s*<svg\b/.test(svg)||!/<\/svg>\s*$/.test(svg))return 'Supply one complete SVG.';
 const allowed=new Set(['svg','g','path','line','rect','circle','ellipse','polyline','polygon','text','tspan','title','desc']);
 if(/<!|<\?|&(?!(?:amp|lt|gt|quot|apos);)|\b(?:href|style|on\w+|src)\s*=|url\s*\(/i.test(svg))return 'The SVG contains unsupported active or external content.';
 const attrs=new Set(SVG_ATTRIBUTES);
 const stack:string[]=[];const tags=svg.match(/<[^>]*>/g)||[];
 for(const tag of tags){const m=tag.match(/^<(\/?)([A-Za-z]+)([\s\S]*?)>$/);if(!m||!allowed.has(m[2]))return 'SVG element is unsupported.';
  if(m[1]){if(stack.pop()!==m[2]||m[3].trim())return 'SVG tags are not balanced.';continue;}
  const rest=m[3].replace(/\/$/,'');const clean=rest.replace(/\s+([A-Za-z][\w:-]*)\s*=\s*("[^"]*"|'[^']*')/g,(_,name)=>{if(!attrs.has(name))throw Error(`Unsupported SVG attribute: ${name}.`);return '';});
  if(clean.trim())return 'SVG attributes must be quoted.';if(!tag.endsWith('/>'))stack.push(m[2]);
 }
 if(stack.length)return 'SVG tags are not balanced.';
 const root=svg.match(/^\s*<svg\b([^>]*)>/)?.[1]||'';
 const box=root.match(/\bviewBox\s*=\s*(["'])([\s\S]*?)\1/)?.[2];
 const values=box?.trim().split(/[\s,]+/).map(Number);
 if(!values||values.length!==4||!values.every(Number.isFinite)||values[2]<=0||values[3]<=0)return 'SVG requires a quoted viewBox with four finite numbers and positive width/height.';
 if(hasStudentFraction(svg.replace(/<[^>]+>/g,'')))return 'Put fractions in native equations outside the image.';
 return null;
}
export function validateItem(i:Item,s:Spec,state:State,all:Item[]):Issue[]{
 const issues:Issue[]=[];const fail=(code:string,message:string)=>issues.push({severity:'error',code,message,question:s.question});
 if(i.structureFamilyId!==s.structureFamilyId)fail('structure','The Structure Family ID must match the assigned core.');
 const student=[i.stem,...i.choices,...(i.visual?.kind==='table'?[...i.visual.headers,...i.visual.rows.flat()]:[])];
 for(const t of student){try{segments(t);}catch(e){fail('math',(e as Error).message);}if(hasStudentFraction(t))fail('fraction','Student fractions must use \\frac inside \\( ... \\).');}
 if(/\b(give (?:a reason|reasons)|state (?:a reason|reasons)|explain|justify|justification|show (?:your|the) work|describe (?:your|the) (?:method|reasoning)|write (?:a|the) rule|error analysis|correct the error|use (?:a|the) (?:standard algorithm|method|strategy))\b/i.test(i.stem))fail('language','The student prompt asks for a prohibited response or prescribed method.');
 const words=i.stem.replace(/\\\([\s\S]*?\\\)/g,'math').trim().split(/\s+/).filter(Boolean).length;
 if(methodBan(i.stem))fail('language','Do not prescribe or forbid an internal calculation method; specify only the response required.');
 if(words>s.wordLimit)fail('length',`The stem has ${words} words; the assigned limit is ${s.wordLimit}. Each equation counts as one word.`);
 if(s.visualPolicy==='Prohibited'&&i.visual)fail('visual','This item prohibits a visual.');
 if(s.visualPolicy==='Required'&&!i.visual)fail('visual',`A ${s.representation.toLowerCase()} is required.`);
 if(i.visual?.kind==='svg'){try{const e=validateSvg(i.visual.svg);if(e)fail('visual',e);}catch(e){fail('visual',(e as Error).message);}}
 if(i.visual?.kind==='image'){
  const m=i.visual.dataUrl.match(/^data:image\/(png|jpeg);base64,([A-Za-z0-9+/]+={0,2})$/);if(!m)fail('visual','Images must be embedded PNG or JPEG files.');
  else if((m[1]==='png'&&!m[2].startsWith('iVBORw0KGgo'))||(m[1]==='jpeg'&&!m[2].startsWith('/9j/')))fail('visual','Image bytes do not match the declared format.');
 }
 if(i.visual?.kind==='table'&&!TABLE_REPRESENTATIONS.includes(s.representation))fail('visual',`A table does not satisfy the assigned ${s.representation.toLowerCase()}.`);
 if(i.visual?.kind==='table'){const width=i.visual.headers.length;if(i.visual.rows.some(r=>r.length!==width))fail('visual','Each table row must match the header width.');}
 if(s.responseMode==='mcq'){
  if(i.choices.length!==4||new Set(i.choices.map(t=>t.trim())).size!==4)fail('mcq','Supply four distinct options.');
  if(!/^[ABCD]$/.test(i.answer)||i.acceptedAnswers.some(t=>t!==i.answer))fail('answer','The MCQ answer must be A, B, C, or D.');
 }else{if(i.choices.length)fail('response','The assigned response is short answer. Remove choices.');if([i.answer,...i.acceptedAnswers].some(v=>!responseValid(v,s,i.stem)))fail('answer',responseDescription(s));}
 if(s.structureFamilyId.startsWith('MATH49|'))for(const answer of [i.answer,...i.acceptedAnswers])for(const message of checkTaskData(s,i.taskData,scalarValue(answer)))fail('task-data',message);
 const others=seed.items.filter(x=>x.key!==s.key).map(x=>{const draft=state.forms[formKey(x.grade,x.form)];const item=draft?.items.find(y=>y.question===x.question);return {grade:x.grade,form:x.form,templateId:item?.templateId||x.templateId,surfaceFormId:item?.surfaceFormId||x.surfaceFormId};});
 if(others.some(x=>x.surfaceFormId===i.surfaceFormId)||all.some(x=>x.question!==i.question&&x.surfaceFormId===i.surfaceFormId))fail('id','Surface Form ID is already used.');
 if(others.some(x=>x.grade===s.grade&&x.form===s.form&&x.templateId===i.templateId)||all.some(x=>x.question!==i.question&&x.templateId===i.templateId))fail('id','Template IDs must be unique within the form.');
 if(others.filter(x=>x.grade===s.grade&&x.form!==s.form&&x.templateId===i.templateId).length>=2)fail('id','A Template ID can appear at most twice in a grade bank.');
 if(all.some(x=>x.question!==i.question&&x.stem.trim().toLowerCase()===i.stem.trim().toLowerCase()))fail('duplicate','This student prompt repeats another item.');
 const teacher:Record<string,string[]>={answer:[i.answer],acceptedAnswers:i.acceptedAnswers,scoringNote:[i.scoringNote],solution:i.solution,reviewNote:[i.reviewNote]};
 for(const [field,texts] of Object.entries(teacher))for(const [index,text] of texts.entries()){try{segments(text);}catch(e){fail('export-math',`${field}[${index}]: ${(e as Error).message}`);}}

 return issues;
}
export async function makePacket(g:number,f:number,state:State,diagnostic=false):Promise<Packet>{
 if(f<4&&historicalLocks(state))throw Error('Forms 1–3 remain finalized and locked in the original assessment year. Create a new assessment year to regenerate them.');
 const issues=validateBlueprint(g,f,state),errors=issues.filter(i=>i.severity==='error');if(errors.length&&!diagnostic)throw Error(errors.map(i=>i.message).join(' '));
 const revision=await designRevision(g,f,state),old=state.forms[formKey(g,f)];if(old?.status==='finalized')throw Error('Finalized forms cannot be regenerated.');if(old?.packet.seedHash===seed.seedHash&&old.packet.designRevision===revision&&old.packet.purpose===(diagnostic?'diagnostic':'generation')&&old.packet.contractVersion===CONTRACT_VERSION)return old.packet;
 const assigned=slots(g,f);
 return {schema:'aac.packet.v1',projectId:yearProject(state),assessmentYear:currentYear(state),purpose:diagnostic?'diagnostic':'generation',studioVersion:STUDIO_VERSION,blueprintVersion:seed.blueprintVersion,contractVersion:CONTRACT_VERSION,preflightIssues:issues,seedHash:seed.seedHash,packetId:crypto.randomUUID(),designRevision:revision,grade:g,form:f,issuedAt:new Date().toISOString(),items:await Promise.all(assigned.map(async s=>({...s,specificationHash:await digest(s),proposedTemplateId:`${historicalLocks(state)?'':currentYear(state).id+'-'}${s.claimId}-${s.structureCode}-V${String(f).padStart(2,'0')}-T01`,proposedSurfaceFormId:`${historicalLocks(state)?'AAC-26-27':yearProject(state)}-G${g}-F${String(f).padStart(2,'0')}-Q${String(s.question).padStart(2,'0')}-SF01`}))),adjacent:adjacentSlots(g,f).map(s=>effective(s,state)),paired:pairedSlots(g,f).map(s=>effective(s,state))};
}
export async function parseResult(input:unknown,packet:Packet,state:State){
 if(packet.purpose==='diagnostic'||packet.purpose==='audit')throw Error('Diagnostic packets accept conflict reports only; they cannot accept or finalize student items.');
 if(packet.projectId!==yearProject(state))throw Error('This packet belongs to a different assessment year.');
 if(packet.seedHash!==seed.seedHash)throw Error('This packet uses the previous blueprint. Refresh the packet in Generate; your saved draft stays in history.');
 const result=resultSchema.safeParse(input);if(!result.success)throw Error(result.error.issues.slice(0,6).map(i=>`${i.path.join('.')||'Import'}: ${i.message}`).join('\n'));
 const r=result.data;
 if(r.projectId!==packet.projectId||r.packetId!==packet.packetId||r.designRevision!==packet.designRevision||r.grade!==packet.grade||r.form!==packet.form)throw Error('This result belongs to a different or superseded packet. Export the current packet and regenerate the result.');
 if(packet.designRevision!==await designRevision(packet.grade,packet.form,state))throw Error('A comparison form changed after this packet was issued. Export a current packet before importing.');
 if(new Set(r.items.map(i=>i.question)).size!==15)throw Error('The result must contain Questions 1–15 exactly once.');
 for(const i of r.items){const s=packet.items.find(s=>s.question===i.question)!;if(i.specificationHash!==s.specificationHash)throw Error(`Question ${i.question}: assigned specification fingerprint differs from the packet.`);}
 return r.items.sort((a,b)=>a.question-b.question).map(i=>({...i,reviewed:false})) as Item[];
}
export async function validateForm(entry:FormState,state:State):Promise<Issue[]>{
 const {grade:g,form:f}=entry.packet;const out=entry.status==='finalized'?[]:validateBlueprint(g,f,state);if(entry.packet.purpose==='diagnostic'||entry.packet.purpose==='audit')out.push({severity:'error',code:'diagnostic',message:'This packet is for diagnosis only. Resolve the allocation findings and issue a generation packet before finalization.'});if(entry.conflict?.status==='open')out.push({severity:'error',code:'reported-conflict',message:'Resolve the saved generation conflict before finalizing.'});if(entry.status!=='finalized'&&(entry.packet.seedHash!==seed.seedHash||entry.packet.designRevision!==await designRevision(g,f,state)))out.push({severity:'error',code:'stale',message:'The blueprint or a comparison task changed. Refresh the packet and import an updated result.'});
 if(entry.items.length!==15)out.push({severity:'error',code:'items',message:'Import all 15 items before finalization.'});
 for(const i of entry.items){const s=entry.packet.items.find(s=>s.question===i.question);if(s)out.push(...validateItem(i,s,state,entry.items));}
 return out;
}
export async function canFinalize(entry:FormState,state:State){const issues=await validateForm(entry,state);if(entry.items.filter(i=>i.reviewed).length!==15)issues.push({severity:'error',code:'review',message:'Review and accept all 15 items.'});for(const [k,label] of Object.entries(checklist))if(!entry.checks[k])issues.push({severity:'error',code:'review',message:label});return issues;}
