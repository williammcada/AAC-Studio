import type {Spec} from './model';
export type TaskData=Record<string,number|number[]>;
const policies:Record<string,{fields:string;kind:string}>={
 'WHOLE-QUOTIENT-ROW-GROUPS':{fields:'rows, perRow, groupSize, suppliedTotal (0 means withheld; 1 means supplied)',kind:'groups'},
 'MEAN-TO-TOTAL':{fields:'mean, count',kind:'mean-total'},
 'DECIMAL-PRODUCT-DERIVED-FACTOR':{fields:'length, reduction',kind:'rectangle'},
 'TEST-EQUATION-AND-INEQUALITY':{fields:'candidates (array); coefficients [a,b,c] for ax²+bx+c=0; bound; direction (-1 for x<bound, 1 for x>bound)',kind:'candidate-intersection'},
 'TEST-TWO-CONDITIONS':{fields:'candidates (array); coefficients [a,b,c] for ax²+bx+c=0; bound; direction (-1 for x<bound, 1 for x>bound)',kind:'candidate-intersection'},
 'ADJACENT-LINEAR-ANGLE-SOLVE':{fields:'a, b, c, d for angles ax+b and cx+d',kind:'angles'},
 'LCM':{fields:'inputs (two integers)',kind:'lcm'},
 'SIMPLE-INTEREST-PRINCIPAL':{fields:'interest, rate (decimal), time',kind:'interest'},
 'UNIT-RATE-DIFFERENCE':{fields:'numerators (two numbers), denominators (two numbers), in the common stem units',kind:'rate-gap'},
 'DATA-MISSING-FREQUENCY':{fields:'known (array of frequencies), total',kind:'frequency'},
};
export function taskDataPolicy(s:Spec){return policies[s.structureCode]||null;}
/** Tests declared numerical inputs; matching those inputs to prose/figures remains a review gate. */
export function checkTaskData(s:Spec,data:TaskData|undefined,answer:number|null):string[]{
 const p=taskDataPolicy(s);if(!p)return [];
 if(!data)return ['Supply taskData for '+p.kind+': '+p.fields+'.'];
 const d=data as Record<string,any>,errors:string[]=[];
 const require=(v:boolean,m:string)=>{if(!v)errors.push(m);};
 const finite=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
 const positive=(v:unknown)=>finite(v)&&v>0;
 const integer=(v:unknown)=>finite(v)&&Number.isSafeInteger(v);
 const close=(a:number,b:number)=>Math.abs(a-b)<=1e-10*Math.max(1,Math.abs(a),Math.abs(b));
 const result=(n:number)=>require(answer!==null&&Number.isFinite(n)&&close(answer,n),'Answer disagrees with the declared taskData result.');
 switch(p.kind){
 case 'groups':require([d.rows,d.perRow,d.groupSize].every(v=>integer(v)&&v>0)&&d.groupSize>=10&&d.groupSize<=99&&d.rows*d.perRow<=9999,'Positive integer rows/items, two-digit group size and at most four-digit total required.');require(d.suppliedTotal===0,'Withhold the derived total.');require(d.rows*d.perRow%d.groupSize===0,'New groups must divide exactly.');result(d.rows*d.perRow/d.groupSize);break;
 case 'mean-total':require(finite(d.mean)&&integer(d.count)&&d.count>0,'Mean is finite; observation count is a positive integer.');result(d.mean*d.count);break;
 case 'rectangle':require(positive(d.length)&&positive(d.reduction)&&d.reduction<d.length,'Require 0 < reduction < length.');require([d.length,d.reduction].every(v=>finite(v)&&close(v*100,Math.round(v*100))),'Decimal dimensions have at most two decimal places.');result(d.length*(d.length-d.reduction));break;
 case 'candidate-intersection':{
  const candidates=d.candidates,cs=d.coefficients;
  if(!Array.isArray(candidates)||!Array.isArray(cs)){errors.push('Supply candidate and coefficient arrays.');break;}
  require(candidates.length===4&&new Set(candidates).size===4&&candidates.every(v=>integer(v)&&v>=0&&v<=12),'Four distinct whole candidates 0–12 required.');
  require(cs.length===3&&cs.every(v=>integer(v)&&Math.abs(v)<=144)&&(cs[0]!==0||cs[1]!==0),'A bounded nontrivial quadratic-or-lower equation is required.');
  require(finite(d.bound)&&[-1,1].includes(d.direction),'Supply a finite bound and strict inequality direction.');
  const matches=candidates.filter(x=>cs[0]*x*x+cs[1]*x+cs[2]===0),joint=matches.filter(x=>d.direction===-1?x<d.bound:x>d.bound);
  require(matches.length===2&&matches.length<candidates.length&&joint.length===1,'Exactly two equation matches, at least one nonmatch, and one joint match required.');if(joint.length===1)result(joint[0]);break;
 }
 case 'angles':{require([d.a,d.b,d.c,d.d].every(finite)&&d.a+d.c!==0,'Finite coefficients and a+c nonzero required.');const x=(180-d.b-d.d)/(d.a+d.c),u=d.a*x+d.b,v=d.c*x+d.d;require(u>0&&u<180&&v>0&&v<180&&close(u+v,180),'Both angles must lie strictly between 0 and 180 and sum to 180.');result(u);break;}
 case 'lcm':{const a=d.inputs;if(!Array.isArray(a)||a.length!==2||!a.every(v=>integer(v)&&v>0&&v<=12)){errors.push('Two positive integer inputs no greater than 12 required.');break;}let [x,y]=a;while(y)[x,y]=[y,x%y];result(a[0]*a[1]/x);break;}
 case 'interest':require(positive(d.interest)&&positive(d.rate)&&integer(d.time)&&d.time>0,'Interest and rate must be positive; time a positive whole number.');result(d.interest/(d.rate*d.time));break;
 case 'rate-gap':{const n=d.numerators,b=d.denominators;if(!Array.isArray(n)||!Array.isArray(b)||n.length!==2||b.length!==2||!n.every(finite)||!b.every(positive)){errors.push('Two finite quantities and positive denominator quantities required.');break;}result(Math.abs(n[0]/b[0]-n[1]/b[1]));break;}
 case 'frequency':{const a=d.known;if(!Array.isArray(a)||!a.length||!a.every(v=>integer(v)&&v>=0)||!integer(d.total)||d.total<=0){errors.push('Nonnegative integer frequencies and positive integer total required.');break;}const missing=d.total-a.reduce((x,y)=>x+y,0);require(missing>=0,'Known frequencies cannot exceed the total.');result(missing);break;}
 }
 return errors;
}
