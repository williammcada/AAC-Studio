import assert from 'node:assert/strict';
import {writeFileSync,mkdirSync} from 'node:fs';
import {seed,type Spec,type Packet} from '../lib/model';
import archive from '../data/blueprint-4.8-original.json';
import {applyOperation,backup,verifyBackup} from '../lib/operations';
import {makePacket,validateBlueprint,validateItem,digest,stable,parseResult} from '../lib/validation';
import {packetText} from '../lib/packet';
import {responseValid,coordinatePlaneCount,quotaSemantics,methodBan} from '../lib/contracts';
import {reviewedEvidence,taskIntegrity,semanticIdentity} from '../lib/task-integrity';
import {checkTaskData} from '../lib/task-data';
import {completedWitness} from './witness-result';
let checks=0;const ok=(v:unknown,m:string)=>{assert.ok(v,m);checks++;};
const state=(await applyOperation({forms:{}},{kind:'createYear',label:'v0.5 isolated regression',yearKind:'test'})).state;
const find=(c:string)=>seed.items.find(s=>s.structureCode===c)!;
for(const s of seed.items){
 ok(!!reviewedEvidence(s),'contract evidence '+s.key);ok(taskIntegrity(s).length===0,'task integrity '+s.key);
 ok(!reviewedEvidence({...s,outputForm:'mutated'}),'output policy is binding');
 ok(!reviewedEvidence({...s,domainRules:['mutated']}),'domain policy is binding');
 ok(s.wordLimit===(s.context==='Neutral context'?45:20),'context budget');
 ok(s.comparison===quotaSemantics(s).comparison,'canonical comparisons');
 if(s.quantity==='Count'&&!/DIV|PORTION|BUDGET|QUOTIENT/.test(s.structureCode))ok(!s.domainRules.some(x=>/divisor\/group\/portion/.test(x)),'no inherited divisor boilerplate');
}
let comparisons=0;const hashes=new Set<string>();
for(const g of [5,6,7])for(let f=1;f<=8;f++){
 const p=await makePacket(g,f,state),issues=validateBlueprint(g,f,state),text=packetText(p);
 ok(!issues.some(i=>i.severity==='error'),'clean hard preflight');ok(issues.some(i=>i.code==='educator-review'),'review disclosure');ok(issues.some(i=>i.code==='difficulty-target'),'target deviations visible');
 ok(p.items.length===15&&p.adjacent.length===30&&p.paired.length===(g===6?30:15),'matrix counts');
 for(const s of p.items){ok(s.specificationHash===await digest(seed.items.find(x=>x.key===s.key)),'hash source');hashes.add(s.proposedSurfaceFormId);}
 for(const s of [...p.adjacent,...p.paired]){ok(stable(s)===stable(seed.items.find(x=>x.key===s.key)),'source/excerpt identity');comparisons++;}
 ok(text.includes('taskDataContract')&&(text.includes('numeric candidate')||text.includes('Numeric candidate')),'candidate and numerical verification delivery');
 ok(text.includes('warnings require review'),'preflight scope');
}
ok(comparisons===1200&&hashes.size===360,'all matrix identities');
const old=archive.items.filter(s=>s.grade===6&&s.form===2);ok(old.filter(s=>quotaSemantics(s).comparison).length===3,'old V2 correctly classified as three comparisons');
const graph=seed.items.find(s=>s.representation==='Proportional Graph')!;
ok(coordinatePlaneCount(graph)===1,'shared plane');ok(coordinatePlaneCount({...graph,coordinatePlanes:4})===4,'four panels count four');ok(coordinatePlaneCount({...graph,representation:'Coordinate Plane'})===1,'representation aliases');
const mutate=find('ADD-TWO');ok(taskIntegrity({...mutate,context:'Pure mathematics',given:'A neutral situation.'}).some(i=>i.code==='context-contract'),'context contradiction');
ok(methodBan('do not evaluate either')&&methodBan('calculate both rates before comparing'),'method mandates');ok(!methodBan('Return an unevaluated expression.'),'output forms preserved');
const response=(c:string,good:string[],bad:string[])=>{const s=find(c);for(const v of good)ok(responseValid(v,s,'x is the input and y is the output.'),'accept '+c+': '+v);for(const v of bad)ok(!responseValid(v,s,'x is the input and y is the output.'),'reject '+c+': '+v);};
response('MEAN-TO-TOTAL',['-7.5','0','3/2'],['3 liters']);
response('FRACTION-TO-DECIMAL',['0.25','-2.5'],['1/4','0.(3)','sqrt(2)']);
response('DECIMAL-CLASSIFY',['terminating','finite','nonterminating repeating','repeating'],['0.25','irrational']);
response('COMPARE-TWO',['<','>','='],['≤','≥']);
response('TRANSLATE-EXPONENTIAL',['2^3*(4+1)'],['x^2*(4+1)','42']);
response('PROPORTION-REVERSE-EQUATION',['y=(1/4)*x','y=2x'],['x=4y','y=x/4','y=2*(x+1)']);
response('SOLVE-TWO-STEP-INEQUALITY',['x<5','5>x'],['x≤5','2x<10']);
response('RATIO-PART-PART',['2:3'],['4:6','-2:3','1.5:2']);
response('CIRCLE-CIRCUMFERENCE',['6π','3pi/2'],['18.8496']);
const data=(c:string,d:any,answer:number,pass:boolean)=>ok((checkTaskData(find(c),d,answer).length===0)===pass,'data '+c);
data('MEAN-TO-TOTAL',{mean:-1.5,count:5},-7.5,true);data('MEAN-TO-TOTAL',{mean:2,count:0},0,false);
data('WHOLE-QUOTIENT-ROW-GROUPS',{rows:32,perRow:18,groupSize:24,suppliedTotal:0},24,true);
data('WHOLE-QUOTIENT-ROW-GROUPS',{rows:32,perRow:18,groupSize:25,suppliedTotal:0},23,false);
data('WHOLE-QUOTIENT-ROW-GROUPS',{rows:32,perRow:18,groupSize:24,suppliedTotal:1},24,false);
data('DECIMAL-PRODUCT-DERIVED-FACTOR',{length:3.2,reduction:1.2},6.4,true);data('DECIMAL-PRODUCT-DERIVED-FACTOR',{length:3,reduction:3},0,false);
const candidates={candidates:[0,1,2,3],coefficients:[1,-4,3],bound:2,direction:1};
data('TEST-EQUATION-AND-INEQUALITY',candidates,3,true);data('TEST-EQUATION-AND-INEQUALITY',{...candidates,coefficients:[0,0,0]},3,false);data('TEST-EQUATION-AND-INEQUALITY',{...candidates,candidates:[1,1,2,3]},3,false);data('TEST-EQUATION-AND-INEQUALITY',{...candidates,bound:0},3,false);
data('LCM',{inputs:[6,8]},24,true);data('LCM',{inputs:[12,18]},36,false);
data('ADJACENT-LINEAR-ANGLE-SOLVE',{a:2,b:10,c:3,d:20},70,true);data('ADJACENT-LINEAR-ANGLE-SOLVE',{a:2,b:10,c:-2,d:20},70,false);
data('SIMPLE-INTEREST-PRINCIPAL',{interest:12,rate:.03,time:2},200,true);data('SIMPLE-INTEREST-PRINCIPAL',{interest:12,rate:.03,time:0},200,false);
for(const d of [{numerators:[9,8],denominators:[6,4]},{numerators:[8,9],denominators:[4,6]}])data('UNIT-RATE-DIFFERENCE',d,.5,true);
data('UNIT-RATE-DIFFERENCE',{numerators:[9,8],denominators:[0,4]},.5,false);
data('DATA-MISSING-FREQUENCY',{known:[2,3,1],total:10},4,true);data('DATA-MISSING-FREQUENCY',{known:[2,3,1],total:5},-1,false);
ok(find('RATIONAL-BUDGET-COUNT').domainRules.some(x=>x.includes('COMPLETE')),'floor policy retained');
ok(!find('TRIANGLE-TWO-ANGLES-SIDE').domainRules.some(x=>x.includes('strict triangle inequalities')),'impossible triangles retained');
const p=await makePacket(5,2,state),result=completedWitness(p);const grouping=p.items.find(s=>s.structureCode==='WHOLE-QUOTIENT-ROW-GROUPS')!,i=result.items.find(x=>x.question===grouping.question)!;
ok(!validateItem(i,grouping,state,result.items).length,'valid declared data imports');ok(validateItem({...i,taskData:undefined},grouping,state,result.items).some(x=>x.code==='task-data'),'missing data rejected');ok(validateItem({...i,acceptedAnswers:['25']},grouping,state,result.items).some(x=>x.code==='task-data'),'incorrect declared equivalent rejected');
await assert.rejects(()=>parseResult({...result,seedHash:archive.seedHash},p,state));checks++;
// Authentic v0.4 packet shape and hashes, retained without rewriting.
const archived:Packet={...p,seedHash:archive.seedHash,studioVersion:'0.4.0',blueprintVersion:'4.8.0',contractVersion:'aac.contract.v4',items:await Promise.all(archive.items.filter(s=>s.grade===5&&s.form===2).map(async s=>({...s,specificationHash:await digest(s),proposedTemplateId:'OLD-T-'+s.question,proposedSurfaceFormId:'OLD-S-'+s.question}))),adjacent:archive.items.filter(s=>s.grade===5&&[1,3].includes(s.form)),paired:archive.items.filter(s=>s.grade===6&&s.form===2)};
const saved={...state,forms:{'5|2':{packet:archived,items:[],checks:{},status:'draft' as const,updatedAt:new Date().toISOString()}}};
const b={...backup(saved,1),seedHash:archive.seedHash};const restored=await verifyBackup(b,{forms:{}});ok(stable(restored.forms['5|2'].packet)===stable(archived),'v0.4 preserved');
const tampered=structuredClone(b);tampered.state.forms['5|2'].packet.items[0].given='tampered';await assert.rejects(()=>verifyBackup(tampered,{forms:{}}),/specification/);checks++;
mkdirSync('docs/releases',{recursive:true});writeFileSync('docs/releases/0.5-regression.json',JSON.stringify({checks,forms:24,rows:360,comparisonRecords:comparisons,seedHash:seed.seedHash,scope:'Contract/domain and workflow checks; not full semantic certification of future items.'},null,2)+'\n');console.log('PASS',checks,'v0.5 regression assertions');
