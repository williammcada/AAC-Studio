import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const qa=process.env.AAC_QA_DIR||resolve('work/qa');
import {buildDocx} from '../lib/export';
import {type FormState} from '../lib/model';
const entry=JSON.parse(readFileSync(resolve(qa,'fixture.json'),'utf8')) as FormState;
entry.status='draft';entry.items[0].stem='Find \\(\\frac{3}{4} - \\frac{1}{6}\\).';entry.items[0].answer='7/12';entry.items[0].solution=['Use twelfths: 3/4 = 9/12 and 1/6 = 2/12.','Subtract: 9/12 − 2/12 = 7/12.'];
entry.items[1].stem='Evaluate \\(3^{2} + \\sqrt{16}\\).';entry.items[1].answer='13';entry.items[1].solution=['3 squared is 9. The square root of 16 is 4.','9 + 4 = 13.'];
entry.items[2].stem='Find \\(1\\frac{1}{2} + \\frac{2}{3}\\).';entry.items[2].answer='13/6';entry.items[2].solution=['3/2 + 2/3 = 9/6 + 4/6 = 13/6.'];
// Export fixture only; no assessment content is loaded into the app by this test.
entry.items[4].visual={kind:'table',alt:'Fraction table export fixture',headers:['Part','Amount'],rows:[['A','\\(\\frac{1}{3}\\)'],['B','\\(\\frac{3}{4}\\)']]};
const bytes=await buildDocx(entry,'package',async()=>({bytes:new Uint8Array(readFileSync(resolve(qa,'figure.png'))),width:1200,height:450}));
writeFileSync(resolve(qa,'AAC_Export_Check.docx'),bytes);
console.log(`Created ${bytes.length} bytes for document export QA.`);
