import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import archive46 from '../data/blueprint-4.6-original.json';
import {seed,historicalSeed,type Packet} from '../lib/model';
import {applyOperation,backup,verifyBackup} from '../lib/operations';
import {validateBlueprint,validateItem,digest,stable} from '../lib/validation';
import {semanticIdentity,reviewedEvidence,taskIntegrity} from '../lib/task-integrity';
import {responseValid} from '../lib/contracts';
import {completedWitness} from './witness-result';
const state=(await applyOperation({forms:{}},{kind:'createYear',label:'0.3 regression',yearKind:'test'})).state;
let checks=0;const ok=(v:unknown,m:string)=>{assert.ok(v,m);checks++;};
for(const g of [5,6,7])for(let f=1;f<=8;f++){
 const rows=seed.items.filter(s=>s.grade===g&&s.form===f);ok(rows.length===15,'15 slots');ok(validateBlueprint(g,f,state).filter(i=>i.severity==='error').length===0,'No current preflight errors or warnings');
 ok(new Set(rows.map(semanticIdentity)).size===15,'No same-form semantic duplicate');
 for(const s of rows){const e=reviewedEvidence(s);ok(e&&e.dok===s.dok&&e.witnessSolution.length>0,'Evidence bound to contract');
  for(const t of seed.items.filter(t=>(t.grade===g&&[f===1?8:f-1,f===8?1:f+1].includes(t.form))||(Math.abs(t.grade-g)===1&&t.form===f)))ok(semanticIdentity(s)!==semanticIdentity(t),'Cyclic and paired semantic separation');
 }
}
ok(new Set(seed.items.map(s=>s.claimId)).size===124,'All claims covered');
const sample=seed.items[0];ok(!reviewedEvidence({...sample,given:sample.given+' changed'}),'Changed givens invalidate evidence');ok(!reviewedEvidence({...sample,action:'Another action'}),'Changed action invalidates evidence');ok(!reviewedEvidence({...sample,visualPolicy:'Required'}),'Changed representation contract invalidates evidence');
const inequality={...sample,answerObject:'Inequality',quantity:'Relation',given:'An inequality px+q<r.',boundary:'Return one inequality.'};ok(responseValid('x < 5',inequality,'Solve \\(3x+4<19\\).'),'Implicit coefficient variable supported');ok(!responseValid('bananas < apples',inequality,'Solve \\(3x+4<19\\).'),'Prose is not algebra');
let current=(await applyOperation(state,{kind:'packet',grade:5,form:1})).state;const p=current.forms['5|1'].packet;const result=completedWitness(p);const item=result.items[0];
const short={...p.items[0],wordLimit:3,visualPolicy:'Prohibited'};ok(!validateItem({...item,stem:'Calculate \\(2+3\\).',visual:null},short,current,[item]).some(i=>i.code==='length'),'Equation punctuation is not an extra word');
ok(validateItem({...item,stem:'Find this long numerical value now.',visual:null},short,current,[item]).some(i=>i.code==='length'),'Real excess words still rejected');
// Restore authentic 4.6-shaped current and original-year packets without rewriting them.
for(const original of [false,true]){
 const y=original?undefined:state.year;const g=5,f=original?4:1;
 const p46:Packet={schema:'aac.packet.v1',projectId:original?archive46.projectId:`AAC-${state.year!.id}`,seedHash:archive46.seedHash,packetId:crypto.randomUUID(),designRevision:'archived-46-design',grade:g,form:f,issuedAt:new Date().toISOString(),...(y?{assessmentYear:y}:{}),purpose:original?'generation':'diagnostic',studioVersion:'0.2.0',blueprintVersion:'4.6.0',contractVersion:'aac.contract.v2',items:await Promise.all(archive46.items.filter(s=>s.grade===g&&s.form===f).map(async s=>({...s,specificationHash:await digest(s),proposedTemplateId:'ARCHIVE-T',proposedSurfaceFormId:'ARCHIVE-S'}))),adjacent:archive46.items.filter(s=>s.grade===g&&[f===1?8:f-1,f+1].includes(s.form)).map(s=>original&&s.form<4?historicalSeed.items.find(t=>t.key===s.key)!:s),paired:archive46.items.filter(s=>s.grade===6&&s.form===f)};
 const saved={...state,forms:{[`${g}|${f}`]:{packet:p46,items:[],checks:{},status:'draft' as const,updatedAt:new Date().toISOString()}}};
 const b=original?{schema:'aac.backup.v1',seedHash:archive46.seedHash,state:{forms:saved.forms}}:{...backup(saved,1),seedHash:archive46.seedHash};
 const restored=await verifyBackup(b,{forms:{}});ok(stable(restored.forms[`${g}|${f}`].packet)===stable(p46),'4.6 backup immutable restore');
 const bad=structuredClone(b);bad.state.forms[`${g}|${f}`].packet.items[0].given='tampered';await assert.rejects(()=>verifyBackup(bad,{forms:{}}),/specification/);checks++;
}
const report={studioVersion:'0.5.0',blueprintVersion:seed.blueprintVersion,forms:24,slots:360,claims:124,checks,seedHash:seed.seedHash,scope:'Current catalog constraints, reviewed mathematical witnesses, contract regression, cyclic/paired semantic separation and immutable 4.6 backup compatibility.'};
writeFileSync('docs/releases/0.5-retained-bank-validation.json',JSON.stringify(report,null,2)+'\n');console.log(`PASS: ${checks} retained bank and compatibility assertions.`);
