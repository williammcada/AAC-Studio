import assert from 'node:assert/strict';
import {mkdirSync,writeFileSync} from 'node:fs';
import {seed,checklist,slots,type State,type FormState} from '../../lib/model';
import witnesses from '../../data/v03/witnesses.json';
import {validateBlueprint,validateItem,validateForm,canFinalize} from '../../lib/validation';
import {applyOperation,backup,verifyBackup} from '../../lib/operations';
import {resultSkeleton,packetText} from '../../lib/packet';
import {buildDocx} from '../../lib/export';
import {createHash} from 'node:crypto';
let state=(await applyOperation({forms:{}},{kind:'createYear',label:'V0.3 release verification',yearKind:'test'})).state;
const out='work/v03/qa';mkdirSync(out,{recursive:true});let failures:any[]=[];const results:any[]=[];
for(const g of [5,6,7])for(let f=1;f<=8;f++){
 const issues=validateBlueprint(g,f,state);if(issues.length){failures.push({grade:g,form:f,issues});continue;}
 state=(await applyOperation(state,{kind:'packet',grade:g,form:f})).state;const p=state.forms[`${g}|${f}`].packet;
 const result=resultSkeleton(p);
 result.items=result.items.map((i,j)=>{const s=p.items[j],w=witnesses[s.key as keyof typeof witnesses];return {...i,stem:w.stem,choices:w.choices,answer:w.answer,solution:w.solution,visual:w.visual as any,scoringNote:'Award 1 point for the correct mathematical answer.',reviewNote:'Release verification witness only; not accepted for school use. '+s.action};});
 const errors=result.items.flatMap((i,j)=>validateItem(i,p.items[j],state,result.items)).filter(i=>i.severity==='error');if(errors.length){failures.push({grade:g,form:f,errors});continue;}
 writeFileSync(`${out}/G${g}_V${f}_packet.txt`,packetText(p));writeFileSync(`${out}/G${g}_V${f}_result.json`,JSON.stringify(result,null,2));
 state=(await applyOperation(state,{kind:'import',grade:g,form:f,result:JSON.parse(JSON.stringify(result))})).state;
 assert((await canFinalize(state.forms[`${g}|${f}`],state)).some(i=>i.code==='review'));
 for(let q=1;q<=15;q++)state=(await applyOperation(state,{kind:'review',grade:g,form:f,question:q,reviewed:true})).state;
 state=(await applyOperation(state,{kind:'checks',grade:g,form:f,checks:Object.fromEntries(Object.keys(checklist).map(k=>[k,true]))})).state;
 const finalErrors=(await canFinalize(state.forms[`${g}|${f}`],state)).filter(i=>i.severity==='error');assert.equal(finalErrors.length,0,JSON.stringify(finalErrors));
 // Keep the exported package visibly a review copy. Finalization below is isolated QA state.
 const entry=state.forms[`${g}|${f}`];writeFileSync(`${out}/G${g}_V${f}_entry.json`,JSON.stringify(entry,null,2));
 if(process.env.AAC_RENDER_EXPORT==='1'){
  const raster=async(v:any)=>{const {createRequire}=await import('node:module');const sharp=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/runtime.cjs')('sharp');const {data,info}=await sharp(Buffer.from(v.svg)).resize({width:1600}).flatten({background:'#ffffff'}).png().toBuffer({resolveWithObject:true});return {bytes:new Uint8Array(data),width:info.width,height:info.height};};
  writeFileSync(`${out}/G${g}_V${f}.docx`,await buildDocx(entry,'package',raster));
 }
 state=(await applyOperation(state,{kind:'finalize',grade:g,form:f})).state;
 results.push({grade:g,form:f,items:15,packet:true,import:true,reviewGate:true,finalize:true});
}
writeFileSync(`${out}/failures.json`,JSON.stringify(failures,null,2));writeFileSync(`${out}/workflow-results.json`,JSON.stringify(results,null,2));
console.log('Forms completed',results.length,'failures',failures.length);for(const x of failures)console.log(JSON.stringify(x));
if(!failures.length){const saved=backup(state,1),restored=await verifyBackup(saved,{forms:{}});assert.equal(Object.keys(restored.forms).length,24);console.log('All 24 finalized QA forms round-trip through backup; actual application data unchanged.');}
if(failures.length)process.exitCode=1;
