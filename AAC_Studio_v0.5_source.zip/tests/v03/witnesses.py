"""Model-authored mathematical witnesses, not accepted school assessments.
Every entry supplies real givens, an objective response, and a checkable calculation.
"""
from fractions import Fraction as F
import json,re,pathlib,html,ast,operator,math
ROOT=pathlib.Path(__file__).resolve().parents[2]
T={}
def put(code,stem,answer,calc=None,solution=None,visual=None,choices=None,reason=None):
 T[code]=dict(stem=stem,answer=str(answer),calculation=calc,solution=solution or ([f'{calc} = {answer}.'] if calc else []),visual=visual,choices=choices or [],reason=reason)
def table(headers,rows):return {'kind':'table','headers':headers,'rows':rows,'alt':'Mathematical data table'}
def svg(body,w=500,h=220,alt='Mathematical diagram'):
 return {'kind':'svg','svg':f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}">'+body+'</svg>','alt':alt}
def text(x,y,s,size=20):return f'<text x="{x}" y="{y}" font-size="{size}" font-family="Arial" fill="black">{html.escape(str(s))}</text>'
def line(x1,y1,x2,y2):return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="black" stroke-width="2"/>'
def rect(x,y,w,h,fill='white'):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="black" stroke-width="2"/>'
def dotplot(values,labels=None):
 lo=min(values);hi=max(values);scale=360/max(1,hi-lo);b=line(60,160,430,160)
 for v in sorted(set(values)):
  x=60+(v-lo)*scale;b+=line(x,155,x,165)+text(x-6,193,(labels or {}).get(v,str(v)))
  for j in range(values.count(v)):b+=f'<circle cx="{x}" cy="{140-j*24}" r="7" fill="black"/>'
 return svg(b,500,220,'Dot plot with one dot per observation')
def plane(points,scale=1):
 b=''
 for k in range(9):
  b+=line(60+k*40,25,60+k*40,345)+line(60,345-k*40,380,345-k*40)
  if k:b+=text(52+k*40,370,k*scale,16)+text(22,351-k*40,k*scale,16)
 b+=text(395,347,'x')+text(50,20,'y')+text(35,370,'0',16)
 for name,x,y in points:
  px=60+x/scale*40;py=345-y/scale*40;b+=f'<circle cx="{px}" cy="{py}" r="5" fill="black"/>'+text(px+8,py-8,name,18)
 return svg(b,450,400,'First-quadrant coordinate plane with labeled points')
def numberline(lo=-4,hi=4,marks=None,arrows=None):
 px=lambda x:50+(x-lo)/(hi-lo)*400;b=line(45,140,455,140)
 for x in range(lo,hi+1):b+=line(px(x),134,px(x),146)+text(px(x)-8,174,str(x),18)
 for label,x in marks or []:b+=f'<circle cx="{px(x)}" cy="140" r="6" fill="black"/>'+text(px(x)-8,120,label)
 for j,(a,c) in enumerate(arrows or []):
  y=70-j*24;d=1 if c>a else -1;b+=line(px(a),y,px(c),y)+line(px(c),y,px(c)-10*d,y-7)+line(px(c),y,px(c)-10*d,y+7)
 return svg(b,500,205,'Labeled number line')
def bars(labels,widths):
 b=''
 for j,(label,w) in enumerate(zip(labels,widths)):b+=rect(50,25+j*70,w,38)+text(60,52+j*70,label)
 return svg(b,500,70*len(labels)+20,'Labeled bar model')
# Arithmetic and symbolic witnesses. @...@ becomes native inline Word mathematics.
for code,stem,ans,calc in [
 ('MULTIPLY-TWO','Calculate @246 \\times 24@.','5904','246*24'),
 ('MULTIPLY-THREE','Calculate @24 \\times 15 \\times 12@.','4320','24*15*12'),
 ('ADD-TWO','Calculate @2/3+3/4@.','17/12','2/3+3/4'),
 ('ADD-THREE','Calculate @12.45+6.08+3.7@.','22.23','12.45+6.08+3.7'),
 ('SUBTRACT-TWO','Calculate @7/8-1/3@.','13/24','7/8-1/3'),
 ('ADD-THEN-SUBTRACT','Calculate @3/4+2/3-1/2@.','11/12','3/4+2/3-1/2'),
 ('DIV-QUOTIENT','Calculate @8.64\\div1.2@.','7.2','8.64/1.2'),
 ('WHOLE-DIVISION-QUOTIENT','Calculate @2736\\div24@.','114','2736/24'),
 ('DIV-DIVISOR','Find @d@: @1440\\div d=60@.','24','1440/60'),
 ('DIV-DIVIDEND','Find @n@: @n\\div24=36@.','864','24*36'),
 ('MUL-MISSING-FACTOR','Find @n@: @1.2\\times n=4.8@.','4','4.8/1.2'),
 ('MUL-DIGIT','Find digit @d@: @2d4\\times3=702@.','3',None),
 ('SUM-PRODUCTS','Calculate @1.2\\times3.5+0.8\\times2.5@.','6.2','1.2*3.5+0.8*2.5'),
 ('MULTIPLY-THEN-DIVIDE','Calculate @(-3/4)\\times2\\div(-1/2)@.','3','(-3/4)*2/(-1/2)'),
 ('SUBTRACT-MISSING-CHANGE','Find @b@: @-2-b=-7/2@.','3/2','-2-(-7/2)'),
 ('ADD-MISSING-PART','Find @a@: @a+2.75=8.2@.','5.45','8.2-2.75'),
 ('SUBTRACT-TWICE-MISSING-START','A temperature falls by @3/2@ degrees, then @2/3@ degrees, reaching @-1@ degree. What was its starting value?','7/6','-1+3/2+2/3'),
 ('COMPARE-TWO','Complete with @<@, @>@, or @=@: @4.08@ ___ @4.8@.','<',None),
 ('COMPARE-QUOTIENTS','Complete with @<@, @>@, or @=@: @8.4\\div0.7@ ___ @9.6\\div0.6@.','<',None),
 ('PLACE-ADJACENT-FACTOR','How many times the value of @6@ in @0.06@ is its value in @0.6@?','10','0.6/0.06'),
 ('DECIMAL-COMPOSE','Write as one decimal: @4+2/10+7/1000@.','4.207','4+2/10+7/1000'),
 ('POWER10-SEQUENCE','Divide by @10@ each time: @45@, ___, @0.45@.','4.5','45/10'),
 ('POWER10-COMPOSE','Calculate @3.48\\times100\\div1000@.','0.348','3.48*100/1000'),
 ('ROUND-DECIMAL','Round @7.486@ to the nearest hundredth.','7.49',None),
 ('EVAL-GROUPED-PRODUCT','Calculate @(18+7)\\times(12-8)@.','100','(18+7)*(12-8)'),
 ('EVALUATE-TWO-CASES-DIFF','For @E=3x+2@, find its value at @x=5@ minus its value at @x=2@.','9','(3*5+2)-(3*2+2)'),
 ('COMBINE-CONSTANTS','Find @c@: @(8+x)+5=x+c@.','13','8+5'),
 ('COMBINE-LIKE-TERMS','Find the coefficient of @x@ after simplifying @3x+5x-2x+7@.','6','3+5-2'),
 ('DISTRIBUTE-COEFFICIENT','Find @a@: @3(2x+5)=ax+15@.','6','3*2'),
 ('DISTRIBUTE-CONSTANT','Find @b@: @2(3x+4)=6x+b@.','8','2*4'),
 ('DISTRIBUTE-MISSING-LIKE-COEFFICIENT','Find @d@ so @3(2x+4)+dx=11x+12@ for every @x@.','5','11-3*2'),
 ('FACTOR-LINEAR-MISSING','Find @b@: @6x+18=6(x+b)@.','3','18/6'),
 ('EXPRESSION-TERM-COUNT','How many terms are in @3(x+2)+4y-7@ before expanding?','3',None),
 ('FUNCTION-OUTPUT','Given @y=3x+2@, find @y@ when @x=4@.','14','3*4+2'),
 ('FUNCTION-INPUT','Given @y=3x+2@, find @x@ when @y=20@.','6','(20-2)/3'),
 ('RELATED-VARIABLE-OFFSET','In @y=3x+b@, @x=4@ gives @y=17@. Find @b@.','5','17-3*4'),
 ('SOLVE-TWO-STEP-EQUATION','Find @x@: @3x+4=19@.','5','(19-4)/3'),
 ('SOLVE-GROUPED-EQUATION','Find @x@: @3(x+2)=21@.','5','21/3-2'),
 ('SOLVE-TWO-STEP-INEQUALITY','Solve @3x+4<19@. Write one inequality.','x < 5',None),
 ('OPPOSITE','What is the opposite of @-3/4@?','3/4','-(-3/4)'),
 ('OPPOSITE-INVERSE','The opposite of @n@ is @3/4@. Find @n@.','-3/4','-(3/4)'),
 ('SIGNED-QUANTITY','A point is @7@ meters below zero. Write its signed height in meters.','-7','-7'),
 ('SIGNED-REFERENCE','A platform is @12@ meters high. A point is @5@ meters high. What is its height relative to the platform?','-7','5-12'),
 ('GCF-DIRECT','Find the greatest common factor of @36@ and @48@.','12',None),
 ('LCM','Find the least common multiple of @12@ and @18@.','36',None),
 ('GCF-FACTOR-BLANK','Complete @24+36=12(2+b)@. Find @b@.','3','36/12'),
 ('GCF-OUTER-FACTOR','Find the greatest whole-number @a@ for which @24+36=a(2+3)@.','12','(24+36)/(2+3)'),
 ('MEAN-TO-TOTAL','Six observations have mean @7@. Find their total.','42','6*7'),
 ('MEAN-MISSING-VALUE','The mean of @4,6,8,n@ is @7@. Find @n@.','10','7*4-4-6-8'),
 ('FRACTION-TO-DECIMAL','Write @7/8@ as a decimal.','0.875','7/8'),
 ('CIRCLE-CIRCUMFERENCE','A circle has radius @3@ cm. Find its circumference in cm. Give an exact answer using @\\pi@.','6π',None),
 ('PROBABILITY-COMPLEMENT','The probability of rain is @3/8@. What is the probability of no rain?','5/8','1-3/8'),
 ('PAIR-SUMS-RECOVER-TOTAL','Given @a+b=-1@, @a+c=5@, and @b+c=2@, find @a+b+c@.','3','(-1+5+2)/2'),
 ('QUADRANT-FROM-PAIR','Which quadrant contains @(-3,4)@?','II',None),
]: put(code,stem,ans,calc)
# Explanatory teacher lines provide verification when the answer is non-numeric.
T['MUL-DIGIT']['solution']=['234 × 3 = 702, so the tens digit is 3. Testing digits 0–9 gives exactly one match.']
T['COMPARE-TWO']['solution']=['4.08 is less than 4.80.']
T['COMPARE-QUOTIENTS']['solution']=['The quotients are 12 and 16; 12 < 16.']
T['ROUND-DECIMAL']['solution']=['The thousandths digit is 6, so 7.486 rounds to 7.49 at hundredths.']
T['EXPRESSION-TERM-COUNT']['solution']=['The three outermost terms are 3(x+2), 4y and -7.']
T['SOLVE-TWO-STEP-INEQUALITY']['solution']=['Subtract 4: 3x < 15. Divide by positive 3: x < 5.']
T['GCF-DIRECT']['solution']=['36 = 2² × 3² and 48 = 2⁴ × 3. The common prime factors give 2² × 3 = 12.']
T['LCM']['solution']=['12 = 2² × 3; 18 = 2 × 3². The least common multiple is 2² × 3² = 36.']
T['CIRCLE-CIRCUMFERENCE']['solution']=['C = 2πr = 2π(3) = 6π cm.']
T['QUADRANT-FROM-PAIR']['solution']=['Negative x and positive y place the point in Quadrant II.']
for code,stem,ans,calc in [
 ('SHARE-ADD-THEN-DIVIDE','A group shares @5@ meters and @2@ meters equally among @4@ people. How many meters does each receive?','7/4','(5+2)/4'),
 ('SCALING-COMPARE','Complete with @<@, @>@, or @=@: @8\\times3/4@ ___ @8@.','<',None),
 ('PATTERN-DIFFERENCE','A starts @2@, adding @3@. B starts @1@, adding @5@. Find their fourth terms’ difference, @B-A@.','5','(1+3*5)-(2+3*3)'),
 ('UNIT-DIV-PORTIONS','How many @1/4@-meter pieces make @3@ meters?','12','3/(1/4)'),
 ('SCALE-REMAINDER','A strip is @7/2@ meters long. One third is used. How many meters remain?','7/3','(7/2)*(1-1/3)'),
 ('QUAD-SUBCLASS','A parallelogram has four right angles. What more specific category must it belong to?','rectangle',None),
 ('COMBINE-SHARE-QUOTIENT','Two containers hold @3@ and @4@ liters. Their contents fill @6@ equal bottles. How many liters fill each bottle?','7/6','(3+4)/6'),
 ('PATTERN-CORRESPONDING-PAIR','A: start @2@, add @3@. B: start @1@, add @5@. Write @(A,B)@ at term @4@.','(11,16)',None),
 ('SUBTRACT-TWICE','A @7/2@-meter strip loses @3/4@ meter, then @2/3@ meter. How many meters remain?','25/12','7/2-3/4-2/3'),
 ('UNIT-SHARE-COMBINED-GROUPS','Two groups of @2@ and @3@ people share @1/2@ meter equally. How many meters does each person receive?','1/10','(1/2)/(2+3)'),
 ('COORD-MOVE','A point starts at @(3,4)@, moves @2@ units right and @1@ unit down. What is its final ordered pair?','(5,3)',None),
 ('SCALING-INFER-INTERVAL','Multiplying @8@ by @k@ gives @6@. Is @k@ below, equal to, or above @1@?','below 1',None),
 ('QUAD-COUNT-CLASSES','How many listed classes must have four right angles: square, rectangle, rhombus, parallelogram?','2',None),
 ('ESTIMATE-SUM','Which is closest to @7/8+11/12@: @1@, @2@, or @3@?','2',None),
 ('SUBTRACT-THEN-MULTIPLY','A box holds @30@ counters. Remove @6@. Use @2/3@ of the remaining counters. How many are used?','16','(30-6)*2/3'),
 ('SCALING-SELECT-FACTOR','Choose @k@ from @1/2,3/4,5/4@ so @5<8k<7@.','3/4',None),
 ('PATTERN-MISSING-START','A starts at @2@, adding @3@. B adds @5@. Their fourth terms match. What is B’s starting value?','-4','2+3*3-3*5'),
 ('CONVERT-TOTAL','Join a @2@-meter strip and a @35@-centimeter strip. How many centimeters long is it? @1@ meter = @100@ centimeters.','235','2*100+35'),
 ('REMAINING-UNIT-PORTION-COUNT','From @5@ meters, @2@ meters are used. How many @1/4@-meter pieces can be cut from the remainder?','12','(5-2)/(1/4)'),
 ('COORD-DISTANCE','On a map, A is at @(2,3)@ and B at @(7,3)@. What is their distance in grid units?','5','7-2'),
 ('UNIT-SHARE-AMOUNT','Calculate @1/3\\div4@.','1/12','(1/3)/4'),
 ('UNIT-SHARE-REMAINDER','Share @1/2@ meter equally among @3@ people. One person uses @1/12@ meter. How many meters remain in that person’s share?','1/12','(1/2)/3-1/12'),
 ('CONVERT-THEN-RESTORE','After removing @1/2@ meter, @125@ centimeters remain. How many meters was the original strip? @100@ centimeters = @1@ meter.','7/4','125/100+1/2'),
 ('COMPARE-SHARES','A shares @5@ liters among @3@ people. B shares @7@ liters among @4@ people. What is the greater per-person share in liters?','7/4',None),
 ('QUAD-INHERIT-PROPERTY','All rectangles are parallelograms. Complete their inherited side property: opposite sides are ___.','parallel',None),
 ('TRANSLATE-GROUPED-SUM','Write an expression for three times the sum of eight and five.','3(8+5)',None),
 ('DIV-REMAINDER-ONLY','Find the remainder when @1457@ is divided by @24@.','17','1457-24*60'),
 ('MUL-MISSING-DENOMINATOR','Find @d@: @2/3\\times3/d=1/2@.','4','(2/3)*3/(1/2)'),
 ('EXPRESSION-RELATION','How many times @18+7@ is @4(18+7)@?','4','4'),
 ('ESTIMATE-REASONABLE','A @23/8@-meter strip loses @11/12@ meter. Which remaining length is closest: @1@, @2@, or @3@ meters?','2',None),
 ('UNIT-SHARE-TWO-STAGES','Share @1/2@ meter among @3@ groups. Each group cuts its share into @4@ equal pieces. How many meters per piece?','1/24','(1/2)/3/4'),
 ('UNIT-DIV-DENOMINATOR','Find whole number @d@: @3\\div1/d=12@.','4','12/3'),
 ('RATIO-PART-PART','There are @12@ blue and @18@ red counters. Write the blue-to-red ratio in simplest form.','2:3',None),
 ('TEST-INEQUALITY','Which value satisfies @3x+2<10@: @2,3,4,5@?','2',None),
 ('UNIT-RATE','A pipe delivers @3/2@ liters in @3/4@ minute. How many liters per minute?','2','(3/2)/(3/4)'),
 ('TRANSLATE-ORDERED-OPS','Write an expression for the difference of @x@ and @4@, divided by @3@.','(x-4)/3',None),
 ('PRISM-EDGE-VOLUME','A rectangular prism has edge lengths @3/2@, @4/3@, and @5/2@ centimeters. What is its volume in cubic centimeters?','5','(3/2)*(4/3)*(5/2)'),
 ('INEQUALITY-TRANSLATE','The length @x@ is greater than @7@. Write one inequality.','x > 7',None),
 ('COMPARE-UNIT-RATES','A fills @6@ liters in @4@ minutes. B fills @10@ liters in @5@ minutes. Compare A’s rate to B’s using @<,>,=@.','<',None),
 ('PERCENT-WHOLE','@12@ counters are @30%@ of a collection. How many counters are in the collection?','40','12/(30/100)'),
 ('COORD-SIDE-LENGTH','A polygon has vertices @(-3,2),(4,2),(4,6)@. What is the length of its first side in units?','7','4-(-3)'),
 ('TEST-TWO-CONDITIONS','Which of @1,2,3,4@ satisfies @x^2=4@ and @x>0@?','2',None),
 ('UNIT-RATE-DIFFERENCE','A delivers @9@ liters in @6@ minutes. B delivers @8@ liters in @4@ minutes. Find B’s rate minus A’s in liters/minute.','1/2','8/4-9/6'),
 ('FRACTION-AREA-MISSING-SIDE','A rectangle has area @3/4@ square meter and width @1/2@ meter. Find its length in meters.','3/2','(3/4)/(1/2)'),
 ('EQUATION-MODEL','A strip of length @x@ centimeters gains @4@ centimeters and becomes @11@ centimeters. Write an equation.','x+4=11',None),
 ('RATE-TWO-STAGES','A pipe delivers @3@ liters in @2@ minutes, then @7@ liters in @3@ minutes. Find its overall rate in liters/minute.','2','(3+7)/(2+3)'),
 ('ABS-CONSTRAINED-NUMBER','Choose @x@ from @-3,-2,2,4@ so @|x|=2@ and @x<0@.','-2',None),
 ('PERCENT-PART','Find @35%@ of @60@.','21','35/100*60'),
 ('EQUATION-COEFFICIENT-MODEL','Each bag holds @4@ counters, with @3@ extra. For @x@ bags, @y=ax+3@ counters. Find @a@.','4','4'),
 ('EQUIVALENCE-COUNTERVALUE','Which value, @1@ or @2@, makes @3x+2@ and @5x@ unequal?','2',None),
 ('DIVIDE-TOTAL-PORTIONS','Combine @3/4@ liter and @5/6@ liter. How many @1/12@-liter portions result?','19','(3/4+5/6)/(1/12)'),
 ('TRANSLATE-EXPONENTIAL','Write @3\\times3\\times(2+5)@ using an exponent.','3^2(2+5)',None),
 ('RATIO-TOTAL-PART','The red-to-blue ratio is @2:3@. There are @35@ counters. How many are blue?','21','35/(2+3)*3'),
 ('TEST-EQUATION-AND-INEQUALITY','Choose from @0,1,2,3@: @(x-1)(x-3)=0@ and @x>2@.','3',None),
 ('DIVIDE-REMAINDER-PORTION','A container has @7/4@ liters. Remove @1/2@ liter. How many @1/4@-liter portions remain?','5','(7/4-1/2)/(1/4)'),
 ('EQUATION-SHARED-SOLUTION','The same @x@ satisfies @3x=12@ and @cx=20@. Find @c@.','5','20/(12/3)'),
 ('ABS-SIGNED-ORDER','Choose @x@ from @-3,-2,2,4@ so @|x|=2@ and @x<0@.','-2',None),
 ('FUNCTION-MISSING-PARAMETER','The table follows @y=3x+b@. Find @b@.','5','17-3*4'),
 ('CONVERT-SINGLE','Convert @250@ centimeters to meters. @100@ centimeters = @1@ meter.','2.5','250/100'),
 ('PERCENT-PART-REMAINDER','A container holds @80@ liters. @25%@ is used. How many liters remain?','60','80*(1-25/100)'),
 ('TRANSLATE-SHARE-ADDED','Add @5@ liters to @x@ liters, then share equally among @3@ containers. Write the liters per container.','(x+5)/3',None),
 ('INEQUALITY-BOUNDARY','A load has @4@ fixed kilograms and @x@ extra kilograms. Total mass must be below @15@ kilograms. Complete @x<b@: find @b@.','11','15-4'),
 ('INEQUALITY-INTEGER-LIMIT','For integer @x@ between @-10@ and @20@, find the greatest solution of @3x+4<18@.','4',None),
 ('AFFINE-TOTAL','A container has @3/2@ liters. Add @4@ bottles holding @3/4@ liter each. How many liters are there now?','9/2','3/2+4*(3/4)'),
 ('PERCENT-CHANGE','A length increases from @40@ to @50@ centimeters. What is the percent increase?','25%','(50-40)/40*100'),
 ('TRIANGLE-SSS-CLASSIFY','Sides measure @3,4,6@ centimeters. Is the triangle determined uniquely or impossible?','unique',None),
 ('FACTOR-CONTEXT-OUTER','A total is @6x+18@ liters, written @a(x+3)@. Find @a@.','6','6'),
 ('UNIFORM-EVENT-PROBABILITY','Choose equally likely from the numbers @1@ through @8@. What is the probability of an even number?','1/2','4/8'),
 ('AFFINE-MISSING-RATE','A container starts with @3/2@ liters. Four equal bottles raise the total to @9/2@ liters. How many liters per bottle?','3/4','(9/2-3/2)/4'),
 ('TRIANGLE-AAA-CLASSIFY','Angles measure @40,60,80@ degrees. Do they allow no triangle or multiple sizes?','multiple sizes',None),
 ('PERCENT-EQUIVALENT-MULTIPLIER','A length @x@ increases by @25%@. Write the multiplier @m@ in its new length @mx@.','1.25','1+25/100'),
 ('PRODUCT-SIGN','What is the sign of the product of three negative factors and two positive factors?','-',None),
 ('PERCENT-ORIGINAL','A length increases by @25%@ to @50@ centimeters. What was its original length in centimeters?','40','50/(1+25/100)'),
 ('TRIAL-PREDICT-FREQUENCY','An event occurs @12@ times in @40@ trials. At that rate, how many occurrences are predicted in @200@ trials?','60','12/40*200'),
 ('UNIT-RATES-COMBINE','A fills @3/2@ liters in @3/4@ minute. B fills @2/3@ liter in @1/3@ minute. Find their combined liters per minute.','4','(3/2)/(3/4)+(2/3)/(1/3)'),
 ('RATIONAL-BUDGET-COUNT','From @5@ meters, reserve @3/4@ meter. How many complete @3/2@-meter pieces can be cut?','2',None),
 ('RATIONAL-WEIGHTED-TOTAL','Combine @3/2@ kilograms costing @4@ units per kilogram and @3/4@ kilogram costing @8@ units per kilogram. Find the total cost.','12','(3/2)*4+(3/4)*8'),
 ('PERCENT-EQUIVALENT-DECREASE','A length @x@ decreases by @20%@. Find @m@ in the remaining length @mx@.','0.8','1-20/100'),
 ('PERCENT-DISCOUNT-THEN-FEE','An item costs @40@ units. Reduce this by @25%@, then add a @3@-unit fee. Find the final cost.','33','40*(1-25/100)+3'),
 ('TRAVEL-TIME-TWO-LEGS','Travel @6@ kilometers in two equal stages, at @3@ then @2@ kilometers per hour. Find the total hours.','5/2','(6/2)/3+(6/2)/2'),
 ('PROPORTION-EQUATION-GROUPED-INPUT','Each bottle holds @3/4@ liter. Each box has @4@ bottles. For @x@ boxes and @y@ liters, write @y@ in terms of @x@.','y=3x',None),
 ('PERCENT-SUCCESSIVE','A @100@-unit amount increases by @20%@, then decreases by @25%@. Find the final amount.','90','100*(1+20/100)*(1-25/100)'),
 ('SCALE-REDRAW-LENGTH','An @8@-centimeter drawing uses scale @1:50@. Redraw at @1:100@. What is the new length in centimeters?','4','8*50/100'),
 ('FACTOR-CONTEXT-COEFFICIENT','A total @6x+18@ liters is written @6(x+b)@. Find @b@.','3','18/6'),
 ('RATE-TOTAL-DIFFERENCE','A tank holds @10@ liters. Use @3/2@ liters/minute for @2@ minutes, then @1/2@ liter/minute for @3@ minutes. How many liters remain?','11/2','10-(3/2)*2-(1/2)*3'),
 ('EMPIRICAL-PROBABILITY','Trials produce red @12@ times and blue @28@ times. Estimate the probability of red.','3/10','12/(12+28)'),
 ('SAMPLE-POPULATION-ESTIMATE','In a random sample of @40@ plants, @12@ flower. Estimate how many of @200@ plants flower.','60','12/40*200'),
 ('PROPORTION-REVERSE-EQUATION','Given @x=4y@, write @y@ in terms of @x@.','y=x/4',None),
 ('AFFINE-MISSING-FIXED','Four bottles of @3/4@ liter raise a container’s total to @9/2@ liters. How many liters were there initially?','3/2','9/2-4*(3/4)'),
 ('UNIT-RATE-CONVERT','A pipe delivers @3/2@ liters in @3/4@ minute. Find milliliters per minute. @1@ liter = @1000@ milliliters.','2000','(3/2)/(3/4)*1000'),
 ('EQUATION-FROM-CONTEXT','Three strips each measure @x@ meters. With @4@ extra meters, total length is @19@ meters. Write an equation.','3x+4=19',None),
 ('PRODUCT-SIGN-INVERSE','A product is negative. Its known factors have signs @-,-,+@. What sign must the remaining nonzero factor have?','-',None),
 ('SIMPLE-INTEREST-PRINCIPAL','Simple interest is @12@ units after @2@ years at @3%@ yearly. Using @I=Prt@, find the original amount @P@.','200','12/((3/100)*2)'),
 ('TRIANGLE-TWO-ANGLES-SIDE','Two angles are @50@ and @60@ degrees; their included side is @4@ cm. Is the triangle unique or impossible?','unique',None),
 ('COMPARE-MEDIANS','A: @1,3,5,7@. B: @2,6,8,10@. Find median B minus median A.','3','(6+8)/2-(3+5)/2'),
 ('DECIMAL-CLASSIFY','Does the decimal expansion of @7/12@ terminate or repeat?','repeats',None),
]:put(code,stem,ans,calc)
# Exact structural reasoning for objective answers that are not direct arithmetic.
proofs={
'SCALING-COMPARE':'Multiplying a positive value by 3/4 makes it smaller.',
'QUAD-SUBCLASS':'A parallelogram with four right angles is a rectangle; equal adjacent sides are not supplied.',
'PATTERN-CORRESPONDING-PAIR':'The fourth terms are 2+3×3=11 and 1+3×5=16.',
'COORD-MOVE':'The coordinates become (3+2,4-1)=(5,3).',
'SCALING-INFER-INTERVAL':'The result is positive and smaller than the original; 0<k<1.',
'QUAD-COUNT-CLASSES':'Square and rectangle always have four right angles; a general rhombus or parallelogram need not.',
'ESTIMATE-SUM':'The sum is 43/24, approximately 1.79; of the given candidates 2 is uniquely closest.',
'SCALING-SELECT-FACTOR':'The three products are 4,6,10. Only 6 lies strictly between 5 and 7.',
'COMPARE-SHARES':'5/3=20/12 and 7/4=21/12; 7/4 is greater.',
'QUAD-INHERIT-PROPERTY':'Both pairs of opposite sides of every parallelogram are parallel.',
'TRANSLATE-GROUPED-SUM':'The sum 8+5 is one group; multiply the entire group by 3.',
'ESTIMATE-REASONABLE':'23/8-11/12=47/24, about 1.96. The unique closest candidate is 2.',
'RATIO-PART-PART':'Divide both counts by their GCF, 6: 12:18=2:3.',
'TEST-INEQUALITY':'Only x=2 gives 3x+2<10; the other values give 11,14,17.',
'TRANSLATE-ORDERED-OPS':'Subtract 4 from x before dividing the whole difference by 3.',
'INEQUALITY-TRANSLATE':'Greater than 7 is x>7; the boundary is excluded.',
'COMPARE-UNIT-RATES':'A has rate 1.5 liters/minute; B has rate 2. Thus A<B.',
'TEST-TWO-CONDITIONS':'Only 2 among the candidates squares to 4 and is positive.',
'EQUATION-MODEL':'The starting length plus 4 equals the final length 11.',
'ABS-CONSTRAINED-NUMBER':'Both -2 and 2 have magnitude 2; only -2 is negative.',
'EQUIVALENCE-COUNTERVALUE':'At 1 both expressions are 5; at 2 they are 8 and 10.',
'TRANSLATE-EXPONENTIAL':'The repeated factors 3×3 are 3², multiplying the grouped sum.',
'TEST-EQUATION-AND-INEQUALITY':'The equation holds for 1 and 3; only 3 exceeds 2.',
'ABS-SIGNED-ORDER':'Both -2 and 2 have magnitude 2; only -2 is negative.',
'TRANSLATE-SHARE-ADDED':'Combine x and 5, then divide their total by 3.',
'INEQUALITY-INTEGER-LIMIT':'x<14/3; the greatest integer satisfying this is 4, below the domain upper bound.',
'TRIANGLE-SSS-CLASSIFY':'3+4>6 and the other triangle inequalities hold. SSS determines one congruence class.',
'TRIANGLE-AAA-CLASSIFY':'Angles total 180 degrees; scale is undetermined, so multiple sizes are possible.',
'PRODUCT-SIGN':'Three negative factors contribute an odd number of minus signs, giving a negative product.',
'RATIONAL-BUDGET-COUNT':'17/4 remains. (17/4)/(3/2)=17/6, so at most 2 complete pieces fit.',
'PROPORTION-EQUATION-GROUPED-INPUT':'Each box contains 4×3/4=3 liters; y=3x.',
'PROPORTION-REVERSE-EQUATION':'Divide both sides by 4: y=x/4.',
'EQUATION-FROM-CONTEXT':'Three equal lengths plus the fixed extra 4 give total 19.',
'PRODUCT-SIGN-INVERSE':'The known factors have positive product; a negative missing factor produces a negative total.',
'TRIANGLE-TWO-ANGLES-SIDE':'The third angle is 70 degrees; ASA with positive included side fixes one triangle.',
'DECIMAL-CLASSIFY':'The reduced denominator 12 contains factor 3, so the decimal repeats.'}
for c,p in proofs.items():T[c]['solution']=[p]
# Diagrams are data-bearing, with native fractions outside SVG labels.
fp=dotplot([1,1,2,3,3],{1:'A',2:'B',3:'C'})
put('PLOT-FREQUENCY','Lengths in meters: @A=1/4@, @B=1/2@, @C=3/4@. How many lengths equal @3/4@ meter?','2','2',visual=fp)
put('PLOT-TOTAL','Lengths in meters: @A=1/4@, @B=1/2@, @C=3/4@. Find the total length in meters.','5/2','2*(1/4)+1/2+2*(3/4)',visual=fp)
put('DISTRIBUTION-RANGE','Lengths in meters: @A=1/4@, @B=1/2@, @C=3/4@. Find the range in meters.','1/2','3/4-1/4',visual=fp)
put('COORD-READ','Write the ordered pair for P.','(6,10)',solution=['P is three intervals right and five up. Each interval is 2 units, so P=(6,10).'],visual=plane([('P',6,10)],2))
put('COORD-COMBINE','Use P’s x-coordinate and Q’s y-coordinate. Write the resulting ordered pair.','(2,5)',solution=['P has x=2; Q has y=5. The resulting pair is (2,5).'],visual=plane([('P',2,3),('Q',6,5)]))
put('COORD-INFER-RECTANGLE','A, B, and C are three vertices of an axis-aligned rectangle. Write its fourth vertex.','(2,6)',solution=['The missing vertex shares A’s x=2 and C’s y=6.'],visual=plane([('A',2,2),('B',6,2),('C',6,6)]))
def prism(a='4 cm',b='3 cm',h='2 cm',extra=''):
 body=rect(85,85,230,110)+line(85,85,145,35)+line(315,85,375,35)+line(145,35,375,35)+line(375,35,375,145)+line(375,145,315,195)+text(175,225,a)+text(325,190,b)+text(30,145,h)+text(145,20,extra)
 return svg(body,500,255,'Right rectangular prism with labeled dimensions')
layer=svg(''.join(rect(100+x*45,50+y*45,45,45) for y in range(3) for x in range(4))+text(100,215,'5 identical layers; 1 cm cubes'),500,250,'One complete layer of a solid, four by three unit squares')
put('PRISM-LAYERS','Find the volume in cubic centimeters.','60','4*3*5',visual=layer)
put('CUBE-LAYERS-COUNT','Each square represents one cube per layer. How many cubes are in both stacks?','42','4*3*2+3*2*3',visual=svg(''.join(rect(40+x*30,50+y*30,30,30) for y in range(3) for x in range(4))+''.join(rect(260+x*30,50+y*30,30,30) for y in range(2) for x in range(3))+text(40,180,'Stack A: 2 layers')+text(260,180,'Stack B: 3 layers'),500,215,'Two adjoining stack layer plans'))
put('PRISM-BASE-HEIGHT','Find the volume in cubic centimeters.','60','12*5',visual=prism('base area: 12 cm²','','5 cm'))
put('PRISM-MISSING-EDGE','The prism has volume @15/2@ cubic meters. Edges A and B are @3/2@ and @5/3@ meters. Find h in meters.','3','(15/2)/((3/2)*(5/3))',visual=prism('A','B','h'))
put('COMPOSITE-MISSING-VOLUME','The solid’s total volume is @50@ cubic centimeters. Find component B’s volume in cubic centimeters.','26','50-4*3*2',visual=svg(rect(70,60,200,100)+rect(270,60,130,100)+text(90,90,'A: 4 × 3 × 2 cm')+text(310,115,'B'),500,210,'Two nonoverlapping rectangular-prism components A and B'))
put('VOLUME-ATTRIBUTE','What attribute of the solid is measured by counting the unit cubes that fill it?','volume',solution=['Counting cubic units filling an interior measures volume.'],visual=layer)
put('CUBIC-UNIT-IDENTIFY','Each edge of the unit cube is @1@ centimeter. Name the volume unit.','cubic centimeter',solution=['A cube with 1-centimeter edges occupies one cubic centimeter.'],visual=prism('1 cm','1 cm','1 cm'))
put('QUAD-HIERARCHY-BLANK','Complete the missing category. Arrows mean “is a type of.”','parallelogram',solution=['Both rectangles and rhombuses are parallelograms, which are quadrilaterals.'],visual=svg(text(15,45,'rectangle')+text(310,45,'rhombus')+line(110,55,240,110)+line(360,55,240,110)+text(225,140,'?')+line(240,150,240,185)+text(160,218,'quadrilateral'),500,250,'Two named classes join at a missing parent category'))
put('QUAD-COMMON-CLASS','Name the most specific common parent of rectangles and rhombuses.','parallelogram',solution=['Each is a parallelogram. That is the closest common parent in the displayed hierarchy.'],visual=svg(text(160,35,'quadrilateral')+line(245,45,245,80)+text(155,110,'parallelogram')+line(230,125,90,170)+line(260,125,385,170)+text(35,200,'rectangle')+text(335,200,'rhombus'),500,230,'Inclusive hierarchy of quadrilaterals'))
put('SCALE-TWICE','The strip is @8@ meters long. Select @3/4@ of it, then @1/2@ of that selection. Find the final length.','3','8*(3/4)*(1/2)',visual=svg(''.join(rect(50+j*50,70,50,70,'#999' if j<3 else '#ddd' if j<6 else 'white') for j in range(8))+text(60,45,'8 equal sections; dark part is final selection'),520,190,'A strip with six sections selected and three of those shaded dark'))
put('ESTIMATE-DIFFERENCE','Each large bar is one unit. What whole number is closest to A minus B?','2',solution=['A=11/4 and B=3/4; their difference is exactly 2.'],visual=svg(text(15,55,'A')+''.join(rect(50+j*25,25,25,45,'#aaa' if j<11 else 'white') for j in range(12))+text(15,150,'B')+''.join(rect(50+j*25,120,25,45,'#aaa' if j<3 else 'white') for j in range(4))+line(50,90,150,90)+text(65,112,'1 unit',16),500,205,'Unit bars each partitioned into fourths'))
put('RECT-TILE-AREA','Each tile is @1/2@ meter by @1/3@ meter. Find the full rectangle’s area in square meters.','2','(4/2)*(3/3)',visual=svg(''.join(rect(90+x*65,30+y*50,65,50) for x in range(4) for y in range(3)),500,210,'Rectangle tiled in four columns and three rows'))
put('EQUIVALENCE-SELECT','Which expression equals @3(2x+4)+x@ for every @x@?','B',solution=['Distribute and combine: 6x+12+x=7x+12.'],choices=['@7x+4@','@7x+12@','@6x+12@','@9x+12@'])
put('TRANSLATE-TWO-PARTS','Each variable section has length @x@. Write an expression for the total length.','3x+4',solution=['Three sections contribute 3x and the fixed section contributes 4.'],visual=svg(''.join(rect(45+j*100,60,100,65)+text(85+j*100,102,label) for j,label in enumerate(['x','x','x','4'])),500,170,'Bar with three equal variable sections and a fixed section'))
put('MEDIAN-SORTED-DATA','Find the median.','4','(3+5)/2',visual=dotplot([1,3,3,5,7,9]))
put('DISTRIBUTION-MEDIAN','Find the median.','4','(3+5)/2',visual=dotplot([1,3,3,5,7,9]))
put('DISTRIBUTION-CENTER-SHIFT','Every observation increases by @2@. Find the new median.','6','(3+5)/2+2',visual=dotplot([1,3,3,5,7,9]))
put('DISTRIBUTION-INTERVAL-COUNT','How many observations are between @3@ and @7@, inclusive?','4','2+1+1',visual=dotplot([1,3,3,5,7,9]))
put('DATA-OBSERVATIONS','How many observations are shown?','6','1+2+1+1+1',visual=dotplot([1,3,3,5,7,9]))
put('DATA-MISSING-FREQUENCY','There are @10@ observations. Find the missing frequency.','4','10-2-3-1',visual=svg(text(60,40,'Value')+text(220,40,'Frequency')+''.join(text(60,80+j*35,v)+text(240,80+j*35,n) for j,(v,n) in enumerate([(1,2),(2,3),(3,'?'),(4,1)])),420,220,'Frequency display with one missing count'))
put('NUMBERLINE-INTERPOLATE','Find the coordinate of P.','1/2','1/2',visual=numberline(0,2,[('P',.5)]))
put('NUMBERLINE-REFLECT-POINT','Reflect P across zero. What is the coordinate of its reflection?','-2','-2',visual=numberline(-4,4,[('P',2)]))
put('INEQUALITY-GRAPH-READ','Write the inequality represented for @x@.','x > 2',solution=['The open endpoint excludes 2; the ray extends to greater values.'],visual=svg(line(50,130,455,130)+line(250,130,450,130)+line(450,130,437,122)+line(450,130,437,138)+'<circle cx="250" cy="130" r="7" fill="white" stroke="black" stroke-width="2"/>'+text(240,165,'2'),500,200,'Open endpoint at 2 with a ray to the right'))
put('FUNCTION-MISSING-PARAMETER','The table follows @y=3x+b@. Find @b@.','5','17-3*4',visual=table(['x','y'],[['4','17']]))
put('CONVERT-MISSING-PART','Two joined strips total @250@ centimeters. One measures @1@ meter. How many meters long is the other?','1.5','(250-100)/100',visual=table(['Meters','Centimeters'],[['1','100'],['2','200']]))
put('RATIO-TABLE-INPUT','The quantities are proportional. Find the missing input x.','5','15/(6/2)',visual=table(['Input','Output'],[['2','6'],['x','15']]))
put('PROPORTIONALITY-CONSTANT','The table follows @y=kx@. Find @k@.','3','6/2',visual=table(['x','y'],[['2','6'],['4','12'],['6','18']]))
put('RATIO-PART-WHOLE','Write the shaded-to-total ratio in simplest form.','2:5',solution=['There are 4 shaded objects out of 10. The ratio 4:10 simplifies to 2:5.'],visual=svg(''.join(rect(50+(j%5)*60,30+(j//5)*65,40,40,'#888' if j<4 else 'white') for j in range(10)),430,180,'Ten objects, four shaded'))
# Vocabulary MCQ choices are meaningful categories, not padded binary labels.
for c,stem,answer,choices,solution in [
 ('CENTER-OUTLIER-CHOICE','Most travel times are near @10@ minutes; one is @120@. Which measure best describes a typical time?','B',['mean','median','range','interquartile range'],'The extreme value strongly changes the mean; the median is a resistant measure of center.'),
 ('VARIABILITY-OUTLIER-CHOICE','Most times cluster closely, but one is extremely large. Which spread measure best limits the extreme value’s effect?','D',['mean','median','range','interquartile range'],'The interquartile range measures the spread of the middle 50% and resists extreme values.'),
 ('DATA-UNIT-CHOICE','Students record plant heights in centimeters. Which unit belongs with the reported mean height?','A',['centimeters','square centimeters','cubic centimeters','plants'],'A mean retains the measurement unit, centimeters.'),
 ('STAT-QUESTION-SELECT','Which question anticipates variability across a group?','C',['How many sides has a square?','What is 6 plus 4?','How tall are our class plants?','How many minutes are in an hour?'],'Plant heights vary across the group; the other questions have fixed answers.'),
 ('OPPOSITE-PAIR','Which pair consists of opposites?','C',['@(-3,-3)@','@(-2,3)@','@(-4,4)@','@(2,4)@'],'Only -4 and 4 have equal magnitude and opposite signs.'),
 ('SAMPLE-BIAS-CLASSIFY','To estimate all students’ travel times, only bus riders are surveyed. Which feature most threatens the estimate?','B',['random selection','undercoverage','measurement rounding','large sample'],'Students using other transport are excluded, so the sample undercovers the population.')
]:put(c,stem,answer,solution=[solution],choices=choices)
for c,stem,ans,calc in [
 ('DECIMAL-PRODUCT-DERIVED-FACTOR','A rectangle is @3.2@ meters long. Its width is @1.2@ meters shorter. Find its area in square meters.','6.4','3.2*(3.2-1.2)'),
 ('DECIMAL-PRODUCT-TWO-LENGTHS','A rectangle’s width combines @1.2@ and @0.8@ meters. Its length is @3.5@ meters. Find its area in square meters.','7','(1.2+0.8)*3.5'),
 ('FRACTION-PRODUCT-DERIVED-FACTOR','A rectangle’s width combines @1/2@ and @1/3@ meter. Its length is @3/4@ meter. Find its area in square meters.','5/8','(1/2+1/3)*(3/4)'),
 ('FRACTION-PRODUCT-REMAINING-AREA','A sheet measures @3/4@ by @2/3@ meter. Remove @1/4@ of its area. Find the remaining area in square meters.','3/8','(3/4)*(2/3)*(1-1/4)'),
 ('DECIMAL-QUOTIENT-COMBINED-LENGTH','Join @2.4@ and @1.8@ meters. Cut into @0.6@-meter pieces. How many pieces result?','7','(2.4+1.8)/.6'),
 ('DECIMAL-QUOTIENT-REMAINDER-LENGTH','Join @2.4@ and @1.8@ meters. Remove @0.6@ meter. Cut the rest into @0.3@-meter pieces. How many pieces result?','12','(2.4+1.8-.6)/.3'),
 ('FRACTION-QUOTIENT-UNIT-CONVERSION','Cut @3/4@ meter into pieces @25/2@ centimeters long. How many pieces result? @100@ centimeters = @1@ meter.','6','(3/4)*100/(25/2)'),
 ('SHARE-REMAINDER-QUOTIENT','A container has @9@ liters. Reserve @2@ liters. Share the remainder among @4@ groups. How many liters per group?','7/4','(9-2)/4'),
 ('WHOLE-QUOTIENT-ROW-GROUPS','There are @32@ rows of @18@ counters. Repack them in groups of @24@. How many groups result?','24','32*18/24'),
]:put(c,stem,ans,calc)
put('WHOLE-QUOTIENT-REMAINDER','Divide @1457@ by @24@. Write quotient and remainder as @q@ R @r@.','60 R 17',solution=['24×60+17=1457, with 0≤17<24.'])
def angle(labels):return svg(line(45,170,455,170)+line(250,170,330,35)+text(125,132,labels[0])+text(305,132,labels[1]),500,210,'Two adjacent angles on a straight line')
put('ANGLE-SUPPLEMENT','Find the unknown angle in degrees.','65','180-115',visual=angle(['115°','?']))
put('ADJACENT-LINEAR-ANGLE-SOLVE','Find the angle labeled @2x+10@, in degrees.','70','2*((180-10-20)/(2+3))+10',visual=angle(['2x + 10','3x + 20']))
put('NUMBERLINE-NET-SUM','Start at @-2@. Follow the two arrows in order. Find the final position.','1','-2+4-1',visual=numberline(-4,4,arrows=[(-2,2),(2,1)]))
put('NUMBERLINE-MISSING-MOVE','Start at @-2@. First move @+4@. The final point is P. Find the second signed move.','-1','1-(-2+4)',visual=numberline(-4,4,[('P',1)],[(-2,2)]))
# Geometric data carry every needed dimension; no supplied opposite-face shortcut.
L=svg('<path d="M70 30 H390 V110 H230 V230 H70 Z" fill="white" stroke="black" stroke-width="2"/>'+text(200,25,'8 cm')+text(15,140,'5 cm')+text(285,140,'4 cm')+text(240,190,'3 cm'),500,270,'L-shaped polygon with outer width 8, outer height 5, missing rectangle width 4 and height 3')
put('POLYGON-DECOMPOSE-AREA','Find the area in square centimeters.','28','8*5-4*3',visual=L)
put('COMPOSITE-AREA-DEDUCE','Find the total area in square centimeters.','28','8*3+(8-4)*2/2',visual=svg(rect(70,100,320,120)+'<path d="M70 100 L230 20 L230 100 Z" fill="white" stroke="black" stroke-width="2"/>'+text(200,250,'8 cm')+text(395,165,'3 cm')+text(265,90,'4 cm')+text(120,62,'2 cm'),500,280,'Rectangle topped on the left by a right triangle; rectangle width 8, height 3; uncovered top length 4 and triangle altitude 2'))
def net(base='3 cm',height='5 cm',extra=''):
 b=''.join(rect(40+j*100,95,100,100) for j in range(4))+rect(140,15,100,80)+rect(140,195,100,80)+text(150,60,base,17)+text(45,150,height,17)+text(35,308,extra,18)
 return svg(b,500,335,'Prism net with two bases and four side rectangles; not drawn to scale')
put('SQUARE-PRISM-NET-AREA','Find the total surface area in square centimeters.','78','2*(12/4)**2+12*5',visual=net('square','5 cm','Each square base has perimeter 12 cm.'))
put('NET-SURFACE-AREA-FROM-PERIMETER','The base is rectangular. Find the total surface area in square centimeters.','94','2*3*(14/2-3)+14*5',visual=net('edge 3 cm','5 cm','Base perimeter: 14 cm; other edge unknown.'))
triNet=svg(''.join(rect(50+j*130,90,130,110) for j in range(3))+'<polygon points="180,90 310,90 180,20" fill="white" stroke="black" stroke-width="2"/><polygon points="180,200 310,200 180,270" fill="white" stroke="black" stroke-width="2"/>'+text(70,150,'3 × 6')+text(200,150,'4 × 6')+text(330,150,'5 × 6')+text(180,12,'Right triangles: legs 3 and 4',16)+text(70,305,'All lengths are centimeters.'),500,335,'Triangular prism net with three rectangular faces and two congruent right triangles')
put('NET-ADD-FACES','Find the surface area in square centimeters.','84','3*6+4*6+5*6+2*(3*4/2)',visual=triNet)
put('COMPARE-MEANS','Find mean B minus mean A.','2','(4+6+8)/3-(2+4+6)/3',visual=svg(text(30,25,'A')+''.join(text(100+j*100,70,v) for j,v in enumerate([2,4,6]))+text(30,130,'B')+''.join(text(100+j*100,175,v) for j,v in enumerate([4,6,8])),500,220,'Two aligned data displays with equal numeric scale'))
put('MEDIAN-GAP-IN-SPREADS','How many common spread units separate the centers?','2','(14-10)/2',visual=svg(line(60,155,440,155)+text(70,105,'A: median 10')+text(275,105,'B: median 14')+text(80,45,'Both interquartile ranges equal 2'),500,205,'Same-scale distributions summarized by centers 10 and 14 and common interquartile range 2'))
put('SIMULATION-EVENT-ESTIMATE','Estimate the probability of red or blue.','3/4','(12+18)/(12+18+10)',visual=table(['Outcome','Frequency'],[['red','12'],['blue','18'],['green','10']]))
space=table(['Coin','Number'],[['H','1'],['H','2'],['H','3'],['T','1'],['T','2'],['T','3']])
put('COMPOUND-PROBABILITY','The listed outcomes are equally likely. Find the probability of H and an even number.','1/6','1/6',visual=space)
put('COMPOUND-COUNT','How many listed outcomes have T or the number @2@?','4','3+2-1',visual=space)
put('PROPORTION-UNIT-POINT','The horizontal axis counts minutes and vertical axis liters. Point P is @(1,3)@. How many liters correspond to one minute?','3','3',visual=plane([('P',1,3)]))
# Four graphs, readable at the allocated large footprint.
b=''
for j,coords in enumerate([[(0,0),(1,2),(2,4)],[(0,1),(1,2),(2,3)],[(0,4),(1,3),(2,2)],[(0,0),(1,1),(2,4)]]):
 ox=45+(j%2)*240;oy=195+(j//2)*225;b+=line(ox,oy,ox+170,oy)+line(ox,oy,ox,oy-160)+text(ox+10,oy-165,chr(65+j))+text(ox-15,oy+20,'0',16)
 for a,c in zip(coords,coords[1:]):b+=line(ox+a[0]*70,oy-a[1]*35,ox+c[0]*70,oy-c[1]*35)
put('PROPORTION-CLASSIFY','Which graph represents a proportional relationship?','A',solution=['Only A is a straight line through the origin.'],visual=svg(b,510,460,'Four graphs labeled A–D, showing proportional and nonproportional relationships'),choices=['Graph A','Graph B','Graph C','Graph D'])
put('CROSS-SECTION','The cutting plane is parallel to the rectangular base. What shape is the cross-section?','B',solution=['A plane parallel to a rectangular prism’s base cuts a rectangle.'],visual=svg(prism()['svg'].split('>',1)[1].rsplit('</svg>',1)[0]+'<polygon points="85,145 145,95 375,95 315,145" fill="#bbb" fill-opacity="0.6" stroke="black" stroke-width="2"/>',500,255,'Rectangular prism cut by a shaded plane parallel to the base'),choices=['triangle','rectangle','pentagon','circle'])
put('WHOLE-PRODUCT-JOINED-ROWS','Combine @120@ rows and @6@ rows, each with @24@ counters. How many counters are there?','3024','(120+6)*24')
put('UNIT-DIV-TWO-PORTION-SIZES','Share @6@ meters equally among @3@ batches. Cut one batch into @1/2@-meter pieces and another into @1/4@-meter pieces. How many pieces altogether?','12','(6/3)/(1/2)+(6/3)/(1/4)')
put('PRISM-VOLUME-EXTENDED-EDGE','Edges A, B, h measure @3/2,4/3,2@ meters. Extend h by @1/2@ meter. Find the new volume in cubic meters.','5','(3/2)*(4/3)*(2+1/2)',visual=prism('A','B','h'))
put('INEQUALITY-DERIVE-FROM-TOTAL','A load has @4@ fixed kilograms plus @x@ extra kilograms. Total mass must be below @15@ kilograms. Write an inequality for @x@.','x < 11',solution=['4+x<15 is equivalent to x<11.'])
put('NUMBERLINE-SUM-WITH-OPPOSITE','Find P’s coordinate plus the opposite of Q’s coordinate.','-5','-2+(-3)',visual=numberline(-4,4,[('P',-2),('Q',3)]))
put('SAMPLE-REPRESENTATIVE-SELECT','Which procedure gives a representative sample of all students’ travel times?','C',solution=['Random selection from the complete student list gives each student an equal chance. The other procedures exclude groups.'],choices=['Survey only bus riders.','Survey the first ten arrivals.','Randomly select from the full student list.','Ask students who volunteer.'])
put('PATTERN-PAIR-FROM-TOTAL','A starts @2@, adding @3@. B starts @1@, adding @5@. Corresponding terms total @27@. Find @(A,B)@.','(11,16)',solution=['Corresponding totals are 3,11,19,27. At the fourth position A=11 and B=16; positive increments make this position unique.'])
# Mathematical claims are checked against the actual branch, not a generic code.
def for_spec(r):
 import copy
 w=copy.deepcopy(T[r['structureCode']]);c=r['structureCode'];g=r['grade'];claim=r['claimId']
 def use(stem,answer,calculation=None,solution=None,visual=None,choices=None):
  w.update(stem=stem,answer=str(answer),calculation=calculation,solution=solution or ([f'{calculation} = {answer}.'] if calculation else []),visual=visual,choices=choices or [])
 if c=='PATTERN-MISSING-START':use('A: start @8@, add @3@. B: add @4@. Their fourth terms match. Find B’s starting value.','5','8+3*3-3*4')
 if c=='PLACE-ADJACENT-FACTOR':w['stem']='The @6@ in @0.6@ is how many times the value of the @6@ in @0.06@?'
 if c=='ADD-TWO' and g==5 and claim=='G5-018':use('Join a @2/3@-meter strip and a @3/4@-meter strip. Find the combined length in meters.','17/12','2/3+3/4')
 if c=='ADD-TWO' and g==7:use('A temperature changes by @-3/4@ degree, then @1/2@ degree. Find the total change in degrees.','-1/4','-3/4+1/2')
 if c=='SUBTRACT-TWO' and g==7:use('Calculate @-3/4-1/2@.','-5/4','-3/4-1/2')
 if c=='ADD-THREE' and g==7:use('A temperature starts at @-2@ degrees, rises @3/4@ degree, then falls @1/2@ degree. Find the final temperature.','-7/4','-2+3/4-1/2')
 if c=='MULTIPLY-TWO' and g==7:use('Calculate @(-3/4)\\times(-2/3)@.','1/2','(-3/4)*(-2/3)')
 if c=='DIV-QUOTIENT' and g==7:use('Calculate @(-3/4)\\div(1/2)@.','-3/2','(-3/4)/(1/2)')
 if c=='DIV-DIVISOR' and g==7:use('Find @d@: @(-3/4)\\div d=3/2@.','-1/2','(-3/4)/(3/2)')
 if c=='ADD-MISSING-PART' and g==5:use('Two strips join to make @7/4@ meters. One is @2/3@ meter. How many meters long is the other?','13/12','7/4-2/3')
 if c=='ADD-MISSING-PART' and g==7:
  use('A value changes from @-3/4@ to @1/2@ by adding @a@. Find @a@.','5/4','1/2-(-3/4)')
  if claim=='G7-010':use('Find @a@: @a+(-3/4)=1/2@.','5/4','1/2-(-3/4)')
 if c=='ADD-THEN-SUBTRACT' and r['context']!='Pure mathematics':use('A strip starts at @3/4@ meter. Add @2/3@ meter, then remove @1/2@ meter. How many meters remain?','11/12','3/4+2/3-1/2')
 if c=='COMPARE-TWO' and g==6:use('A’s temperature is @-3/4@ degree. B’s is @-1/2@ degree. Compare A to B using @<,>,=@.','<',solution=['-3/4 is less than -1/2.'])
 if c=='COORD-DISTANCE' and g==6:use('Points are @(-3,2)@ and @(4,2)@. Find their distance in units.','7','4-(-3)')
 if c=='DISTRIBUTION-RANGE' and g==6:use('Find the range.','8','9-1',visual=dotplot([1,3,3,5,7,9]))
 if c=='PROPORTION-CLASSIFY' and r['responseMode']=='shortAnswer':use('Is the table proportional or nonproportional?','nonproportional',solution=['The ratios are 3,3, and 10/3; no single constant applies.'],visual=table(['x','y'],[['1','3'],['2','6'],['3','10']]))
 if c=='SCALING-INFER-INTERVAL' and r['visualPolicy']=='Required':use('The bars show a positive quantity before and after multiplication by @k@. Is @k@ below, equal to, or above @1@?','above 1',solution=['The result exceeds the positive original; k>1.'],visual=bars(['Original: 4','Result: 6'],[200,300]))
 if c=='FUNCTION-OUTPUT' and r['context']!='Pure mathematics':use('A container’s volume @y@ in liters follows @y=3x+2@ after @x@ minutes. Find @y@ at @x=4@.','14','3*4+2')
 if c=='EVALUATE-TWO-CASES-DIFF':w['stem']='For @E=3x+2@, find its value at @x=5@ minus its value at @x=2@.'
 if c=='TEST-TWO-CONDITIONS':use('Choose from @0,1,2,3@: @(x-1)(x-3)=0@ and @x<2@.','1',solution=['1 and 3 satisfy the equation; only 1 satisfies x<2.'])
 if c=='PRISM-EDGE-VOLUME':w['stem']='A rectangular prism has edges @3/2,4/3,5/2@ meters. Find its volume in cubic meters.'
 if c in ['UNIT-RATE','UNIT-RATE-DIFFERENCE'] and g==7:
  if c=='UNIT-RATE-DIFFERENCE':use('A fills @3/2@ liters in @3/4@ minute. B fills @3/2@ liters in @1/2@ minute. Find B’s rate minus A’s in liters/minute.','1','(3/2)/(1/2)-(3/2)/(3/4)')
 if c=='COMBINE-LIKE-TERMS' and g==7:use('Find the coefficient of @x@ after combining @1/2x+3/4x-1/4x@.','1','1/2+3/4-1/4')
 if c=='DISTRIBUTE-CONSTANT' and g==7:use('Find @b@: @1/2(6x+8)=3x+b@.','4','(1/2)*8')
 if c=='DISTRIBUTE-COEFFICIENT' and g==7:use('Find @a@: @3/2(4x+6)=ax+9@.','6','(3/2)*4')
 if c=='FACTOR-LINEAR-MISSING' and g==7:use('Find @b@: @3/2x+9/2=3/2(x+b)@.','3','(9/2)/(3/2)')
 if c=='NET-ADD-FACES' and g==7:
  # Fractional prism length while retaining exact integral surface-area result.
  w.update(stem='The prism length is @3/2@ centimeters. The triangular bases have legs @3@ and @4@. Find surface area in square centimeters.',answer='30',calculation='(3+4+5)*(3/2)+2*(3*4/2)',solution=['Two triangular bases total 12 cm². Side faces total (3+4+5)×3/2=18 cm². Total surface area is 30 cm².'],visual=svg(triNet['svg'].split('>',1)[1].rsplit('</svg>',1)[0].replace('3 × 6','3 × L').replace('4 × 6','4 × L').replace('5 × 6','5 × L'),500,335,'Triangular prism net; all rectangular faces have common length L'))
 if c=='POLYGON-DECOMPOSE-AREA':
  # The interior horizontal length is inferred, rather than supplied twice.
  w.update(visual=svg('<path d="M70 30 H390 V110 H230 V230 H70 Z" fill="white" stroke="black" stroke-width="2"/>'+text(200,25,'8 cm')+text(15,140,'5 cm')+text(100,260,'4 cm')+text(400,75,'2 cm'),500,285,'L-shaped polygon: overall 8 by 5; lower width 4; upper-right vertical side 2'),calculation='8*5-(8-4)*(5-2)',solution=['The removed rectangle is (8-4) by (5-2), or 4 by 3. The area is 8×5-4×3=28 cm².'])
 if c=='INEQUALITY-GRAPH-READ':
  w['visual']=svg(line(50,130,455,130)+line(250,130,450,130).replace('stroke-width="2"','stroke-width="6"')+line(450,130,436,120)+line(450,130,436,140)+'<circle cx="250" cy="130" r="8" fill="white" stroke="black" stroke-width="2"/>'+text(240,168,'2'),500,205,'Thin number-line axis with a thick rightward solution ray and open endpoint at 2')
 if c=='COMPOSITE-AREA-DEDUCE':
  w['visual']=svg(rect(70,100,320,120)+'<path d="M70 100 L230 20 L230 100 Z" fill="white" stroke="black" stroke-width="2"/>'+line(220,100,220,90)+line(220,90,230,90)+text(200,250,'8 cm')+text(395,165,'3 cm')+text(285,90,'4 cm')+text(240,60,'2 cm'),500,280,'Rectangle topped by a right triangle; triangle altitude 2 is labeled beside its vertical leg, rectangle width 8, height 3 and uncovered top length 4')
 if c=='ADJACENT-LINEAR-ANGLE-SOLVE':w['visual']=svg(line(45,170,455,170)+line(250,170,201,35)+text(115,130,'2x + 10')+text(300,130,'3x + 20'),500,210,'Straight angle split into a left acute angle and right obtuse angle with linear expressions')
 if c in ['SQUARE-PRISM-NET-AREA','NET-SURFACE-AREA-FROM-PERIMETER']:
  widths=[75,75,75,75] if c=='SQUARE-PRISM-NET-AREA' else [75,100,75,100]
  x=50;b='';h=125;y=100
  for width in widths:b+=rect(x,y,width,h);x+=width
  b+=rect(125,25,widths[1],75)+rect(125,225,widths[1],75)+text(55,170,'5 cm',18)
  if c=='SQUARE-PRISM-NET-AREA':b+=text(135,70,'square',16)+text(35,335,'Each square base has perimeter 12 cm.',18)
  else:b+=text(235,70,'edge 3 cm',18)+text(35,335,'Base perimeter: 14 cm',18)
  w['visual']=svg(b,470,365,'Prism net with six dimensionally consistent faces and the supplied base-perimeter condition')
 if c=='VOLUME-ATTRIBUTE':
  b=rect(80,100,180,120)+line(80,100,140,40)+line(140,40,320,40)+line(320,40,320,160)+line(320,160,260,220)+line(260,100,320,40)
  for x in [140,200]:b+=line(x,100,x,220)+line(x,100,x+60,40)
  b+=line(80,160,260,160)+line(260,160,320,100)+line(110,70,290,70)+line(290,70,290,190)+text(75,260,'Unit cubes fill the solid.',20)
  w['visual']=svg(b,440,290,'Solid composed of three columns, two rows and two layers of unit cubes')
 if c=='CUBIC-UNIT-IDENTIFY':w['visual']=svg(rect(100,90,150,150)+line(100,90,145,45)+line(145,45,295,45)+line(295,45,295,195)+line(295,195,250,240)+line(250,90,295,45)+text(150,270,'1 cm')+text(35,165,'1 cm')+text(265,240,'1 cm'),380,300,'Unit cube with equal front edges and three edges labeled 1 centimeter')
 if c=='SIMULATION-EVENT-ESTIMATE':w['stem']='Simulation results are shown. Estimate the probability of red or blue.'
 if c=='NUMBERLINE-INTERPOLATE':
  b=line(50,130,450,130)
  for j in range(7):b+=line(50+j*400/6,124,50+j*400/6,136)
  b+=text(43,168,'0')+text(443,168,'3')+text(242,110,'P')+'<circle cx="250" cy="130" r="5" fill="black"/>'
  w.update(answer='3/2',calculation='3/6*3',solution=['Six equal intervals span 3 units, so each is 1/2. P is three intervals from 0, at 3/2.'],visual=svg(b,500,200,'Six equal intervals from 0 to 3, with P on the third interval'))
 if c=='MEDIAN-GAP-IN-SPREADS':
  b=line(60,190,440,190)
  for n in range(6,19,2):b+=text(60+(n-6)*28,218,n,16)
  for label,center,y in [('A',10,60),('B',14,130)]:
   x=lambda n:60+(n-6)*28
   b+=text(20,y+10,label)+line(x(center-3),y,x(center+3),y)+rect(x(center-1),y-18,56,36)+line(x(center),y-18,x(center),y+18)+line(x(center-3),y-10,x(center-3),y+10)+line(x(center+3),y-10,x(center+3),y+10)
  w['visual']=svg(b+text(90,250,'Both interquartile ranges: 2',18),500,280,'Box plots on a common scale; medians 10 and 14, IQR 2 each')
 if c=='COMPARE-MEANS':
  b=''
  for label,values,y in [('A',[2,4,6],90),('B',[4,6,8],220)]:
   b+=text(15,y-35,label)+line(70,y,430,y)
   for n in range(0,11,2):b+=line(70+n*34,y-5,70+n*34,y+5)+text(65+n*34,y+30,n,16)
   for n in values:b+=f'<circle cx="{70+n*34}" cy="{y-20}" r="6" fill="black"/>'
  w['visual']=svg(b,500,285,'Two dot plots A and B on the same zero-to-ten scale')
 if c=='PROPORTION-UNIT-POINT':w['visual']['svg']=w['visual']['svg'].replace('</svg>',line(60,345,160,45)+'</svg>')
 if c=='COMPOSITE-MISSING-VOLUME':
  b=rect(70,85,220,110)+rect(290,85,110,110)+line(70,85,115,40)+line(290,85,335,40)+line(400,85,445,40)+line(115,40,445,40)+line(445,40,445,150)+line(445,150,400,195)+text(105,128,'A')+text(330,135,'B')+text(60,230,'A: length 4, width 3, height 2 cm',18)
  w['visual']=svg(b,500,265,'Two adjacent nonoverlapping rectangular prisms A and B with A dimensions stated')
 return w
# Fraction math uses exact rational arithmetic; no floating-point answer tolerance.
def evaluate(expr):
 def walk(n):
  if isinstance(n,ast.Expression):return walk(n.body)
  if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):return F(str(n.value))
  if isinstance(n,ast.UnaryOp):return -walk(n.operand) if isinstance(n.op,ast.USub) else walk(n.operand)
  if isinstance(n,ast.BinOp):
   a,b=walk(n.left),walk(n.right)
   if isinstance(n.op,ast.Add):return a+b
   if isinstance(n.op,ast.Sub):return a-b
   if isinstance(n.op,ast.Mult):return a*b
   if isinstance(n.op,ast.Div):return a/b
   if isinstance(n.op,ast.Pow) and b.denominator==1:return a**int(b)
  raise ValueError('Unsupported calculation '+expr)
 return walk(ast.parse(expr,mode='eval'))
def native(t):
 def eq(m):
  body=m.group(1)
  body=re.sub(r'(?<![0-9])(-?\d+(?:\.\d+)?)/([A-Za-z]|\d+(?:\.\d+)?)',lambda q:r'\frac{'+q[1]+'}{'+q[2]+'}',body)
  return r'\( '+body+r' \)'
 return re.sub(r'@([^@]+)@',eq,t)
if __name__=='__main__':
 bank=json.loads((ROOT/'work/v03/compiled.json').read_text());out={};errors=[]
 for r in bank['items']:
  try:w=for_spec(r)
  except Exception as e:errors.append((r['key'],str(e)));continue
  if not w['solution']:errors.append((r['key'],'Missing solution '+r['structureCode']))
  if w['calculation']:
   try:assert evaluate(w['calculation'])==F(w['answer'].removesuffix('%'))
   except Exception as e:errors.append((r['key'],'Arithmetic '+str(e)+' '+w['calculation']))
  if (r['visualPolicy']=='Required')!=bool(w['visual']):errors.append((r['key'],'Visual policy '+r['structureCode']))
  if (r['responseMode']=='mcq')!=bool(w['choices']):errors.append((r['key'],'Response mode '+r['structureCode']))
  w['stem']=native(w['stem']);w['choices']=[native(x) for x in w['choices']]
  w['catalogId']=r['catalogId'];out[r['key']]=w
 (ROOT/'data/v03/witnesses.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print('Witnesses',len(out),'errors',len(errors))
 for x in errors:print(x)
 if errors:raise SystemExit(1)
