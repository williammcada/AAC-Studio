/** Test-only dependency is installed in an isolated QA directory. */
declare module 'fake-indexeddb' {
 export const indexedDB: IDBFactory;
 export const IDBKeyRange: typeof globalThis.IDBKeyRange;
}
