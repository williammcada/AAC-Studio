import assert from 'node:assert/strict';
import original from '../data/blueprint-4.4-original.json';
import {seed,slots,checklist,type State,type Packet,type Spec} from '../lib/model';
import {applyOperation,backup,verifyBackup} from '../lib/operations';
import {digest,stable,makePacket,parseResult,validateItem,validateBlueprint,designRevision,canFinalize} from '../lib/validation';
import {scalarValue} from '../lib/exact-number';
import {taskIntegrity,semanticIdentity} from '../lib/task-integrity';
import {resultSkeleton,conflictSkeleton,packetText} from '../lib/packet';
const blank:State={forms:{}};
const old=(key:string)=>original.items.find(i=>i.key===key)! as Spec;
assert.ok(taskIntegrity(old('5|4|6')).some(i=>i.code==='scope'));
assert.ok(taskIntegrity(old('7|4|7')).some(i=>i.code==='response-scope'));
assert.equal(semanticIdentity(old('6|4|9')),semanticIdentity({...old('7|4|5'),structureCode:'AN-UNRELATED-ID',structureFamilyId:'COSMETIC-RENAME'}));
assert.ok(taskIntegrity(old('6|3|6')).some(i=>i.code==='baseline-text'));
assert.ok(taskIntegrity(old('6|4|8')).some(i=>i.code==='choice-domain'));
for(const grade of [5,6,7])for(let form=4;form<=8;form++){
 assert.deepEqual(validateBlueprint(grade,form).filter(i=>i.severity==='error'),[],`G${grade} V${form}`);
 const a=slots(grade,form);assert.ok(a.filter(i=>i.dok===1).length<=6);assert.ok(a.filter(i=>i.dok===2).length>=8);if(form===4){assert.equal(a.filter(i=>i.dok===1).length,6);assert.equal(a.filter(i=>i.dok===2).length,9);}
}
for(const s of seed.items.filter(i=>i.legacy)){const before=old(s.key);assert.equal(s.templateId,before.templateId);assert.equal(s.surfaceFormId,before.surfaceFormId);}
for(const [text,value] of [['12π',12*Math.PI],['3π/2',1.5*Math.PI],['1/2π',Math.PI/2],['sqrt(2)',Math.sqrt(2)],['-1 1/2',-1.5],['1,200.5',1200.5],['25%',.25]] as const)assert.equal(scalarValue(text),value,text);
for(const text of ['1/0','π/0','sqrt(2)/0','1,2','process.exit()','2x','NaN','Infinity'])assert.equal(scalarValue(text),null,text);
const p=await makePacket(7,4,blank),circle=p.items.find(s=>s.standard==='7.G.B.4')!;
const numeric={...resultSkeleton(p).items[circle.question-1],stem:'Find the area.',answer:'12π',scoringNote:'Award 1 point.',solution:['Exact area.'],visual:null,reviewed:false};
assert.ok(!validateItem(numeric,circle,blank,[numeric]).some(i=>i.code==='answer'));
function filled(packet:Packet){const r=resultSkeleton(packet),answer:Record<string,string>={Number:'12',Label:'parallel',Symbol:'<','Comparison symbol':'<','Ordered pair':'(2, 3)',Equation:'x = 3',Inequality:'x > 3',Expression:'3x + 2',Ratio:'2:3'};return {...r,items:r.items.map((i,j)=>({...i,stem:`Find the value of ${j+1} plus 2.`,choices:packet.items[j].responseMode==='mcq'?['First','Second','Third','Fourth']:[],answer:packet.items[j].responseMode==='mcq'?'A':answer[packet.items[j].answerObject],scoringNote:'Award 1 point.',solution:['Transport fixture only.'],visual:packet.items[j].visualPolicy==='Required'?{kind:'svg' as const,alt:'Transport fixture',svg:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 80"><rect x="10" y="10" width="80" height="50" fill="white" stroke="black"/></svg>'}:null}))};}
let state=(await applyOperation(blank,{kind:'packet',grade:5,form:4})).state;
const packet=state.forms['5|4'].packet;state=(await applyOperation(state,{kind:'import',grade:5,form:4,result:filled(packet)})).state;
const prior=stable(state.forms['5|4'].items),c=conflictSkeleton(packet);c.issues=[{question:6,message:'The supplied source task contains conflicting givens.',suggestedRepair:'Review the actual source.'}];
state=(await applyOperation(state,{kind:'import',grade:5,form:4,result:c})).state;
assert.equal(stable(state.forms['5|4'].items),prior);assert.ok((await canFinalize(state.forms['5|4'],state)).some(i=>i.code==='reported-conflict'));
await assert.rejects(()=>applyOperation(state,{kind:'import',grade:5,form:4,result:{...c,packetId:'wrong'}}),/different packet/);
const invalid=filled(packet);invalid.items[0].answer='twelve apples';await assert.rejects(()=>applyOperation(state,{kind:'import',grade:5,form:4,result:invalid}),/number/i);assert.equal(stable(state.forms['5|4'].items),prior);
state=(await applyOperation(state,{kind:'resolveConflict',grade:5,form:4,resolution:'Checked the source; the missing condition was already present in the packet.'})).state;
assert.equal(state.forms['5|4'].conflict?.status,'resolved');assert.equal(stable(state.forms['5|4'].items),prior);
assert.equal((await verifyBackup(backup(state,3),blank)).forms['5|4'].conflict?.status,'resolved');
// Recreate the exact original packet transport, without modifying historical allocations.
const originalSlots=original.items.filter(s=>s.grade===5&&s.form===4);
const oldPacket={...packet,seedHash:original.seedHash,designRevision:'old-design',packetId:'old-packet',items:await Promise.all(originalSlots.map(async (s,j)=>({...s,specificationHash:await digest(s),proposedTemplateId:`ORIGINAL-T-${j+1}`,proposedSurfaceFormId:`ORIGINAL-SF-${j+1}`}))),adjacent:original.items.filter(s=>s.grade===5&&[3,5].includes(s.form)),paired:original.items.filter(s=>s.grade===6&&s.form===4)} as Packet;
const oldEntry={packet:oldPacket,items:filled(oldPacket).items.map(i=>({...i,reviewed:true})),checks:Object.fromEntries(Object.keys(checklist).filter(k=>k!=='cognitiveDemand').map(k=>[k,true])),status:'finalized' as const,updatedAt:'2026-09-14T00:00:00Z',finalizedAt:'2026-09-14T00:00:00Z'};
const oldState:State={forms:{'5|4':oldEntry}},oldBackup={...backup(oldState,8),seedHash:original.seedHash};
const restored=await verifyBackup(oldBackup,blank);assert.equal(stable(restored),stable(oldState));assert.equal(stable(await verifyBackup(backup(restored,9),restored)),stable(restored));
assert.notEqual(await designRevision(6,4,blank),await designRevision(6,4,restored),'Actual original mathematical task change invalidates dependency');
const draft=structuredClone(oldState);draft.forms['5|4'].status='draft';
await assert.rejects(()=>parseResult(filled(oldPacket),oldPacket,draft),/previous blueprint/);
const upgraded=(await applyOperation(draft,{kind:'packet',grade:5,form:4})).state;assert.equal(upgraded.forms['5|4'].packet.seedHash,seed.seedHash);assert.equal(upgraded.forms['5|4'].items.length,0);assert.equal(draft.forms['5|4'].items.length,15,'Caller history snapshot remains intact');
assert.ok(packetText(packet).includes('aac.conflict.v1'));assert.ok(packetText(packet).includes('comparisonSignature'));
// Feasibility witnesses for repaired relationships; never shipped as assessment items.
assert.equal((.5/3)-(1/12),1/12);assert.equal(6/2/1.5+6/2/2,3.5);assert.equal(4*2/4,2);
assert.deepEqual([2,3,6,7].filter(x=>x*(10-x)===21&&x<5),[3]);assert.equal(18/(12/3),4.5);assert.equal(11-2*3,5);assert.equal(1.5*4,6);
console.log('PASS: repaired scope and duplicate checks, all 15 planned forms, locked identifiers, exact numeric answers, conflict preservation, old finalized/draft backup migration, and mathematical feasibility witnesses.');
