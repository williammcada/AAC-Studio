import archive44 from '../data/blueprint-4.4-original.json';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {seed,historicalSeed,slots,legacyGenerationSpecs,type State,type Spec,type Item,type Packet,ORIGINAL_YEAR} from '../lib/model';
import {responseValid,STUDIO_VERSION,hasStudentFraction} from '../lib/contracts';
import {validateItem,validateSvg,validateBlueprint,makePacket,digest,stable,designRevision} from '../lib/validation';
import {applyOperation,backup,verifyBackup} from '../lib/operations';
import {packetText,resultSkeleton} from '../lib/packet';
import {schemaDocument} from '../lib/schema-document';
import {resultSchema} from '../lib/validation';
import {semanticIdentity} from '../lib/task-integrity';
import {parseMath} from '../lib/math';
import {buildDocx} from '../lib/export';
import JSZip from '../vendor/jszip.cjs';
let checks=0;function ok(v:unknown,message:string){assert.ok(v,message);checks++;}
const get=(key:string)=>seed.items.find(s=>s.key===key)!;
const base=get('5|4|1');
const spec=(answerObject:string,quantity='Unitless')=>({...base,answerObject,quantity,given:'The variables x and y represent numbers.',requiredResult:'one value'});
for(const [kind,quantity,value,expected] of [
 ['Number','Unitless','1/0',false],['Number','Integer','-2',true],['Number','Integer','3/2',false],['Number','Count','-2',false],['Number','Probability','3/2',false],['Number','Percent','20%',true],['Number','Percent','20',false],
 ['Ordered pair','Location','(1/0, 2)',false],['Ordered pair','Location','(1 1/2, -2/3)',true],['Ordered pair','Location','(banana, 2)',false],
 ['Ratio','Ratio','-3:1',true],['Ratio','Ratio','1:0',false],['Ratio','Ratio','1/2:3/4',true],
 ['Equation','Symbolic','banana=pear',false],['Equation','Symbolic','x = 3',true],['Equation','Symbolic','x==3',false],
 ['Expression','Symbolic','This is not mathematics',false],['Expression','Symbolic','3(x+2)-y/2',true],['Expression','Symbolic','x/(2-2)',false],['Expression','Symbolic','x +',false],['Expression','Symbolic','z+1',false],
 ['Inequality','Relation','bananas > apples',false],['Inequality','Relation','x > -2',true],['Quotient with remainder','Unitless','12 R 3',true],['Quotient with remainder','Unitless','12:3',false],
 ['Repeating decimal','Unitless','0.(3)',true],['Repeating decimal','Unitless','-1.2(34)',true],['Repeating decimal','Unitless','0.333...',false],['Repeating decimal','Unitless','1/3',false],
] as const)ok(responseValid(value,spec(kind,quantity))===expected,`${kind}: ${value}`);
const sign={...spec('Symbol','Symbolic'),action:'Find the sign of a quotient.'};ok(responseValid('+',sign)&&responseValid('−',sign)&&!responseValid('banana',sign),'Sign enum');
let state=(await applyOperation({forms:{}},{kind:'createYear',label:'Release regression',yearKind:'test'})).state;
const item=(s:Spec):Item=>({question:s.question,specificationHash:'test-hash',templateId:'TEST-02-T',surfaceFormId:'TEST-02-S',structureFamilyId:s.structureFamilyId,stem:'Find the value.',choices:[],answer:'1',acceptedAnswers:[],scoringNote:'One point.',solution:['The diagnostic calculation gives 1.'],visual:null,reviewNote:''});
const fixture=item(base);
for(const note of ['No specification conflict.','No unresolved conflict was found.'])ok(!validateItem({...fixture,reviewNote:note},base,state,[fixture]).some(x=>x.code==='specification'),'Narrative negation is not a conflict');
for(const char of ['¼','⅐','⅑','⅒','⅕','⅖','⅟','↉']){
 ok(hasStudentFraction(char),`Shared fraction ${char}`);assert.throws(()=>parseMath(char));checks++;
 ok(validateItem({...fixture,stem:`Find ${char}.`},base,state,[fixture]).some(x=>x.code==='fraction'),'Stem fraction');
 ok(!!validateSvg(`<svg viewBox="0 0 100 40"><text x="1" y="20">${char}</text></svg>`),'SVG fraction');
 const tableSpec={...base,visualPolicy:'Required',representation:'Compact Data Table'};
 ok(validateItem({...fixture,visual:{kind:'table',headers:['Value'],rows:[[char]],alt:'Data'}},tableSpec,state,[fixture]).some(x=>x.code==='fraction'),'Table fraction');
}
for(const field of ['answer','acceptedAnswers','scoringNote','solution','reviewNote'] as const){
 const value=field==='acceptedAnswers'||field==='solution'?['\\(\\boxed{2}\\)']:'\\(\\boxed{2}\\)';
 ok(validateItem({...fixture,[field]:value},base,state,[fixture]).some(x=>x.code==='export-math'&&x.message.startsWith(field)),`Export parser: ${field}`);
}
ok(validateItem({...fixture,stem:'Find the remainder. Give reasons for your answer.'},base,state,[fixture]).some(x=>x.code==='language'),'Prohibited reasons');
for(const representation of ['Compact Data Table','Ratio Table','Function Table']){const key=representation;const s={...base,visualPolicy:'Required',representation};ok(!validateItem({...item(s),visual:{kind:'table',headers:['x'],rows:[['1']],alt:'Table'}},s,state,[]).some(x=>x.code==='visual'),'Native table '+key);}
const machine=schemaDocument(resultSchema);ok(machine.additionalProperties===false,'Exact strict result schema');ok(JSON.stringify(machine).includes('maxLength'),'Runtime limits exported');
const counts=[];
for(const g of [5,6,7])for(let f=1;f<=8;f++){
 const issues=validateBlueprint(g,f,state),errors=issues.filter(i=>i.severity==='error');counts.push({grade:g,form:f,errors:errors.length,warnings:issues.length-errors.length,codes:[...new Set(errors.map(i=>i.code))]});
 const p=await makePacket(g,f,state,!!errors.length);ok(p.items.length===15&&p.adjacent.length===30&&p.paired.length===(g===6?30:15),'Complete exclusions');
 for(const r of p.items){const {specificationHash,proposedTemplateId,proposedSurfaceFormId,...assigned}=r;ok(await digest(assigned)===specificationHash,'Hash covers exact assigned row');}
 for(const r of [...p.adjacent,...p.paired])ok(stable(r)===stable(get(r.key)),'One canonical current-year catalog');
 ok(p.studioVersion===STUDIO_VERSION&&packetText(p).includes('MACHINE RESULT SCHEMA'),'Versioned machine contract');
 if(errors.length)await assert.rejects(()=>makePacket(g,f,state),/./);
}
// Genuine old packet shapes: raw v1.2.0 audit rows and migrated v1.2.1 generation rows.
for(const purpose of ['audit','generation'] as const){
 const g=5,f=1,raw=historicalSeed.items.filter(s=>s.grade===g&&s.form===f),assigned=purpose==='audit'?raw:legacyGenerationSpecs(g,f);
 const old:Packet={schema:'aac.packet.v1',projectId:`AAC-${state.year!.id}`,seedHash:historicalSeed.seedHash,packetId:crypto.randomUUID(),designRevision:'old-design-revision',grade:g,form:f,issuedAt:new Date().toISOString(),assessmentYear:state.year,purpose,items:await Promise.all(assigned.map(async s=>({...s,specificationHash:await digest(s),proposedTemplateId:'OLD-T',proposedSurfaceFormId:'OLD-S'}))),adjacent:historicalSeed.items.filter(s=>s.grade===g&&(s.form===8||s.form===2)),paired:historicalSeed.items.filter(s=>s.grade===6&&s.form===1)};
 const saved={...state,forms:{'5|1':{packet:old,items:[],checks:{},status:'draft' as const,updatedAt:new Date().toISOString()}}};
 const oldBackup={...backup(saved,1),seedHash:historicalSeed.seedHash};
 const restored=await verifyBackup(oldBackup,{forms:{}});ok(stable(restored.forms['5|1'].packet)===stable(old),'Old immutable packet restores: '+purpose);
 const bad=structuredClone(oldBackup);bad.state.forms['5|1'].packet.items[0].given='tamper';await assert.rejects(()=>verifyBackup(bad,{forms:{}}),/specification/);checks++;
}
// The original 4.4 backup must also retain its pre-transcription-repair baselines.
const a44=archive44.items.filter(s=>s.grade===5&&s.form===4);
const p44={schema:'aac.packet.v1' as const,projectId:archive44.projectId,seedHash:archive44.seedHash,packetId:crypto.randomUUID(),designRevision:'original-44',grade:5,form:4,issuedAt:new Date().toISOString(),items:await Promise.all(a44.map(async s=>({...s,specificationHash:await digest(s),proposedTemplateId:'OLD-T',proposedSurfaceFormId:'OLD-S'}))),adjacent:archive44.items.filter(s=>s.grade===5&&(s.form===3||s.form===5)),paired:archive44.items.filter(s=>s.grade===6&&s.form===4)};
const b44={schema:'aac.backup.v1',seedHash:archive44.seedHash,state:{forms:{'5|4':{packet:p44,items:[],checks:{},status:'draft',updatedAt:new Date().toISOString()}}}};
ok(stable((await verifyBackup(b44,{forms:{}})).forms['5|4'].packet)===stable(p44),'Original 4.4 backup baselines preserved');
const p=await makePacket(5,4,state);const before=await designRevision(5,4,state);const savedGiven=get('5|4|1').given;get('5|4|1').given+=' New binding condition.';ok(before!==await designRevision(5,4,state),'Effective design changes invalidate revision');get('5|4|1').given=savedGiven;
ok(semanticIdentity(get('6|1|6'))!==semanticIdentity(get('6|2|13')),'Missing output differs from scale factor');ok(semanticIdentity(get('6|2|10'))!==semanticIdentity(get('7|2|7')),'Write differs from solve');
ok(semanticIdentity(get('5|6|6'))!==semanticIdentity(get('6|6|9')),'Repaired sharing pair differs');ok(semanticIdentity(get('6|7|4'))!==semanticIdentity(get('6|7|8')),'Repaired negation differs');
// Mathematical witnesses for repaired task relationships (not student items or DOK certification).
const gcd=(a:number,b:number):number=>b?gcd(b,a%b):a;
ok([4,6,9].filter(x=>gcd(12,x)===4).length===1,'Constrained inverse GCF has one solution');
ok((3+4)/6===7/6,'Combined sharing quotient');ok((3/4)/(1/2)===1.5,'Fractional area quotient');ok((5-2)/(1/4)===12,'Remaining unit portions require division');
const x=(180-10-20)/(2+3);ok(x===30&&2*x+10===70&&3*x+20===110,'Two angle expressions determine unique angles');
const edge=20/4;ok(2*edge*edge+4*edge*3===110,'Net surface-area witness');ok([1,2].filter(x=>2*x+1!==x+2).length===1,'Linear counterexample candidate feasibility');
ok(((1+(-2))+(1+4)+(-2+4))/2===1-2+4,'Pairwise sums uniquely recover total');
ok(40+60<180&&100+90>=180,'ASA classification has two reachable outcomes');
// Word footprint regression: deterministic diagram fixture; rendered QA remains outstanding.
const one={...item(p.items[0]),visual:{kind:'image' as const,dataUrl:'data:image/png;base64,iVBORw0KGgo=',alt:'Sizing fixture'}};
const entry={packet:{...p,items:[{...p.items[0],footprint:'Large Visual'}]},items:[one],checks:{},status:'draft' as const,updatedAt:new Date().toISOString()};
const bytes=await buildDocx(entry,'student',async()=>({bytes:new Uint8Array([1]),width:1000,height:1000}));const zip=await (JSZip as unknown as {loadAsync:(b:Uint8Array)=>Promise<{file:(n:string)=>{async:(t:string)=>Promise<string>}|null}>}).loadAsync(bytes);const xml=await zip.file('word/document.xml')!.async('string');ok(xml.includes('cy="3291840"'),'Large footprint uses 3.6 inches');
writeFileSync('docs/releases/0.5-retained-preflight.json',JSON.stringify({studioVersion:STUDIO_VERSION,blueprintVersion:seed.blueprintVersion,counts,checks,scope:'Contract and design consistency probes, not student item or DOK approval.'},null,2)+'\n');
console.log(`PASS: ${checks} release regression assertions, including all 360 assigned hashes and canonical exclusions.`);
