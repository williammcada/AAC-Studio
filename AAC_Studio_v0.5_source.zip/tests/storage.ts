import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {env} from './storage-env';
import {readWorkspace,mutate,readRevision,RevisionConflict} from '../lib/storage';
const db=new DatabaseSync(':memory:');db.exec(readFileSync('drizzle/0000_quiet_fixer.sql','utf8'));
class Statement{params:unknown[]=[];constructor(public text:string){}bind(...p:unknown[]){this.params=p;return this;}async first(){return db.prepare(this.text).get(...this.params as (string|number|null)[])||null;}async all(){return {results:db.prepare(this.text).all(...this.params as (string|number|null)[])};}run(){const r=db.prepare(this.text).run(...this.params as (string|number|null)[]);return {meta:{changes:Number(r.changes)}};}}
const objects=new Map<string,string>();let failWrite=false;
env.DB={prepare:(sql:string)=>new Statement(sql),batch:async(statements:Statement[])=>{db.exec('BEGIN');try{const r=statements.map(s=>s.run());db.exec('COMMIT');return r;}catch(e){db.exec('ROLLBACK');throw e;}}};
env.BUCKET={put:async(key:string,text:string)=>{if(failWrite)throw Error('R2 unavailable');objects.set(key,text);},get:async(key:string)=>objects.has(key)?{json:async()=>JSON.parse(objects.get(key)!)}:null,delete:async(key:string)=>objects.delete(key)};
const initial=await readWorkspace();assert.equal(initial.revision,0);
const a=await mutate(0,{kind:'packet',grade:5,form:4});assert.equal(a.revision,1);assert.equal((await readWorkspace()).state.forms['5|4'].packet.packetId,a.state.forms['5|4'].packet.packetId);
assert.deepEqual(await readRevision(1),a.state);
const race=await Promise.allSettled([mutate(1,{kind:'packet',grade:6,form:4}),mutate(1,{kind:'packet',grade:7,form:4})]);assert.equal(race.filter(r=>r.status==='fulfilled').length,1);assert.ok(race.some(r=>r.status==='rejected'&&r.reason instanceof RevisionConflict));
const current=await readWorkspace();assert.equal(current.revision,2);assert.equal(current.history.length,2);
failWrite=true;await assert.rejects(()=>mutate(2,{kind:'packet',grade:5,form:5}),/unavailable/);assert.deepEqual(await readWorkspace(),current);failWrite=false;
const key=db.prepare('SELECT snapshot_key FROM workspace').get()!.snapshot_key as string;const value=objects.get(key)!;objects.delete(key);await assert.rejects(()=>readWorkspace(),/could not be loaded/);objects.set(key,value);
assert.deepEqual(await readWorkspace(),current);
console.log('PASS: durable snapshot roundtrip, history, concurrent save conflict, failed save preservation, missing snapshot handling.');
